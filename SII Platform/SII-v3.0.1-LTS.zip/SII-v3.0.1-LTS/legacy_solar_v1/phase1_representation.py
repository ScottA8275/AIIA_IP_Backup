#!/usr/bin/env python3
"""
Structural Intelligence Qualification Framework
Phase 1 — Representation Qualification

This module evaluates whether an Organizational Atlas representation is
sufficiently reproducible, robust, balanced, and hierarchically coherent to
support downstream organizational interpretation.

Phase 1 reviews:

1. Seed stability
2. Parameter robustness
3. Occupancy and imbalance
4. Split/merge and hierarchy behavior
5. Adaptive bootstrap stability

The module is domain-neutral. It depends on injected atlas-construction
callbacks rather than embedding Solar-specific construction logic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

import numpy as np
import pandas as pd

from qualification_config import (
    BootstrapStrategy,
    QualificationProtocolConfig,
    parameter_configs,
)
from qualification_metrics import (
    MetricResult,
    MetricState,
    aggregate_phase_score,
    aligned_ari,
    build_metric_result,
    confidence_from_evidence,
    finite_array,
    maximum_basin_occupancy_result,
    occupancy_diagnostics,
    pairwise_seed_stability,
    split_merge_analysis,
    weighted_profile_similarity,
)
from qualification_types import (
    OrganizationalAtlas,
    RecommendationCode,
    RepresentationArtifacts,
    RepresentationReview,
    ReviewRecommendation,
    ReviewStatus,
    utc_now,
)


# =============================================================================
# CONSTRUCTION INTERFACES
# =============================================================================

@dataclass
class RepresentationRun:
    """
    Standardized output from one representation construction.

    The construction callback may use any model implementation, but must return
    aligned state-level assignments and basin-level profiles.
    """

    run_id: str
    seed: int
    config_id: str

    assignments: np.ndarray
    microstate_assignments: np.ndarray
    basin_profiles: np.ndarray
    basin_occupancy: np.ndarray

    representation: RepresentationArtifacts | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        assignments = np.asarray(self.assignments)
        microstates = np.asarray(self.microstate_assignments)
        profiles = np.asarray(self.basin_profiles, dtype=float)
        occupancy = np.asarray(self.basin_occupancy, dtype=float)

        if assignments.ndim != 1:
            raise ValueError("assignments must be one-dimensional.")
        if microstates.ndim != 1:
            raise ValueError("microstate_assignments must be one-dimensional.")
        if len(assignments) != len(microstates):
            raise ValueError(
                "basin and microstate assignments must have equal length."
            )
        if profiles.ndim != 2:
            raise ValueError("basin_profiles must be two-dimensional.")
        if occupancy.ndim != 1:
            raise ValueError("basin_occupancy must be one-dimensional.")
        if len(profiles) != len(occupancy):
            raise ValueError(
                "basin_profiles rows must equal basin_occupancy length."
            )
        if len(assignments) == 0:
            raise ValueError("Representation run contains no assignments.")
        if np.any(occupancy < 0):
            raise ValueError("basin_occupancy cannot contain negative values.")
        if occupancy.sum() <= 0:
            raise ValueError("basin_occupancy must contain positive mass.")


class RepresentationBuilder(Protocol):
    """
    Callable that constructs a representation from a state-level DataFrame.

    Parameters
    ----------
    data:
        State-level source data.
    config:
        RepresentationConfig-compatible object.
    seed:
        Random seed.
    run_id:
        Unique run identifier.
    """

    def __call__(
        self,
        data: pd.DataFrame,
        config: Any,
        seed: int,
        run_id: str,
    ) -> RepresentationRun:
        ...


@dataclass
class BootstrapSample:
    """One bootstrap resample and its provenance."""

    sample_id: str
    data: pd.DataFrame
    block_lengths: list[int]
    source_sequence_ids: list[Any]
    notes: list[str] = field(default_factory=list)


# =============================================================================
# PHASE OUTPUT
# =============================================================================

@dataclass
class Phase1Result:
    """Complete output from Phase 1 Representation Qualification."""

    review: RepresentationReview
    metric_results: dict[str, MetricResult]
    baseline_run: RepresentationRun

    seed_runs: dict[int, RepresentationRun] = field(default_factory=dict)
    parameter_runs: dict[str, RepresentationRun] = field(default_factory=dict)
    bootstrap_runs: dict[str, RepresentationRun] = field(default_factory=dict)

    seed_pairwise_table: pd.DataFrame = field(default_factory=pd.DataFrame)
    parameter_table: pd.DataFrame = field(default_factory=pd.DataFrame)
    bootstrap_table: pd.DataFrame = field(default_factory=pd.DataFrame)
    occupancy_table: pd.DataFrame = field(default_factory=pd.DataFrame)
    split_merge_table: pd.DataFrame = field(default_factory=pd.DataFrame)

    errors: list[dict[str, Any]] = field(default_factory=list)

    def to_summary(self) -> dict[str, Any]:
        return {
            "phase": self.review.phase_name,
            "status": self.review.status.value,
            "confidence": self.review.confidence,
            "n_metrics": len(self.metric_results),
            "n_seed_runs": len(self.seed_runs),
            "n_parameter_runs": len(self.parameter_runs),
            "n_bootstrap_runs": len(self.bootstrap_runs),
            "n_errors": len(self.errors),
            "metric_results": {
                key: value.to_dict()
                for key, value in self.metric_results.items()
            },
        }


# =============================================================================
# INTERNAL HELPERS
# =============================================================================

def _threshold(
    protocol: QualificationProtocolConfig,
    metric_id: str,
):
    return protocol.qualification_policy.threshold_map().get(metric_id)


def _safe_run(
    *,
    builder: RepresentationBuilder,
    data: pd.DataFrame,
    config: Any,
    seed: int,
    run_id: str,
    errors: list[dict[str, Any]],
    fail_fast: bool,
) -> RepresentationRun | None:
    try:
        run = builder(data, config, seed, run_id)
        run.validate()
        return run
    except Exception as exc:
        errors.append({
            "run_id": run_id,
            "seed": seed,
            "config_id": getattr(config, "config_id", str(config)),
            "error_type": exc.__class__.__name__,
            "error": str(exc),
        })
        if fail_fast:
            raise
        return None


def _occupancy_table(assignments: Sequence[int]) -> pd.DataFrame:
    series = pd.Series(np.asarray(assignments), name="basin_id")
    counts = series.value_counts().sort_index()
    table = counts.rename("count").to_frame()
    table["fraction"] = table["count"] / max(int(table["count"].sum()), 1)
    table.index.name = "basin_id"
    return table.reset_index()


def _recommendation(
    code: RecommendationCode,
    rationale: str,
    *,
    priority: int,
    required: bool,
) -> ReviewRecommendation:
    return ReviewRecommendation(
        code=code,
        priority=priority,
        rationale=rationale,
        required_before_advancement=required,
    )


def _result_value(
    results: Mapping[str, MetricResult],
    metric_id: str,
) -> float | None:
    result = results.get(metric_id)
    return result.value if result else None


# =============================================================================
# SEED REVIEW
# =============================================================================

def run_seed_review(
    *,
    data: pd.DataFrame,
    builder: RepresentationBuilder,
    protocol: QualificationProtocolConfig,
    baseline_run: RepresentationRun,
    errors: list[dict[str, Any]],
) -> tuple[
    dict[int, RepresentationRun],
    dict[str, MetricResult],
    pd.DataFrame,
]:
    runs: dict[int, RepresentationRun] = {}
    baseline_seed = protocol.identity.random_seed

    if protocol.seed_review.include_baseline_seed:
        runs[baseline_seed] = baseline_run

    for seed in protocol.seed_review.seeds:
        if seed in runs:
            continue
        run = _safe_run(
            builder=builder,
            data=data,
            config=protocol.baseline_representation,
            seed=seed,
            run_id=f"seed_{seed}",
            errors=errors,
            fail_fast=protocol.computational.fail_fast,
        )
        if run is not None:
            runs[seed] = run

    assignments = {
        seed: run.assignments
        for seed, run in runs.items()
    }

    thresholds = protocol.qualification_policy.threshold_map()
    required_ids = (
        "seed_median_aligned_ari",
        "seed_dominant_basin_stability",
        "seed_minor_basin_stability",
    )

    if len(assignments) < 2:
        reason = "Fewer than two valid seed runs completed."
        results = {
            metric_id: build_metric_result(
                metric_id,
                thresholds[metric_id].display_name,
                None,
                threshold=thresholds[metric_id],
                n_evidence=len(assignments),
                failure_reason=reason,
                limitations=[reason],
                recommendation=(
                    thresholds[metric_id].recommendation_on_failure.value
                    if thresholds[metric_id].recommendation_on_failure
                    else None
                ),
            )
            for metric_id in required_ids
        }
        return runs, results, pd.DataFrame()

    pairwise = pairwise_seed_stability(assignments)

    results: dict[str, MetricResult] = {}
    column_map = {
        "seed_median_aligned_ari": "aligned_ari",
        "seed_dominant_basin_stability": "dominant_basin_stability",
        "seed_minor_basin_stability": "minor_basin_stability",
    }

    for metric_id, column in column_map.items():
        values = finite_array(pairwise[column])
        median = float(np.median(values)) if len(values) else None
        dispersion = (
            float(np.std(values, ddof=1))
            if len(values) > 1
            else None
        )
        confidence = confidence_from_evidence(
            n_evidence=len(values),
            agreement=median,
            dispersion=dispersion,
            target_n=max(len(protocol.seed_review.seeds), 5),
        )
        threshold = thresholds[metric_id]
        results[metric_id] = build_metric_result(
            metric_id,
            threshold.display_name,
            median,
            threshold=threshold,
            confidence=confidence,
            n_evidence=len(values),
            distribution=values,
            components={
                "minimum": float(np.min(values)) if len(values) else None,
                "maximum": float(np.max(values)) if len(values) else None,
                "mean": float(np.mean(values)) if len(values) else None,
            },
            recommendation=(
                threshold.recommendation_on_failure.value
                if threshold.recommendation_on_failure
                else None
            ),
        )

    return runs, results, pairwise


# =============================================================================
# PARAMETER REVIEW
# =============================================================================

def run_parameter_review(
    *,
    data: pd.DataFrame,
    builder: RepresentationBuilder,
    protocol: QualificationProtocolConfig,
    baseline_run: RepresentationRun,
    errors: list[dict[str, Any]],
) -> tuple[
    dict[str, RepresentationRun],
    dict[str, MetricResult],
    pd.DataFrame,
    pd.DataFrame,
]:
    runs: dict[str, RepresentationRun] = {
        baseline_run.config_id: baseline_run
    }

    configs = parameter_configs(protocol)
    for config in configs:
        if config.config_id in runs:
            continue
        run = _safe_run(
            builder=builder,
            data=data,
            config=config,
            seed=protocol.identity.random_seed,
            run_id=f"parameter_{config.config_id}",
            errors=errors,
            fail_fast=protocol.computational.fail_fast,
        )
        if run is not None:
            runs[config.config_id] = run

    records: list[dict[str, Any]] = []
    split_merge_records: list[dict[str, Any]] = []

    for config_id, run in runs.items():
        if config_id == baseline_run.config_id:
            continue

        if len(run.assignments) != len(baseline_run.assignments):
            records.append({
                "config_id": config_id,
                "completed": False,
                "reason": "Assignment length differs from baseline.",
            })
            continue

        profile_similarity = weighted_profile_similarity(
            baseline_run.basin_profiles,
            run.basin_profiles,
            baseline_run.basin_occupancy,
        )
        split_merge = split_merge_analysis(
            baseline_run.assignments,
            run.assignments,
        )
        ari = aligned_ari(
            baseline_run.assignments,
            run.assignments,
        )

        records.append({
            "config_id": config_id,
            "completed": True,
            "occupancy_weighted_profile_similarity": profile_similarity,
            "aligned_ari": ari,
            "split_merge_consistency": split_merge[
                "split_merge_consistency"
            ],
            "split_count": split_merge["split_count"],
            "merge_count": split_merge["merge_count"],
        })

        ref_detail = split_merge["reference_detail"]
        if isinstance(ref_detail, pd.DataFrame) and not ref_detail.empty:
            detail = ref_detail.copy()
            detail["config_id"] = config_id
            detail["direction"] = "reference_to_candidate"
            split_merge_records.extend(detail.to_dict(orient="records"))

        cand_detail = split_merge["candidate_detail"]
        if isinstance(cand_detail, pd.DataFrame) and not cand_detail.empty:
            detail = cand_detail.copy()
            detail["config_id"] = config_id
            detail["direction"] = "candidate_to_reference"
            split_merge_records.extend(detail.to_dict(orient="records"))

    table = pd.DataFrame(records)
    split_merge_table = pd.DataFrame(split_merge_records)

    expected_nonbaseline = max(len(configs) - 1, 1)
    completed = (
        int(table["completed"].sum())
        if not table.empty and "completed" in table
        else 0
    )
    completed_fraction = completed / expected_nonbaseline

    results: dict[str, MetricResult] = {}

    profile_metric_id = "parameter_occupancy_weighted_similarity"
    split_metric_id = "parameter_split_merge_consistency"

    profile_threshold = _threshold(protocol, profile_metric_id)
    split_threshold = _threshold(protocol, split_metric_id)

    valid = (
        table.loc[table["completed"] == True]  # noqa: E712
        if not table.empty and "completed" in table
        else pd.DataFrame()
    )

    profile_values = (
        finite_array(valid["occupancy_weighted_profile_similarity"])
        if not valid.empty
        else np.array([])
    )
    split_values = (
        finite_array(valid["split_merge_consistency"])
        if not valid.empty
        else np.array([])
    )

    limitations = []
    if completed_fraction < protocol.parameter_review.minimum_completed_fraction:
        limitations.append(
            "The completed parameter-run fraction was below the configured "
            "minimum."
        )

    for metric_id, values, threshold in (
        (profile_metric_id, profile_values, profile_threshold),
        (split_metric_id, split_values, split_threshold),
    ):
        median = float(np.median(values)) if len(values) else None
        confidence = confidence_from_evidence(
            n_evidence=len(values),
            agreement=median,
            dispersion=(
                float(np.std(values, ddof=1))
                if len(values) > 1
                else None
            ),
            target_n=expected_nonbaseline,
        )
        results[metric_id] = build_metric_result(
            metric_id,
            threshold.display_name if threshold else metric_id,
            median,
            threshold=threshold,
            confidence=confidence,
            n_evidence=len(values),
            distribution=values,
            components={
                "completed_runs": completed,
                "expected_runs": expected_nonbaseline,
                "completed_fraction": completed_fraction,
                "minimum": float(np.min(values)) if len(values) else None,
                "maximum": float(np.max(values)) if len(values) else None,
            },
            limitations=limitations,
            failure_reason=(
                "Insufficient completed parameter configurations."
                if len(values) == 0
                else None
            ),
            recommendation=(
                threshold.recommendation_on_failure.value
                if threshold and threshold.recommendation_on_failure
                else None
            ),
        )

    return runs, results, table, split_merge_table


# =============================================================================
# ADAPTIVE BOOTSTRAP
# =============================================================================

def _resolve_sequence_column(
    data: pd.DataFrame,
    protocol: QualificationProtocolConfig,
) -> str | None:
    for alias in protocol.columns.sequence_aliases:
        if alias in data.columns:
            return alias
    return None


def _adaptive_block_length(
    sequence_length: int,
    protocol: QualificationProtocolConfig,
) -> int | None:
    config = protocol.bootstrap
    if sequence_length < config.minimum_block_length:
        return None

    if config.strategy == BootstrapStrategy.FIXED_CONTIGUOUS_BLOCK:
        if sequence_length < config.target_block_length:
            return None
        return config.target_block_length

    if config.strategy == BootstrapStrategy.ADAPTIVE_CONTIGUOUS_BLOCK:
        maximum_allowed = min(
            config.maximum_block_length,
            sequence_length // max(config.minimum_blocks_per_sequence, 1),
        )
        if maximum_allowed < config.minimum_block_length:
            maximum_allowed = min(
                config.maximum_block_length,
                sequence_length,
            )
        if maximum_allowed < config.minimum_block_length:
            return None
        return int(min(config.target_block_length, maximum_allowed))

    return sequence_length


def generate_bootstrap_sample(
    data: pd.DataFrame,
    *,
    protocol: QualificationProtocolConfig,
    rng: np.random.Generator,
    replicate_index: int,
) -> BootstrapSample | None:
    sequence_column = _resolve_sequence_column(data, protocol)

    if sequence_column is None:
        groups = [("single_sequence", data)]
    else:
        groups = list(data.groupby(sequence_column, sort=False))

    blocks: list[pd.DataFrame] = []
    lengths: list[int] = []
    source_ids: list[Any] = []
    notes: list[str] = []

    eligible = []
    for sequence_id, group in groups:
        group = group.reset_index(drop=True)
        block_length = _adaptive_block_length(len(group), protocol)
        if block_length is not None:
            eligible.append((sequence_id, group, block_length))

    if not eligible:
        return None

    target_rows = len(data)
    accumulated = 0
    block_index = 0

    while accumulated < target_rows:
        sequence_id, group, block_length = eligible[
            int(rng.integers(0, len(eligible)))
        ]
        max_start = len(group) - block_length
        start = int(rng.integers(0, max_start + 1))
        block = group.iloc[start:start + block_length].copy()

        if protocol.bootstrap.assign_new_sequence_ids:
            new_id = f"boot_{replicate_index:03d}_{block_index:05d}"
            if sequence_column is None:
                block["bootstrap_sequence_id"] = new_id
            else:
                block[sequence_column] = new_id

        blocks.append(block)
        lengths.append(block_length)
        source_ids.append(sequence_id)
        accumulated += len(block)
        block_index += 1

    sample = pd.concat(blocks, ignore_index=True).iloc[:target_rows].copy()
    if accumulated > target_rows:
        notes.append(
            "The final sampled block was truncated to match source row count."
        )

    return BootstrapSample(
        sample_id=f"bootstrap_{replicate_index:03d}",
        data=sample,
        block_lengths=lengths,
        source_sequence_ids=source_ids,
        notes=notes,
    )


def run_bootstrap_review(
    *,
    data: pd.DataFrame,
    builder: RepresentationBuilder,
    protocol: QualificationProtocolConfig,
    baseline_run: RepresentationRun,
    errors: list[dict[str, Any]],
) -> tuple[
    dict[str, RepresentationRun],
    MetricResult,
    pd.DataFrame,
]:
    runs: dict[str, RepresentationRun] = {}
    records: list[dict[str, Any]] = []
    rng = np.random.default_rng(protocol.identity.random_seed)

    for replicate in range(protocol.bootstrap.n_replicates):
        sample = generate_bootstrap_sample(
            data,
            protocol=protocol,
            rng=rng,
            replicate_index=replicate,
        )

        if sample is None:
            records.append({
                "replicate": replicate,
                "completed": False,
                "reason": "No sequences met adaptive block requirements.",
            })
            continue

        run = _safe_run(
            builder=builder,
            data=sample.data,
            config=protocol.baseline_representation,
            seed=protocol.identity.random_seed + replicate + 1,
            run_id=sample.sample_id,
            errors=errors,
            fail_fast=protocol.computational.fail_fast,
        )
        if run is None:
            records.append({
                "replicate": replicate,
                "completed": False,
                "reason": "Representation construction failed.",
            })
            continue

        runs[sample.sample_id] = run

        profile_similarity = weighted_profile_similarity(
            baseline_run.basin_profiles,
            run.basin_profiles,
            baseline_run.basin_occupancy,
        )

        records.append({
            "replicate": replicate,
            "sample_id": sample.sample_id,
            "completed": True,
            "profile_similarity": profile_similarity,
            "n_blocks": len(sample.block_lengths),
            "median_block_length": float(np.median(sample.block_lengths)),
            "minimum_block_length": int(np.min(sample.block_lengths)),
            "maximum_block_length": int(np.max(sample.block_lengths)),
        })

    table = pd.DataFrame(records)
    values = (
        finite_array(
            table.loc[table["completed"] == True, "profile_similarity"]  # noqa: E712
        )
        if not table.empty and "completed" in table
        else np.array([])
    )

    threshold = _threshold(protocol, "bootstrap_profile_similarity")

    if len(values) == 0:
        reason = (
            "Bootstrap stability was not evaluated because no valid adaptive "
            "bootstrap representations completed."
        )
        result = build_metric_result(
            "bootstrap_profile_similarity",
            threshold.display_name if threshold else "Bootstrap profile similarity",
            None,
            threshold=threshold,
            n_evidence=0,
            limitations=[reason],
            failure_reason=reason,
            recommendation=RecommendationCode.REPAIR_BOOTSTRAP.value,
        )
        return runs, result, table

    median = float(np.median(values))
    confidence = confidence_from_evidence(
        n_evidence=len(values),
        agreement=median,
        dispersion=(
            float(np.std(values, ddof=1))
            if len(values) > 1
            else None
        ),
        target_n=protocol.bootstrap.n_replicates,
    )
    result = build_metric_result(
        "bootstrap_profile_similarity",
        threshold.display_name if threshold else "Bootstrap profile similarity",
        median,
        threshold=threshold,
        confidence=confidence,
        n_evidence=len(values),
        distribution=values,
        components={
            "completed_replicates": len(values),
            "requested_replicates": protocol.bootstrap.n_replicates,
            "completed_fraction": len(values) / protocol.bootstrap.n_replicates,
        },
        recommendation=(
            threshold.recommendation_on_failure.value
            if threshold and threshold.recommendation_on_failure
            else None
        ),
    )
    return runs, result, table


# =============================================================================
# REVIEW INTERPRETATION
# =============================================================================

def _build_review_narrative(
    *,
    status: ReviewStatus,
    metric_results: Mapping[str, MetricResult],
    occupancy: Mapping[str, float],
) -> str:
    seed_ari = _result_value(metric_results, "seed_median_aligned_ari")
    parameter_similarity = _result_value(
        metric_results,
        "parameter_occupancy_weighted_similarity",
    )
    bootstrap_similarity = _result_value(
        metric_results,
        "bootstrap_profile_similarity",
    )
    max_occupancy = occupancy.get("maximum_basin_occupancy")

    parts = [
        f"The representation review was classified as {status.value.replace('_', ' ')}."
    ]

    if seed_ari is not None:
        parts.append(
            f"Median aligned seed agreement was {seed_ari:.3f}."
        )
    else:
        parts.append("Seed agreement could not be fully evaluated.")

    if parameter_similarity is not None:
        parts.append(
            "Median occupancy-weighted parameter similarity was "
            f"{parameter_similarity:.3f}."
        )
    else:
        parts.append("Parameter robustness could not be fully evaluated.")

    if max_occupancy is not None:
        parts.append(
            f"The largest basin contained {max_occupancy:.1%} of states."
        )

    if bootstrap_similarity is not None:
        parts.append(
            f"Median adaptive-bootstrap profile similarity was "
            f"{bootstrap_similarity:.3f}."
        )
    else:
        parts.append(
            "Bootstrap evidence remains unavailable and was not treated as a "
            "scientific failure."
        )

    return " ".join(parts)


def _populate_review(
    *,
    review: RepresentationReview,
    metric_results: Mapping[str, MetricResult],
    phase_score: Any,
    occupancy: Mapping[str, float],
    parameter_table: pd.DataFrame,
    split_merge_table: pd.DataFrame,
    bootstrap_table: pd.DataFrame,
    errors: Sequence[Mapping[str, Any]],
) -> None:
    review.status = phase_score.status
    review.confidence = phase_score.confidence
    review.completed_utc = utc_now()

    review.seed_stability = {
        metric_id: metric_results[metric_id].to_dict()
        for metric_id in (
            "seed_median_aligned_ari",
            "seed_dominant_basin_stability",
            "seed_minor_basin_stability",
        )
        if metric_id in metric_results
    }

    review.parameter_stability = {
        metric_id: metric_results[metric_id].to_dict()
        for metric_id in (
            "parameter_occupancy_weighted_similarity",
            "parameter_split_merge_consistency",
        )
        if metric_id in metric_results
    }

    review.occupancy_stability = dict(occupancy)
    review.hierarchical_stability = {
        "parameter_runs_evaluated": int(
            parameter_table["completed"].sum()
        )
        if not parameter_table.empty and "completed" in parameter_table
        else 0,
    }
    review.split_merge_analysis = {
        "detail_rows": len(split_merge_table),
        "median_consistency": _result_value(
            metric_results,
            "parameter_split_merge_consistency",
        ),
    }

    review.evidence.metrics = {
        metric_id: result.to_dict()
        for metric_id, result in metric_results.items()
    }
    review.evidence.tables["parameter_review"] = parameter_table
    review.evidence.tables["split_merge_review"] = split_merge_table
    review.evidence.tables["bootstrap_review"] = bootstrap_table

    for metric_id, result in metric_results.items():
        if result.state == MetricState.SUPPORTED:
            review.strengths.append(
                f"{result.display_name} was supported."
            )
        elif result.state == MetricState.NOT_SUPPORTED:
            review.concerns.append(
                result.failure_reason
                or f"{result.display_name} was not supported."
            )
        elif result.state == MetricState.NOT_EVALUATED:
            review.limitations.extend(result.limitations)

    maximum_occupancy = occupancy.get("maximum_basin_occupancy", 0.0)
    if maximum_occupancy > 0.90:
        review.concerns.append(
            "The atlas is strongly dominated by one basin; hierarchical "
            "structure within that basin should be evaluated."
        )
        review.recommendations.append(
            _recommendation(
                RecommendationCode.INVESTIGATE_IMBALANCE,
                "Evaluate whether the dominant basin contains stable internal "
                "substructure or reflects representation collapse.",
                priority=1,
                required=True,
            )
        )

    if metric_results.get("seed_median_aligned_ari", MetricResult(
        "", "", None, None, MetricState.NOT_EVALUATED
    )).state == MetricState.NOT_SUPPORTED:
        review.recommendations.append(
            _recommendation(
                RecommendationCode.REVISE_REPRESENTATION,
                "Seed-level basin organization is not sufficiently reproducible.",
                priority=1,
                required=True,
            )
        )

    if metric_results.get(
        "parameter_occupancy_weighted_similarity",
        MetricResult("", "", None, None, MetricState.NOT_EVALUATED),
    ).state == MetricState.NOT_SUPPORTED:
        review.recommendations.append(
            _recommendation(
                RecommendationCode.REFINE_PARAMETERS,
                "Representation changes materially across nearby parameter "
                "settings.",
                priority=1,
                required=True,
            )
        )

    bootstrap_result = metric_results.get("bootstrap_profile_similarity")
    if bootstrap_result and bootstrap_result.state == MetricState.NOT_EVALUATED:
        review.recommendations.append(
            _recommendation(
                RecommendationCode.REPAIR_BOOTSTRAP,
                "Bootstrap evidence is unavailable; retain Not Evaluated status "
                "until sequence-aware resampling is feasible.",
                priority=2,
                required=False,
            )
        )

    if errors:
        review.limitations.append(
            f"{len(errors)} representation construction runs failed."
        )

    review.limitations = list(dict.fromkeys(review.limitations))
    review.strengths = list(dict.fromkeys(review.strengths))
    review.concerns = list(dict.fromkeys(review.concerns))

    review.narrative = _build_review_narrative(
        status=review.status,
        metric_results=metric_results,
        occupancy=occupancy,
    )
    review.validate()


# =============================================================================
# PUBLIC PHASE EXECUTION
# =============================================================================

def run_phase1_representation(
    *,
    atlas: OrganizationalAtlas,
    data: pd.DataFrame,
    builder: RepresentationBuilder,
    protocol: QualificationProtocolConfig,
    output_dir: Path | None = None,
) -> Phase1Result:
    """
    Execute Phase 1 Representation Qualification.

    The atlas must already contain a baseline representation, or the baseline
    will be constructed through the supplied builder.
    """
    protocol.validate()
    review = RepresentationReview()
    review.begin()

    errors: list[dict[str, Any]] = []

    baseline_run = _safe_run(
        builder=builder,
        data=data,
        config=protocol.baseline_representation,
        seed=protocol.identity.random_seed,
        run_id="baseline",
        errors=errors,
        fail_fast=True,
    )
    if baseline_run is None:
        raise RuntimeError("Baseline representation construction failed.")

    seed_runs, seed_results, seed_table = run_seed_review(
        data=data,
        builder=builder,
        protocol=protocol,
        baseline_run=baseline_run,
        errors=errors,
    )

    (
        parameter_runs,
        parameter_results,
        parameter_table,
        split_merge_table,
    ) = run_parameter_review(
        data=data,
        builder=builder,
        protocol=protocol,
        baseline_run=baseline_run,
        errors=errors,
    )

    bootstrap_runs, bootstrap_result, bootstrap_table = run_bootstrap_review(
        data=data,
        builder=builder,
        protocol=protocol,
        baseline_run=baseline_run,
        errors=errors,
    )

    occupancy = occupancy_diagnostics(baseline_run.assignments)
    occupancy_table = _occupancy_table(baseline_run.assignments)
    occupancy_result = maximum_basin_occupancy_result(
        baseline_run.assignments,
        threshold=_threshold(protocol, "maximum_basin_occupancy"),
    )

    metric_results: dict[str, MetricResult] = {}
    metric_results.update(seed_results)
    metric_results.update(parameter_results)
    metric_results["maximum_basin_occupancy"] = occupancy_result
    metric_results["bootstrap_profile_similarity"] = bootstrap_result

    phase_policy = protocol.qualification_policy.phase_policy_map()["phase1"]
    phase_score = aggregate_phase_score(
        phase_policy,
        protocol.qualification_policy.threshold_map(),
        metric_results,
        unavailable_critical_blocks=(
            protocol.qualification_policy
            .unavailable_critical_metric_blocks_qualification
        ),
    )

    _populate_review(
        review=review,
        metric_results=metric_results,
        phase_score=phase_score,
        occupancy=occupancy,
        parameter_table=parameter_table,
        split_merge_table=split_merge_table,
        bootstrap_table=bootstrap_table,
        errors=errors,
    )

    if atlas.qualification is not None:
        atlas.qualification.representation_review = review

    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        seed_table.to_csv(
            output_dir / "phase1_seed_stability.csv",
            index=False,
        )
        parameter_table.to_csv(
            output_dir / "phase1_parameter_stability.csv",
            index=False,
        )
        split_merge_table.to_csv(
            output_dir / "phase1_split_merge_detail.csv",
            index=False,
        )
        bootstrap_table.to_csv(
            output_dir / "phase1_bootstrap_stability.csv",
            index=False,
        )
        occupancy_table.to_csv(
            output_dir / "phase1_occupancy.csv",
            index=False,
        )
        pd.DataFrame(errors).to_csv(
            output_dir / "phase1_errors.csv",
            index=False,
        )

    return Phase1Result(
        review=review,
        metric_results=metric_results,
        baseline_run=baseline_run,
        seed_runs=seed_runs,
        parameter_runs=parameter_runs,
        bootstrap_runs=bootstrap_runs,
        seed_pairwise_table=seed_table,
        parameter_table=parameter_table,
        bootstrap_table=bootstrap_table,
        occupancy_table=occupancy_table,
        split_merge_table=split_merge_table,
        errors=errors,
    )


# =============================================================================
# ADAPTER EXAMPLE
# =============================================================================

def make_representation_run(
    *,
    run_id: str,
    seed: int,
    config_id: str,
    assignments: Sequence[int],
    microstate_assignments: Sequence[int],
    basin_profiles: np.ndarray,
    basin_occupancy: Sequence[float],
    representation: RepresentationArtifacts | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> RepresentationRun:
    """
    Convenience adapter for converting an existing atlas-construction function's
    outputs into the Phase 1 contract.
    """
    run = RepresentationRun(
        run_id=run_id,
        seed=seed,
        config_id=config_id,
        assignments=np.asarray(assignments, dtype=int),
        microstate_assignments=np.asarray(
            microstate_assignments,
            dtype=int,
        ),
        basin_profiles=np.asarray(basin_profiles, dtype=float),
        basin_occupancy=np.asarray(basin_occupancy, dtype=float),
        representation=representation,
        metadata=dict(metadata or {}),
    )
    run.validate()
    return run


if __name__ == "__main__":
    print(
        "Phase 1 module loaded. Supply an OrganizationalAtlas, source DataFrame, "
        "QualificationProtocolConfig, and RepresentationBuilder to execute."
    )
