"""Validated Solar M1D/RIX v1 implementation preserved for SII v2.2 integration."""
