"""
Solar implementation of the Structural Intelligence Instrument abstractions.

This module contains all Solar-specific meaning. The SII core remains
domain-independent.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from phase1_representation import RepresentationRun
from qualification_config import QualificationProtocolConfig
from qualification_types import OrganizationalAtlas
from sii_core import Experiment, RepresentationProduct
from solar_m1d_adapter import (
    SolarDataset,
    SolarM1DAdapter,
    adapter_diagnostics,
    initialize_solar_atlas,
)


@dataclass
class SolarRepresentationEngine:
    """
    Solar representation engine backed by the established M1D/RIX builder.

    It also remains callable by Phase 1 because SolarM1DAdapter implements the
    existing RepresentationBuilder protocol.
    """

    protocol: QualificationProtocolConfig
    legacy_script_path: Path
    name: str = "Solar M1D RIX Representation Engine"
    version: str = "1.0"

    def __post_init__(self) -> None:
        self.adapter = SolarM1DAdapter(
            protocol=self.protocol,
            legacy_script_path=self.legacy_script_path,
        )

    def load_dataset(self, path: Path) -> SolarDataset:
        return self.adapter.load_data(path)

    def validate_dataset(self, dataset: SolarDataset) -> None:
        dataset.validate()

    def build_representation(
        self,
        dataset: SolarDataset,
        *,
        seed: int,
    ) -> RepresentationProduct:
        run: RepresentationRun = self.adapter(
            dataset.data,
            self.protocol.baseline_representation,
            seed,
        )
        product = RepresentationProduct(
            product_id=(
                f"solar-{run.config.config_id}-seed-{seed}"
            ),
            experiment_code="SOLAR-M1D",
            engine_name=self.name,
            engine_version=self.version,
            configuration_id=run.config.config_id,
            representation=run.representation,
            n_observations=int(len(dataset.data)),
            feature_names=list(dataset.feature_names),
            provenance={
                "source_path": str(dataset.source_path),
                "legacy_script": str(self.legacy_script_path),
                "seed": seed,
                "run_id": run.run_id,
            },
            diagnostics={
                "metric_values": dict(run.metric_values),
                "metadata": dict(run.metadata),
            },
        )
        product.validate()
        return product

    def diagnostics(self, dataset: SolarDataset) -> dict[str, Any]:
        return adapter_diagnostics(self.adapter, dataset)

    def __call__(self, *args: Any, **kwargs: Any) -> RepresentationRun:
        """Delegate to the existing builder interface for Phase 1."""
        return self.adapter(*args, **kwargs)


@dataclass
class SolarExperiment(
    Experiment[SolarDataset, SolarRepresentationEngine]
):
    """M1D Solar Organizational Atlas scientific experiment."""

    dataset_path: Path
    legacy_script_path: Path
    name: str = "M1D Solar Organizational Atlas"
    code: str = "SOLAR-M1D"
    description: str = (
        "Construct and qualify a structural representation of Solar "
        "organizational dynamics across the analysis-ready observation stream."
    )

    def create_engine(
        self,
        protocol: QualificationProtocolConfig,
    ) -> SolarRepresentationEngine:
        return SolarRepresentationEngine(
            protocol=protocol,
            legacy_script_path=self.legacy_script_path,
        )

    def initialize_atlas(
        self,
        protocol: QualificationProtocolConfig,
        dataset: SolarDataset,
    ) -> OrganizationalAtlas:
        return initialize_solar_atlas(
            protocol=protocol,
            dataset=dataset,
        )
