#!/usr/bin/env python3
"""
Structural Intelligence Qualification Framework
Protocol configuration for Organizational Atlas qualification.

This module separates scientific policy from execution code. It defines:

- dataset and output locations
- quick and full qualification modes
- representation parameters
- seed and parameter reviews
- bootstrap strategy
- null-model families
- phase weights
- qualification thresholds
- maturity rules
- publication output conventions

The configuration is domain-neutral by design. Solar is the first concrete
application, but future Bell, protein, world-model, financial, and other atlases
can reuse the same framework.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from enum import Enum
from pathlib import Path
from typing import Any, Mapping

from qualification_types import (
    QualificationLevel,
    RecommendationCode,
    RepresentationConfig,
    ReviewStatus,
)


# =============================================================================
# ENUMERATIONS
# =============================================================================

class QualificationMode(str, Enum):
    """Execution scope for qualification."""

    QUICK = "quick"
    FULL = "full"


class BootstrapStrategy(str, Enum):
    """Supported bootstrap construction strategies."""

    ADAPTIVE_CONTIGUOUS_BLOCK = "adaptive_contiguous_block"
    FIXED_CONTIGUOUS_BLOCK = "fixed_contiguous_block"
    SEQUENCE_RESAMPLE = "sequence_resample"


class NullFamily(str, Enum):
    """Canonical null-model families."""

    FULL_TIME_SHUFFLE = "full_time_shuffle"
    WITHIN_FEATURE_SHUFFLE = "within_feature_shuffle"
    SEQUENCE_ORDER_SHUFFLE = "sequence_order_shuffle"
    PHASE_RANDOMIZED = "phase_randomized"
    WHITE_NOISE = "white_noise"
    RANDOM_WALK = "random_walk"


class MetricDirection(str, Enum):
    """Direction required for threshold support."""

    GREATER_EQUAL = "greater_equal"
    LESS_EQUAL = "less_equal"
    BETWEEN = "between"


class ThresholdSeverity(str, Enum):
    """Scientific importance of a qualification criterion."""

    ADVISORY = "advisory"
    IMPORTANT = "important"
    CRITICAL = "critical"


class OutputFormat(str, Enum):
    """Output format identifiers."""

    CSV = "csv"
    JSON = "json"
    MARKDOWN = "markdown"
    PNG = "png"
    SVG = "svg"


# =============================================================================
# PATHS AND DATASET CONFIGURATION
# =============================================================================

@dataclass(frozen=True)
class PathConfig:
    """Input and output locations for a qualification run."""

    root: Path
    input_file: Path
    output_dir: Path
    report_dir: Path
    table_dir: Path
    figure_dir: Path
    artifact_dir: Path
    cache_dir: Path

    @classmethod
    def solar_default(cls) -> "PathConfig":
        root = Path("data") / "Goldilocks v2"
        output = root / "M1_SOLAR_ATLAS" / "M1D_QUALIFICATION"
        return cls(
            root=root,
            input_file=root / "ANALYSIS_READY" / "dataset_B_core_solar_all.csv.gz",
            output_dir=output,
            report_dir=output / "REPORTS",
            table_dir=output / "TABLES",
            figure_dir=output / "FIGURES",
            artifact_dir=output / "ARTIFACTS",
            cache_dir=output / "CACHE",
        )

    def create_directories(self) -> None:
        for path in (
            self.output_dir,
            self.report_dir,
            self.table_dir,
            self.figure_dir,
            self.artifact_dir,
            self.cache_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)


@dataclass(frozen=True)
class ColumnAliasConfig:
    """Column aliases used to resolve input data fields."""

    timestamp_aliases: tuple[str, ...]
    period_aliases: tuple[str, ...]
    sequence_aliases: tuple[str, ...]
    sequence_length_aliases: tuple[str, ...]
    feature_aliases: Mapping[str, tuple[str, ...]]

    @classmethod
    def solar_default(cls) -> "ColumnAliasConfig":
        return cls(
            timestamp_aliases=(
                "timestamp_utc",
                "utc_timestamp",
                "timestamp",
            ),
            period_aliases=(
                "year_eastern",
                "year",
            ),
            sequence_aliases=(
                "analysis_sequence_id",
                "sequence_id",
                "contiguous_sequence_id",
            ),
            sequence_length_aliases=(
                "analysis_sequence_length",
                "sequence_length",
                "contiguous_sequence_length",
            ),
            feature_aliases={
                "B_avg": (
                    "solar_B_avg_nT",
                    "solar_B_avg",
                    "B_avg",
                    "b_avg",
                    "solar_b_avg_nt",
                ),
                "Bx": (
                    "solar_Bx_nT",
                    "solar_Bx",
                    "Bx",
                    "bx",
                    "solar_bx_nt",
                ),
                "Bz": (
                    "solar_Bz_GSE_nT",
                    "solar_Bz_nT",
                    "solar_Bz",
                    "Bz",
                    "bz",
                    "solar_bz_nt",
                ),
                "AE": (
                    "solar_AE_index_nT",
                    "solar_AE_nT",
                    "solar_AE",
                    "AE",
                    "ae",
                    "solar_ae_nt",
                ),
                "SYM_H": (
                    "solar_SYM_H_nT",
                    "solar_SYM-H_nT",
                    "solar_SYM-H",
                    "solar_SYM_H",
                    "SYM-H",
                    "SYM_H",
                    "sym_h",
                ),
            },
        )


@dataclass(frozen=True)
class AtlasIdentityConfig:
    """Identity and provenance of the atlas being qualified."""

    project_name: str
    milestone: str
    atlas_name: str
    atlas_version: str
    qualification_protocol_version: str
    dataset_name: str
    dataset_version: str
    representation_method: str
    representation_version: str
    random_seed: int

    @classmethod
    def solar_default(cls) -> "AtlasIdentityConfig":
        return cls(
            project_name="The Structural Intelligence Research Program",
            milestone="M1D",
            atlas_name="Solar Organizational Atlas",
            atlas_version="0.2",
            qualification_protocol_version="2.0.0",
            dataset_name="Goldilocks v2 — Core Solar Dataset B",
            dataset_version="analysis-ready",
            representation_method="Microstate-to-basin organizational atlas",
            representation_version="M2A-compatible-v2",
            random_seed=8275,
        )


# =============================================================================
# COMPUTATIONAL LIMITS
# =============================================================================

@dataclass(frozen=True)
class ComputationalConfig:
    """Runtime, sampling, and numerical limits."""

    overwrite_existing_outputs: bool = True
    kmeans_batch_size: int = 4096
    max_fit_states: int = 100_000
    max_silhouette_states: int = 20_000
    min_source_sequence_length: int = 20
    min_transition_count: int = 3
    bottleneck_top_fraction: float = 0.10
    n_jobs: int = 1
    cache_state_matrices: bool = True
    fail_fast: bool = False

    def validate(self) -> None:
        if self.kmeans_batch_size < 1:
            raise ValueError("kmeans_batch_size must be positive.")
        if self.max_fit_states < 100:
            raise ValueError("max_fit_states is implausibly small.")
        if self.max_silhouette_states < 100:
            raise ValueError("max_silhouette_states is implausibly small.")
        if self.min_source_sequence_length < 2:
            raise ValueError("min_source_sequence_length must be at least 2.")
        if self.min_transition_count < 1:
            raise ValueError("min_transition_count must be positive.")
        if not 0.0 < self.bottleneck_top_fraction <= 1.0:
            raise ValueError("bottleneck_top_fraction must be in (0, 1].")


# =============================================================================
# REVIEW-SPECIFIC CONFIGURATION
# =============================================================================

@dataclass(frozen=True)
class SeedReviewConfig:
    """Seed stability review settings."""

    seeds: tuple[int, ...]
    include_baseline_seed: bool = True
    report_pairwise_matrix: bool = True
    report_dominant_basin_stability: bool = True
    report_minor_basin_stability: bool = True
    occupancy_weighted_metrics: bool = True

    def validate(self) -> None:
        if len(self.seeds) < 2:
            raise ValueError("Seed review requires at least two seeds.")
        if len(set(self.seeds)) != len(self.seeds):
            raise ValueError("Seed list contains duplicates.")


@dataclass(frozen=True)
class ParameterReviewConfig:
    """One-factor-at-a-time parameter review settings."""

    n_microstates: tuple[int, ...]
    n_basins: tuple[int, ...]
    embedding_dimensions: tuple[int, ...]
    embedding_lags_minutes: tuple[int, ...]
    include_first_differences: tuple[bool, ...]
    one_factor_at_a_time: bool = True
    include_baseline: bool = True
    split_merge_aware_matching: bool = True
    occupancy_weighted_similarity: bool = True
    minimum_completed_fraction: float = 0.80

    def validate(self) -> None:
        if not self.n_microstates:
            raise ValueError("n_microstates sweep must not be empty.")
        if not self.n_basins:
            raise ValueError("n_basins sweep must not be empty.")
        if not self.embedding_dimensions:
            raise ValueError("embedding_dimensions sweep must not be empty.")
        if not self.embedding_lags_minutes:
            raise ValueError("embedding_lags_minutes sweep must not be empty.")
        if not self.include_first_differences:
            raise ValueError("include_first_differences sweep must not be empty.")
        if not 0.0 < self.minimum_completed_fraction <= 1.0:
            raise ValueError("minimum_completed_fraction must be in (0, 1].")


@dataclass(frozen=True)
class BootstrapConfig:
    """Bootstrap review settings."""

    strategy: BootstrapStrategy
    n_replicates: int
    target_block_length: int
    minimum_block_length: int
    maximum_block_length: int
    minimum_blocks_per_sequence: int
    preserve_sequence_identity: bool
    assign_new_sequence_ids: bool
    report_unavailable_as_not_evaluated: bool = True

    def validate(self) -> None:
        if self.n_replicates < 1:
            raise ValueError("n_replicates must be positive.")
        if self.minimum_block_length < 2:
            raise ValueError("minimum_block_length must be at least 2.")
        if self.maximum_block_length < self.minimum_block_length:
            raise ValueError(
                "maximum_block_length cannot be less than minimum_block_length."
            )
        if not self.minimum_block_length <= self.target_block_length <= self.maximum_block_length:
            raise ValueError(
                "target_block_length must lie within bootstrap block bounds."
            )
        if self.minimum_blocks_per_sequence < 1:
            raise ValueError("minimum_blocks_per_sequence must be positive.")


@dataclass(frozen=True)
class TemporalReviewConfig:
    """Temporal scaffold, transfer, occupancy, and novelty settings."""

    period_pairs: tuple[tuple[str, str], ...] = ()
    derive_period_pairs_from_data: bool = True
    evaluate_bidirectionally: bool = True
    compare_independent_test_atlas: bool = True
    evaluate_shared_scaffold: bool = True
    evaluate_coordinate_transfer: bool = True
    evaluate_occupancy_shift: bool = True
    evaluate_corridor_conservation: bool = True
    evaluate_novel_regions: bool = True
    minimum_states_per_period: int = 1_000
    novelty_minimum_occupancy: float = 0.005
    persistent_region_minimum_period_fraction: float = 0.75

    def validate(self) -> None:
        if self.minimum_states_per_period < 1:
            raise ValueError("minimum_states_per_period must be positive.")
        if not 0.0 <= self.novelty_minimum_occupancy <= 1.0:
            raise ValueError("novelty_minimum_occupancy must be in [0, 1].")
        if not 0.0 <= self.persistent_region_minimum_period_fraction <= 1.0:
            raise ValueError(
                "persistent_region_minimum_period_fraction must be in [0, 1]."
            )


@dataclass(frozen=True)
class NullModelConfig:
    """Configuration for one null-model family."""

    family: NullFamily
    enabled: bool
    n_replicates: int
    evaluate_independently: bool = True
    preserve_marginal_distribution: bool = False
    preserve_autocorrelation: bool = False
    preserve_cross_feature_dependence: bool = False
    notes: str = ""

    def validate(self) -> None:
        if self.enabled and self.n_replicates < 2:
            raise ValueError(
                f"Enabled null family {self.family.value} requires at least "
                "two replicates for effect-size estimation."
            )


@dataclass(frozen=True)
class NullReviewConfig:
    """Collection of independently evaluated null-model families."""

    families: tuple[NullModelConfig, ...]
    report_pooled_summary: bool = True
    pooled_summary_is_advisory_only: bool = True
    minimum_completed_fraction_per_family: float = 0.80

    def validate(self) -> None:
        enabled = [family for family in self.families if family.enabled]
        if not enabled:
            raise ValueError("At least one null family must be enabled.")
        if len({family.family for family in self.families}) != len(self.families):
            raise ValueError("Null families must be unique.")
        for family in self.families:
            family.validate()
        if not 0.0 < self.minimum_completed_fraction_per_family <= 1.0:
            raise ValueError(
                "minimum_completed_fraction_per_family must be in (0, 1]."
            )


@dataclass(frozen=True)
class OrganizationReviewConfig:
    """Organizational-level stability settings."""

    evaluate_neighborhoods: bool = True
    evaluate_transitions: bool = True
    evaluate_corridors: bool = True
    evaluate_bottlenecks: bool = True
    evaluate_topology: bool = True
    transition_similarity_metric: str = "weighted_jensen_shannon"
    topology_similarity_metric: str = "spectral_and_graph"
    corridor_minimum_count: int = 5
    minimum_recurrent_fraction: float = 0.50

    def validate(self) -> None:
        if self.corridor_minimum_count < 1:
            raise ValueError("corridor_minimum_count must be positive.")
        if not 0.0 <= self.minimum_recurrent_fraction <= 1.0:
            raise ValueError("minimum_recurrent_fraction must be in [0, 1].")


# =============================================================================
# THRESHOLDS AND QUALIFICATION POLICY
# =============================================================================

@dataclass(frozen=True)
class MetricThreshold:
    """Scientific support criterion for one metric."""

    metric_id: str
    phase_id: str
    display_name: str
    direction: MetricDirection
    threshold: float | tuple[float, float]
    severity: ThresholdSeverity
    weight: float
    minimum_evidence_count: int = 1
    recommendation_on_failure: RecommendationCode | None = None
    notes: str = ""

    def validate(self) -> None:
        if self.weight < 0.0:
            raise ValueError(f"Threshold weight cannot be negative: {self.metric_id}")
        if self.minimum_evidence_count < 1:
            raise ValueError(
                f"minimum_evidence_count must be positive: {self.metric_id}"
            )
        if self.direction == MetricDirection.BETWEEN:
            if (
                not isinstance(self.threshold, tuple)
                or len(self.threshold) != 2
                or self.threshold[0] > self.threshold[1]
            ):
                raise ValueError(
                    f"BETWEEN threshold must be an ordered pair: {self.metric_id}"
                )

    def is_supported(self, value: float | None) -> bool | None:
        if value is None:
            return None

        if self.direction == MetricDirection.GREATER_EQUAL:
            return float(value) >= float(self.threshold)
        if self.direction == MetricDirection.LESS_EQUAL:
            return float(value) <= float(self.threshold)

        lower, upper = self.threshold
        return float(lower) <= float(value) <= float(upper)


@dataclass(frozen=True)
class PhasePolicy:
    """Confidence and advancement policy for one qualification phase."""

    phase_id: str
    display_name: str
    phase_weight: float
    minimum_confidence_for_support: float
    minimum_evaluated_weight_fraction: float
    critical_metric_ids: tuple[str, ...] = ()

    def validate(self) -> None:
        if self.phase_weight < 0.0:
            raise ValueError("phase_weight cannot be negative.")
        if not 0.0 <= self.minimum_confidence_for_support <= 1.0:
            raise ValueError(
                "minimum_confidence_for_support must be in [0, 1]."
            )
        if not 0.0 < self.minimum_evaluated_weight_fraction <= 1.0:
            raise ValueError(
                "minimum_evaluated_weight_fraction must be in (0, 1]."
            )


@dataclass(frozen=True)
class MaturityRule:
    """Requirements for assigning an atlas qualification level."""

    level: QualificationLevel
    minimum_overall_confidence: float
    required_phase_statuses: Mapping[str, tuple[ReviewStatus, ...]]
    require_entitlement: bool
    maximum_unresolved_critical_concerns: int
    minimum_completed_phases: int

    def validate(self) -> None:
        if not 0.0 <= self.minimum_overall_confidence <= 1.0:
            raise ValueError(
                "minimum_overall_confidence must be in [0, 1]."
            )
        if self.maximum_unresolved_critical_concerns < 0:
            raise ValueError(
                "maximum_unresolved_critical_concerns cannot be negative."
            )
        if self.minimum_completed_phases < 0:
            raise ValueError("minimum_completed_phases cannot be negative.")


@dataclass(frozen=True)
class QualificationPolicy:
    """Full scientific policy for atlas qualification."""

    thresholds: tuple[MetricThreshold, ...]
    phase_policies: tuple[PhasePolicy, ...]
    maturity_rules: tuple[MaturityRule, ...]
    unavailable_critical_metric_blocks_qualification: bool = True
    concern_status_blocks_entitlement: bool = True
    preserve_manual_review: bool = True

    def validate(self) -> None:
        threshold_ids = [threshold.metric_id for threshold in self.thresholds]
        if len(set(threshold_ids)) != len(threshold_ids):
            raise ValueError("Metric threshold IDs must be unique.")

        phase_ids = [policy.phase_id for policy in self.phase_policies]
        if len(set(phase_ids)) != len(phase_ids):
            raise ValueError("Phase policy IDs must be unique.")

        for threshold in self.thresholds:
            threshold.validate()
        for policy in self.phase_policies:
            policy.validate()
        for rule in self.maturity_rules:
            rule.validate()

        known_phases = set(phase_ids)
        unknown = {
            threshold.phase_id
            for threshold in self.thresholds
            if threshold.phase_id not in known_phases
        }
        if unknown:
            raise ValueError(
                f"Thresholds reference unknown phases: {sorted(unknown)}"
            )

    def threshold_map(self) -> dict[str, MetricThreshold]:
        return {
            threshold.metric_id: threshold
            for threshold in self.thresholds
        }

    def phase_policy_map(self) -> dict[str, PhasePolicy]:
        return {
            policy.phase_id: policy
            for policy in self.phase_policies
        }


# =============================================================================
# OUTPUT CONFIGURATION
# =============================================================================

@dataclass(frozen=True)
class OutputConfig:
    """Publication and machine-readable output conventions."""

    write_machine_manifest: bool = True
    write_qualification_record: bool = True
    write_markdown_report: bool = True
    write_phase_reports: bool = True
    write_tables: bool = True
    write_figures: bool = True
    write_coordinate_table: bool = False
    include_raw_distributions_in_json: bool = False

    table_format: OutputFormat = OutputFormat.CSV
    report_format: OutputFormat = OutputFormat.MARKDOWN
    figure_formats: tuple[OutputFormat, ...] = (
        OutputFormat.PNG,
        OutputFormat.SVG,
    )

    figure_dpi: int = 300
    publication_figure_dpi: int = 600
    float_precision: int = 6
    one_page_record_name: str = "atlas_qualification_record"
    report_name: str = "atlas_qualification_report"
    manifest_name: str = "atlas_qualification_manifest"

    def validate(self) -> None:
        if self.figure_dpi < 72:
            raise ValueError("figure_dpi must be at least 72.")
        if self.publication_figure_dpi < self.figure_dpi:
            raise ValueError(
                "publication_figure_dpi cannot be less than figure_dpi."
            )
        if self.float_precision < 0:
            raise ValueError("float_precision cannot be negative.")


# =============================================================================
# COMPLETE PROTOCOL CONFIGURATION
# =============================================================================

@dataclass(frozen=True)
class QualificationProtocolConfig:
    """Complete immutable configuration for one qualification run."""

    mode: QualificationMode
    identity: AtlasIdentityConfig
    paths: PathConfig
    columns: ColumnAliasConfig
    baseline_representation: RepresentationConfig
    computational: ComputationalConfig
    seed_review: SeedReviewConfig
    parameter_review: ParameterReviewConfig
    bootstrap: BootstrapConfig
    organization_review: OrganizationReviewConfig
    temporal_review: TemporalReviewConfig
    null_review: NullReviewConfig
    qualification_policy: QualificationPolicy
    outputs: OutputConfig

    def validate(self) -> None:
        self.baseline_representation.validate()
        self.computational.validate()
        self.seed_review.validate()
        self.parameter_review.validate()
        self.bootstrap.validate()
        self.organization_review.validate()
        self.temporal_review.validate()
        self.null_review.validate()
        self.qualification_policy.validate()
        self.outputs.validate()

        if (
            self.baseline_representation.n_microstates
            not in self.parameter_review.n_microstates
        ):
            raise ValueError(
                "Baseline n_microstates must be included in parameter sweep."
            )
        if (
            self.baseline_representation.n_basins
            not in self.parameter_review.n_basins
        ):
            raise ValueError(
                "Baseline n_basins must be included in parameter sweep."
            )
        if (
            self.baseline_representation.embedding_dimension
            not in self.parameter_review.embedding_dimensions
        ):
            raise ValueError(
                "Baseline embedding_dimension must be included in parameter sweep."
            )
        if (
            self.baseline_representation.embedding_lag_minutes
            not in self.parameter_review.embedding_lags_minutes
        ):
            raise ValueError(
                "Baseline embedding_lag_minutes must be included in parameter sweep."
            )
        if (
            self.baseline_representation.include_first_differences
            not in self.parameter_review.include_first_differences
        ):
            raise ValueError(
                "Baseline differencing choice must be included in parameter sweep."
            )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-compatible protocol description."""
        raw = asdict(self)

        def convert(value: Any) -> Any:
            if isinstance(value, Enum):
                return value.value
            if isinstance(value, Path):
                return str(value)
            if isinstance(value, dict):
                return {
                    str(key): convert(item)
                    for key, item in value.items()
                }
            if isinstance(value, (list, tuple)):
                return [convert(item) for item in value]
            return value

        return convert(raw)

    def with_mode(self, mode: QualificationMode) -> "QualificationProtocolConfig":
        """Return the canonical quick or full protocol."""
        return build_protocol(mode=mode)


# =============================================================================
# DEFAULT POLICY
# =============================================================================

def default_thresholds() -> tuple[MetricThreshold, ...]:
    """
    Conservative initial qualification thresholds.

    These are protocol defaults, not immutable scientific constants. They should
    be versioned and reviewed before a formal publication run.
    """
    return (
        # Phase 1 — Representation
        MetricThreshold(
            metric_id="seed_median_aligned_ari",
            phase_id="phase1",
            display_name="Median aligned basin ARI across seeds",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.50,
            severity=ThresholdSeverity.CRITICAL,
            weight=1.25,
            minimum_evidence_count=3,
            recommendation_on_failure=RecommendationCode.REVISE_REPRESENTATION,
        ),
        MetricThreshold(
            metric_id="seed_dominant_basin_stability",
            phase_id="phase1",
            display_name="Dominant basin stability across seeds",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.80,
            severity=ThresholdSeverity.IMPORTANT,
            weight=1.00,
            minimum_evidence_count=3,
            recommendation_on_failure=RecommendationCode.INVESTIGATE_IMBALANCE,
        ),
        MetricThreshold(
            metric_id="seed_minor_basin_stability",
            phase_id="phase1",
            display_name="Minor basin stability across seeds",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.45,
            severity=ThresholdSeverity.IMPORTANT,
            weight=0.75,
            minimum_evidence_count=3,
            recommendation_on_failure=RecommendationCode.REFINE_PARAMETERS,
        ),
        MetricThreshold(
            metric_id="parameter_occupancy_weighted_similarity",
            phase_id="phase1",
            display_name="Occupancy-weighted parameter similarity",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.65,
            severity=ThresholdSeverity.CRITICAL,
            weight=1.25,
            minimum_evidence_count=4,
            recommendation_on_failure=RecommendationCode.REFINE_PARAMETERS,
        ),
        MetricThreshold(
            metric_id="parameter_split_merge_consistency",
            phase_id="phase1",
            display_name="Split/merge-aware parameter consistency",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.60,
            severity=ThresholdSeverity.IMPORTANT,
            weight=1.00,
            minimum_evidence_count=4,
            recommendation_on_failure=RecommendationCode.REFINE_PARAMETERS,
        ),
        MetricThreshold(
            metric_id="maximum_basin_occupancy",
            phase_id="phase1",
            display_name="Maximum single-basin occupancy",
            direction=MetricDirection.LESS_EQUAL,
            threshold=0.90,
            severity=ThresholdSeverity.IMPORTANT,
            weight=0.75,
            minimum_evidence_count=1,
            recommendation_on_failure=RecommendationCode.INVESTIGATE_IMBALANCE,
            notes=(
                "Values above this threshold do not prove collapse, but require "
                "explicit scientific review."
            ),
        ),
        MetricThreshold(
            metric_id="bootstrap_profile_similarity",
            phase_id="phase1",
            display_name="Median bootstrap profile similarity",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.65,
            severity=ThresholdSeverity.IMPORTANT,
            weight=1.00,
            minimum_evidence_count=5,
            recommendation_on_failure=RecommendationCode.REPAIR_BOOTSTRAP,
        ),

        # Phase 2 — Organization
        MetricThreshold(
            metric_id="transition_graph_similarity",
            phase_id="phase2",
            display_name="Transition graph similarity",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.65,
            severity=ThresholdSeverity.CRITICAL,
            weight=1.25,
            minimum_evidence_count=3,
            recommendation_on_failure=RecommendationCode.REVISE_REPRESENTATION,
        ),
        MetricThreshold(
            metric_id="corridor_recurrence_fraction",
            phase_id="phase2",
            display_name="Corridor recurrence fraction",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.50,
            severity=ThresholdSeverity.IMPORTANT,
            weight=1.00,
            minimum_evidence_count=3,
            recommendation_on_failure=RecommendationCode.REFINE_PARAMETERS,
        ),
        MetricThreshold(
            metric_id="bottleneck_recurrence_fraction",
            phase_id="phase2",
            display_name="Bottleneck recurrence fraction",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.50,
            severity=ThresholdSeverity.IMPORTANT,
            weight=1.00,
            minimum_evidence_count=3,
            recommendation_on_failure=RecommendationCode.REFINE_PARAMETERS,
        ),
        MetricThreshold(
            metric_id="topology_similarity",
            phase_id="phase2",
            display_name="Topology similarity",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.60,
            severity=ThresholdSeverity.CRITICAL,
            weight=1.25,
            minimum_evidence_count=3,
            recommendation_on_failure=RecommendationCode.REVISE_REPRESENTATION,
        ),

        # Phase 3 — Temporal
        MetricThreshold(
            metric_id="shared_scaffold_similarity",
            phase_id="phase3",
            display_name="Shared organizational scaffold similarity",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.60,
            severity=ThresholdSeverity.CRITICAL,
            weight=1.25,
            minimum_evidence_count=2,
            recommendation_on_failure=RecommendationCode.COLLECT_ADDITIONAL_PERIODS,
        ),
        MetricThreshold(
            metric_id="coordinate_transfer_similarity",
            phase_id="phase3",
            display_name="Coordinate transfer similarity",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.55,
            severity=ThresholdSeverity.IMPORTANT,
            weight=1.00,
            minimum_evidence_count=2,
            recommendation_on_failure=RecommendationCode.REVISE_REPRESENTATION,
        ),
        MetricThreshold(
            metric_id="corridor_conservation",
            phase_id="phase3",
            display_name="Temporal corridor conservation",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.50,
            severity=ThresholdSeverity.IMPORTANT,
            weight=0.75,
            minimum_evidence_count=2,
            recommendation_on_failure=RecommendationCode.COLLECT_ADDITIONAL_PERIODS,
        ),

        # Phase 4 — Nulls
        MetricThreshold(
            metric_id="null_minimum_persistence_effect_size",
            phase_id="phase4",
            display_name="Minimum persistence effect size across null families",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.50,
            severity=ThresholdSeverity.CRITICAL,
            weight=1.25,
            minimum_evidence_count=2,
            recommendation_on_failure=RecommendationCode.EXPAND_NULL_MODELS,
        ),
        MetricThreshold(
            metric_id="null_minimum_transition_concentration_effect_size",
            phase_id="phase4",
            display_name=(
                "Minimum transition-concentration effect size across null families"
            ),
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.50,
            severity=ThresholdSeverity.CRITICAL,
            weight=1.25,
            minimum_evidence_count=2,
            recommendation_on_failure=RecommendationCode.EXPAND_NULL_MODELS,
        ),
        MetricThreshold(
            metric_id="null_families_supported_fraction",
            phase_id="phase4",
            display_name="Fraction of independently supported null families",
            direction=MetricDirection.GREATER_EQUAL,
            threshold=0.75,
            severity=ThresholdSeverity.IMPORTANT,
            weight=1.00,
            minimum_evidence_count=3,
            recommendation_on_failure=RecommendationCode.EXPAND_NULL_MODELS,
        ),
    )


def default_phase_policies() -> tuple[PhasePolicy, ...]:
    return (
        PhasePolicy(
            phase_id="phase1",
            display_name="Representation Review",
            phase_weight=0.30,
            minimum_confidence_for_support=0.65,
            minimum_evaluated_weight_fraction=0.75,
            critical_metric_ids=(
                "seed_median_aligned_ari",
                "parameter_occupancy_weighted_similarity",
            ),
        ),
        PhasePolicy(
            phase_id="phase2",
            display_name="Organizational Review",
            phase_weight=0.30,
            minimum_confidence_for_support=0.65,
            minimum_evaluated_weight_fraction=0.75,
            critical_metric_ids=(
                "transition_graph_similarity",
                "topology_similarity",
            ),
        ),
        PhasePolicy(
            phase_id="phase3",
            display_name="Temporal Review",
            phase_weight=0.20,
            minimum_confidence_for_support=0.55,
            minimum_evaluated_weight_fraction=0.65,
            critical_metric_ids=("shared_scaffold_similarity",),
        ),
        PhasePolicy(
            phase_id="phase4",
            display_name="Null Review",
            phase_weight=0.20,
            minimum_confidence_for_support=0.70,
            minimum_evaluated_weight_fraction=0.75,
            critical_metric_ids=(
                "null_minimum_persistence_effect_size",
                "null_minimum_transition_concentration_effect_size",
            ),
        ),
    )


def default_maturity_rules() -> tuple[MaturityRule, ...]:
    """
    Rules are evaluated from most mature to least mature by the qualification
    engine. EXPLORATORY is the fallback level.
    """
    return (
        MaturityRule(
            level=QualificationLevel.REFERENCE,
            minimum_overall_confidence=0.90,
            required_phase_statuses={
                "phase1": (ReviewStatus.STRONGLY_SUPPORTED,),
                "phase2": (ReviewStatus.STRONGLY_SUPPORTED,),
                "phase3": (
                    ReviewStatus.SUPPORTED,
                    ReviewStatus.STRONGLY_SUPPORTED,
                ),
                "phase4": (ReviewStatus.STRONGLY_SUPPORTED,),
            },
            require_entitlement=True,
            maximum_unresolved_critical_concerns=0,
            minimum_completed_phases=4,
        ),
        MaturityRule(
            level=QualificationLevel.QUALIFIED,
            minimum_overall_confidence=0.75,
            required_phase_statuses={
                "phase1": (
                    ReviewStatus.SUPPORTED,
                    ReviewStatus.STRONGLY_SUPPORTED,
                ),
                "phase2": (
                    ReviewStatus.SUPPORTED,
                    ReviewStatus.STRONGLY_SUPPORTED,
                ),
                "phase3": (
                    ReviewStatus.SUPPORTED,
                    ReviewStatus.STRONGLY_SUPPORTED,
                ),
                "phase4": (
                    ReviewStatus.SUPPORTED,
                    ReviewStatus.STRONGLY_SUPPORTED,
                ),
            },
            require_entitlement=True,
            maximum_unresolved_critical_concerns=0,
            minimum_completed_phases=4,
        ),
        MaturityRule(
            level=QualificationLevel.EMERGING,
            minimum_overall_confidence=0.50,
            required_phase_statuses={
                "phase1": (
                    ReviewStatus.INCOMPLETE,
                    ReviewStatus.SUPPORTED,
                    ReviewStatus.STRONGLY_SUPPORTED,
                ),
                "phase2": (
                    ReviewStatus.INCOMPLETE,
                    ReviewStatus.SUPPORTED,
                    ReviewStatus.STRONGLY_SUPPORTED,
                ),
            },
            require_entitlement=False,
            maximum_unresolved_critical_concerns=2,
            minimum_completed_phases=2,
        ),
        MaturityRule(
            level=QualificationLevel.EXPLORATORY,
            minimum_overall_confidence=0.00,
            required_phase_statuses={},
            require_entitlement=False,
            maximum_unresolved_critical_concerns=999,
            minimum_completed_phases=0,
        ),
    )


def default_qualification_policy() -> QualificationPolicy:
    return QualificationPolicy(
        thresholds=default_thresholds(),
        phase_policies=default_phase_policies(),
        maturity_rules=default_maturity_rules(),
        unavailable_critical_metric_blocks_qualification=True,
        concern_status_blocks_entitlement=True,
        preserve_manual_review=True,
    )


# =============================================================================
# MODE BUILDERS
# =============================================================================

def _quick_seed_review() -> SeedReviewConfig:
    return SeedReviewConfig(
        seeds=(8275, 1009, 2024, 31415, 27182),
    )


def _full_seed_review() -> SeedReviewConfig:
    return SeedReviewConfig(
        seeds=(
            8275, 1009, 2024, 31415, 27182,
            73, 211, 509, 991, 1223,
            1667, 1999, 2381, 3001, 4001,
            5003, 6007, 7001, 8009, 9011,
        ),
    )


def _quick_parameter_review() -> ParameterReviewConfig:
    return ParameterReviewConfig(
        n_microstates=(72, 96, 128),
        n_basins=(10, 12, 14),
        embedding_dimensions=(2, 3, 4),
        embedding_lags_minutes=(1, 5),
        include_first_differences=(False, True),
    )


def _full_parameter_review() -> ParameterReviewConfig:
    return ParameterReviewConfig(
        n_microstates=(48, 72, 96, 128),
        n_basins=(6, 8, 10, 12, 14, 16),
        embedding_dimensions=(2, 3, 4, 5),
        embedding_lags_minutes=(1, 5, 15),
        include_first_differences=(False, True),
    )


def _quick_bootstrap() -> BootstrapConfig:
    return BootstrapConfig(
        strategy=BootstrapStrategy.ADAPTIVE_CONTIGUOUS_BLOCK,
        n_replicates=8,
        target_block_length=1_440,
        minimum_block_length=60,
        maximum_block_length=1_440,
        minimum_blocks_per_sequence=2,
        preserve_sequence_identity=False,
        assign_new_sequence_ids=True,
        report_unavailable_as_not_evaluated=True,
    )


def _full_bootstrap() -> BootstrapConfig:
    return BootstrapConfig(
        strategy=BootstrapStrategy.ADAPTIVE_CONTIGUOUS_BLOCK,
        n_replicates=30,
        target_block_length=1_440,
        minimum_block_length=60,
        maximum_block_length=1_440,
        minimum_blocks_per_sequence=3,
        preserve_sequence_identity=False,
        assign_new_sequence_ids=True,
        report_unavailable_as_not_evaluated=True,
    )


def _null_review(replicates: int) -> NullReviewConfig:
    return NullReviewConfig(
        families=(
            NullModelConfig(
                family=NullFamily.FULL_TIME_SHUFFLE,
                enabled=True,
                n_replicates=replicates,
                preserve_marginal_distribution=True,
                notes="Destroys temporal and cross-feature row order.",
            ),
            NullModelConfig(
                family=NullFamily.WITHIN_FEATURE_SHUFFLE,
                enabled=True,
                n_replicates=replicates,
                preserve_marginal_distribution=True,
                notes="Preserves each feature marginal independently.",
            ),
            NullModelConfig(
                family=NullFamily.SEQUENCE_ORDER_SHUFFLE,
                enabled=True,
                n_replicates=replicates,
                preserve_marginal_distribution=True,
                notes="Destroys within-sequence order while preserving sequence membership.",
            ),
            NullModelConfig(
                family=NullFamily.PHASE_RANDOMIZED,
                enabled=True,
                n_replicates=replicates,
                preserve_marginal_distribution=False,
                preserve_autocorrelation=True,
                notes=(
                    "Preserves approximate univariate power spectra; must be "
                    "reviewed independently rather than pooled."
                ),
            ),
            NullModelConfig(
                family=NullFamily.WHITE_NOISE,
                enabled=True,
                n_replicates=replicates,
                notes="Matched feature moments without temporal structure.",
            ),
            NullModelConfig(
                family=NullFamily.RANDOM_WALK,
                enabled=True,
                n_replicates=replicates,
                preserve_autocorrelation=True,
                notes="Nonstationary surrogate with generic path dependence.",
            ),
        ),
        report_pooled_summary=True,
        pooled_summary_is_advisory_only=True,
        minimum_completed_fraction_per_family=0.80,
    )


def build_protocol(
    mode: QualificationMode | str = QualificationMode.QUICK,
    *,
    paths: PathConfig | None = None,
    identity: AtlasIdentityConfig | None = None,
    columns: ColumnAliasConfig | None = None,
) -> QualificationProtocolConfig:
    """Build and validate the canonical qualification protocol."""

    mode = QualificationMode(mode)
    identity = identity or AtlasIdentityConfig.solar_default()
    paths = paths or PathConfig.solar_default()
    columns = columns or ColumnAliasConfig.solar_default()

    baseline = RepresentationConfig(
        include_first_differences=True,
        embedding_dimension=3,
        embedding_lag_minutes=1,
        n_microstates=96,
        n_basins=12,
    )

    if mode == QualificationMode.QUICK:
        seed_review = _quick_seed_review()
        parameter_review = _quick_parameter_review()
        bootstrap = _quick_bootstrap()
        null_review = _null_review(replicates=3)
    else:
        seed_review = _full_seed_review()
        parameter_review = _full_parameter_review()
        bootstrap = _full_bootstrap()
        null_review = _null_review(replicates=10)

    protocol = QualificationProtocolConfig(
        mode=mode,
        identity=identity,
        paths=paths,
        columns=columns,
        baseline_representation=baseline,
        computational=ComputationalConfig(),
        seed_review=seed_review,
        parameter_review=parameter_review,
        bootstrap=bootstrap,
        organization_review=OrganizationReviewConfig(),
        temporal_review=TemporalReviewConfig(),
        null_review=null_review,
        qualification_policy=default_qualification_policy(),
        outputs=OutputConfig(),
    )
    protocol.validate()
    return protocol


# =============================================================================
# PUBLIC DEFAULTS
# =============================================================================

QUICK_PROTOCOL = build_protocol(QualificationMode.QUICK)
FULL_PROTOCOL = build_protocol(QualificationMode.FULL)

# The main driver can import ACTIVE_PROTOCOL and change only this one line.
ACTIVE_PROTOCOL = QUICK_PROTOCOL


# =============================================================================
# SMALL UTILITY FUNCTIONS
# =============================================================================

def parameter_configs(
    protocol: QualificationProtocolConfig,
) -> tuple[RepresentationConfig, ...]:
    """
    Generate one-factor-at-a-time representation configurations.

    The baseline is always included once.
    """
    baseline = protocol.baseline_representation
    sweep = protocol.parameter_review

    configs: dict[str, RepresentationConfig] = {
        baseline.config_id: baseline
    }

    fields_and_values = (
        ("n_microstates", sweep.n_microstates),
        ("n_basins", sweep.n_basins),
        ("embedding_dimension", sweep.embedding_dimensions),
        ("embedding_lag_minutes", sweep.embedding_lags_minutes),
        (
            "include_first_differences",
            sweep.include_first_differences,
        ),
    )

    for field_name, values in fields_and_values:
        for value in values:
            candidate = replace(baseline, **{field_name: value})
            candidate.validate()
            configs[candidate.config_id] = candidate

    return tuple(configs.values())


def enabled_null_families(
    protocol: QualificationProtocolConfig,
) -> tuple[NullModelConfig, ...]:
    """Return enabled null-model configurations."""
    return tuple(
        family
        for family in protocol.null_review.families
        if family.enabled
    )


def protocol_summary(
    protocol: QualificationProtocolConfig,
) -> dict[str, Any]:
    """Return a compact human-readable protocol summary."""
    return {
        "mode": protocol.mode.value,
        "atlas_name": protocol.identity.atlas_name,
        "atlas_version": protocol.identity.atlas_version,
        "qualification_protocol_version": (
            protocol.identity.qualification_protocol_version
        ),
        "baseline_config_id": (
            protocol.baseline_representation.config_id
        ),
        "n_seed_runs": len(protocol.seed_review.seeds),
        "n_parameter_configs": len(parameter_configs(protocol)),
        "n_bootstrap_replicates": protocol.bootstrap.n_replicates,
        "null_families": [
            {
                "family": family.family.value,
                "n_replicates": family.n_replicates,
            }
            for family in enabled_null_families(protocol)
        ],
        "phase_weights": {
            policy.phase_id: policy.phase_weight
            for policy in protocol.qualification_policy.phase_policies
        },
        "input_file": str(protocol.paths.input_file),
        "output_dir": str(protocol.paths.output_dir),
    }


if __name__ == "__main__":
    import json

    print(json.dumps(protocol_summary(ACTIVE_PROTOCOL), indent=2))
