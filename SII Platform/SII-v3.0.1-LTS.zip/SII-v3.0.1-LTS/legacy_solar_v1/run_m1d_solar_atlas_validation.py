#!/usr/bin/env python3
"""
The Structural Intelligence Research Program
M1D — Solar Organizational Atlas Validation
============================================

Objective
---------
Determine whether the Solar Organizational Atlas is reproducible, transferable,
and distinguishable from plausible null models.

This script reuses the representation logic introduced in M2A and evaluates:

    1. Seed stability
    2. Parameter stability
    3. Temporal transfer
    4. Block-bootstrap reproducibility
    5. Null-model separation
    6. Bottleneck recurrence
    7. Representation entitlement

Scientific guardrail
--------------------
The script does not test solar-market correspondence and does not assign physical
meaning to organizational regimes. It tests whether the inferred organization is
stable enough to support later interpretation.

Recommended use
---------------
Start with VALIDATION_MODE = "quick". After confirming the pipeline and runtime,
change it to "full" for the formal validation run.
"""

from __future__ import annotations

import json
import logging
import math
import sys
import warnings
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import networkx as nx
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import AgglomerativeClustering, MiniBatchKMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import RobustScaler

warnings.filterwarnings("ignore", category=RuntimeWarning)


# =============================================================================
# INLINE CONFIGURATION
# =============================================================================

PROJECT_NAME = "The Structural Intelligence Research Program"
MILESTONE = "M1D"
DESCRIPTION = "Solar Organizational Atlas Validation"

ROOT = Path("data") / "Goldilocks v2"
INPUT_FILE = ROOT / "ANALYSIS_READY" / "dataset_B_core_solar_all.csv.gz"
OUTPUT_DIR = ROOT / "M1_SOLAR_ATLAS" / "M1D_VALIDATION"
REPORT_DIR = OUTPUT_DIR / "REPORTS"
TABLE_DIR = OUTPUT_DIR / "TABLES"

OVERWRITE_EXISTING_OUTPUTS = True
RANDOM_SEED = 8275

# "quick" is appropriate for pipeline qualification.
# "full" is appropriate for the formal scientific run.
VALIDATION_MODE = "quick"

TIMESTAMP_ALIASES = ["timestamp_utc", "utc_timestamp", "timestamp"]
YEAR_ALIASES = ["year_eastern", "year"]
SEQUENCE_ALIASES = [
    "analysis_sequence_id",
    "sequence_id",
    "contiguous_sequence_id",
]
SEQUENCE_LENGTH_ALIASES = [
    "analysis_sequence_length",
    "sequence_length",
    "contiguous_sequence_length",
]

FEATURE_ALIASES = {
    "B_avg": [
        "solar_B_avg_nT", "solar_B_avg", "B_avg", "b_avg", "solar_b_avg_nt"
    ],
    "Bx": [
        "solar_Bx_nT", "solar_Bx", "Bx", "bx", "solar_bx_nt"
    ],
    "Bz": [
        "solar_Bz_GSE_nT", "solar_Bz_nT", "solar_Bz", "Bz", "bz",
        "solar_bz_nt"
    ],
    "AE": [
        "solar_AE_index_nT", "solar_AE_nT", "solar_AE", "AE", "ae",
        "solar_ae_nt"
    ],
    "SYM_H": [
        "solar_SYM_H_nT", "solar_SYM-H_nT", "solar_SYM-H", "solar_SYM_H",
        "SYM-H", "SYM_H", "sym_h"
    ],
}

# Baseline atlas representation inherited from M2A.
BASELINE = {
    "include_first_differences": True,
    "embedding_dimension": 3,
    "embedding_lag_minutes": 1,
    "n_microstates": 96,
    "n_basins": 12,
}

MIN_SOURCE_SEQUENCE_LENGTH = 20
KMEANS_BATCH_SIZE = 4096
MAX_FIT_STATES = 100_000
MAX_SILHOUETTE_STATES = 20_000
MIN_TRANSITION_COUNT = 3
BOTTLENECK_TOP_FRACTION = 0.10

if VALIDATION_MODE == "quick":
    SEED_LIST = [8275, 1009, 2024, 31415, 27182]
    PARAMETER_GRID = {
        "n_microstates": [72, 96, 128],
        "n_basins": [10, 12, 14],
        "embedding_dimension": [2, 3, 4],
        "embedding_lag_minutes": [1, 5],
        "include_first_differences": [False, True],
    }
    N_BOOTSTRAPS = 8
    BLOCK_LENGTH = 1_440       # one day at one-minute cadence
    NULL_REPLICATES = 3
else:
    SEED_LIST = [
        8275, 1009, 2024, 31415, 27182, 73, 211, 509, 991, 1223,
        1667, 1999, 2381, 3001, 4001, 5003, 6007, 7001, 8009, 9011,
    ]
    PARAMETER_GRID = {
        "n_microstates": [48, 72, 96, 128],
        "n_basins": [6, 8, 10, 12, 14, 16],
        "embedding_dimension": [2, 3, 4, 5],
        "embedding_lag_minutes": [1, 5, 15],
        "include_first_differences": [False, True],
    }
    N_BOOTSTRAPS = 30
    BLOCK_LENGTH = 1_440
    NULL_REPLICATES = 10

# Pre-declared qualification thresholds.
# These are intentionally conservative starting values and should be reviewed
# before the final formal run.
THRESHOLDS = {
    "median_seed_aligned_ari": 0.50,
    "median_parameter_profile_similarity": 0.70,
    "median_temporal_transfer_profile_similarity": 0.65,
    "median_bootstrap_profile_similarity": 0.65,
    "null_effect_size_persistence": 0.50,
    "null_effect_size_transition_concentration": 0.50,
    "bottleneck_recurrence_fraction": 0.50,
}

# Overall status:
# QUALIFIED requires all critical tests.
# PROVISIONALLY QUALIFIED requires at least 5 of 7 tests and no severe failure.
CRITICAL_TESTS = {
    "seed_stability",
    "temporal_transfer",
    "null_persistence",
}


# =============================================================================
# UTILITIES
# =============================================================================

def configure_logging(path: Path) -> logging.Logger:
    logger = logging.getLogger("m1d")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, mode="w", encoding="utf-8")
    file_handler.setFormatter(formatter)

    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def resolve_column(
    columns: list[str],
    aliases: list[str],
    required: bool = True,
) -> str | None:
    lookup = {c.lower(): c for c in columns}
    for alias in aliases:
        if alias.lower() in lookup:
            return lookup[alias.lower()]
    if required:
        raise ValueError(
            f"Could not resolve any of {aliases}. Available columns: {columns}"
        )
    return None


def resolve_feature_columns(df: pd.DataFrame) -> dict[str, str]:
    return {
        canonical: resolve_column(list(df.columns), aliases, required=True)
        for canonical, aliases in FEATURE_ALIASES.items()
    }


def safe_float(value: Any) -> float | None:
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except Exception:
        return None


def write_csv(df: pd.DataFrame, path: Path) -> None:
    if path.exists() and not OVERWRITE_EXISTING_OUTPUTS:
        raise FileExistsError(path)
    df.to_csv(path, index=False)


def entropy_from_probabilities(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[(values > 0) & np.isfinite(values)]
    if len(values) == 0:
        return 0.0
    values = values / values.sum()
    return float(-(values * np.log2(values)).sum())


def cohen_d(real: Iterable[float], null: Iterable[float]) -> float | None:
    real = np.asarray(list(real), dtype=float)
    null = np.asarray(list(null), dtype=float)
    real = real[np.isfinite(real)]
    null = null[np.isfinite(null)]
    if len(real) < 2 or len(null) < 2:
        return None
    pooled = math.sqrt(
        ((len(real) - 1) * real.var(ddof=1) + (len(null) - 1) * null.var(ddof=1))
        / max(1, len(real) + len(null) - 2)
    )
    if pooled == 0:
        return 0.0
    return float((real.mean() - null.mean()) / pooled)


# =============================================================================
# DATA PREPARATION
# =============================================================================

@dataclass(frozen=True)
class ColumnMap:
    timestamp: str
    year: str
    sequence: str
    sequence_length: str | None
    features: dict[str, str]


@dataclass(frozen=True)
class RepresentationConfig:
    include_first_differences: bool
    embedding_dimension: int
    embedding_lag_minutes: int
    n_microstates: int
    n_basins: int

    @property
    def config_id(self) -> str:
        diff = "diff" if self.include_first_differences else "level"
        return (
            f"micro{self.n_microstates}_basin{self.n_basins}_"
            f"dim{self.embedding_dimension}_lag{self.embedding_lag_minutes}_{diff}"
        )


@dataclass
class StructuralModel:
    scaler: RobustScaler
    microstate_model: MiniBatchKMeans
    basin_model: AgglomerativeClustering
    microstate_to_basin: np.ndarray
    config: RepresentationConfig


def load_data(path: Path) -> tuple[pd.DataFrame, ColumnMap]:
    if not path.exists():
        raise FileNotFoundError(
            f"Input file not found: {path}\n"
            "Edit INPUT_FILE near the top of the script if needed."
        )

    df = pd.read_csv(path, low_memory=False)
    columns = list(df.columns)

    cmap = ColumnMap(
        timestamp=resolve_column(columns, TIMESTAMP_ALIASES),
        year=resolve_column(columns, YEAR_ALIASES),
        sequence=resolve_column(columns, SEQUENCE_ALIASES),
        sequence_length=resolve_column(
            columns, SEQUENCE_LENGTH_ALIASES, required=False
        ),
        features=resolve_feature_columns(df),
    )

    df[cmap.timestamp] = pd.to_datetime(df[cmap.timestamp], utc=True, errors="coerce")
    df[cmap.year] = pd.to_numeric(df[cmap.year], errors="coerce")
    df[cmap.sequence] = pd.to_numeric(df[cmap.sequence], errors="coerce")

    for col in cmap.features.values():
        df[col] = pd.to_numeric(df[col], errors="coerce")

    required = [cmap.timestamp, cmap.year, cmap.sequence, *cmap.features.values()]
    df = df.dropna(subset=required).copy()
    df.sort_values([cmap.year, cmap.sequence, cmap.timestamp], inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df, cmap


def build_state_matrix(
    df: pd.DataFrame,
    cmap: ColumnMap,
    config: RepresentationConfig,
) -> tuple[pd.DataFrame, np.ndarray, list[str]]:
    metadata_rows: list[dict[str, Any]] = []
    state_rows: list[np.ndarray] = []

    feature_names = list(cmap.features.keys())
    base_cols = [cmap.features[name] for name in feature_names]

    representation_names = feature_names.copy()
    if config.include_first_differences:
        representation_names += [f"d_{name}" for name in feature_names]

    embedded_names: list[str] = []
    for lag_index in range(config.embedding_dimension):
        suffix = f"t-{lag_index * config.embedding_lag_minutes}"
        embedded_names.extend(
            [f"{name}_{suffix}" for name in representation_names]
        )

    required_history = (
        config.embedding_dimension - 1
    ) * config.embedding_lag_minutes

    for (year, seq_id), group in df.groupby(
        [cmap.year, cmap.sequence], sort=False
    ):
        group = group.sort_values(cmap.timestamp).reset_index(drop=True)
        minimum = max(MIN_SOURCE_SEQUENCE_LENGTH, required_history + 2)
        if len(group) < minimum:
            continue

        base = group[base_cols].to_numpy(dtype=float)
        rep = base

        if config.include_first_differences:
            diffs = np.vstack(
                [np.full((1, base.shape[1]), np.nan), np.diff(base, axis=0)]
            )
            rep = np.hstack([base, diffs])

        for t in range(required_history, len(group)):
            indices = [
                t - j * config.embedding_lag_minutes
                for j in range(config.embedding_dimension)
            ]
            state = np.concatenate([rep[idx] for idx in indices])
            if not np.isfinite(state).all():
                continue

            state_rows.append(state)
            metadata_rows.append(
                {
                    "year": int(year),
                    "sequence_id": int(seq_id),
                    "sequence_position": int(t),
                    "timestamp_utc": group.at[t, cmap.timestamp],
                }
            )

    if not state_rows:
        raise RuntimeError(
            f"No valid states were constructed for {config.config_id}."
        )

    return pd.DataFrame(metadata_rows), np.vstack(state_rows), embedded_names


# =============================================================================
# STRUCTURAL REPRESENTATION
# =============================================================================

def fit_structural_model(
    states: np.ndarray,
    config: RepresentationConfig,
    seed: int,
) -> tuple[StructuralModel, np.ndarray]:
    rng = np.random.default_rng(seed)

    scaler = RobustScaler(quantile_range=(10.0, 90.0))
    scaled = scaler.fit_transform(states)

    if len(scaled) > MAX_FIT_STATES:
        fit_idx = rng.choice(len(scaled), size=MAX_FIT_STATES, replace=False)
        fit_states = scaled[fit_idx]
    else:
        fit_states = scaled

    micro = MiniBatchKMeans(
        n_clusters=config.n_microstates,
        random_state=seed,
        batch_size=KMEANS_BATCH_SIZE,
        n_init=10,
        reassignment_ratio=0.01,
    )
    micro.fit(fit_states)
    micro_labels = micro.predict(scaled)

    basin = AgglomerativeClustering(
        n_clusters=config.n_basins,
        linkage="ward",
    )
    micro_to_basin = basin.fit_predict(micro.cluster_centers_)
    basin_labels = micro_to_basin[micro_labels]

    model = StructuralModel(
        scaler=scaler,
        microstate_model=micro,
        basin_model=basin,
        microstate_to_basin=micro_to_basin,
        config=config,
    )
    return model, np.column_stack([micro_labels, basin_labels])


def assign_with_model(
    states: np.ndarray,
    model: StructuralModel,
) -> np.ndarray:
    scaled = model.scaler.transform(states)
    micro_labels = model.microstate_model.predict(scaled)
    basin_labels = model.microstate_to_basin[micro_labels]
    return np.column_stack([micro_labels, basin_labels])


def build_assignments(
    metadata: pd.DataFrame,
    labels: np.ndarray,
    original_df: pd.DataFrame,
    cmap: ColumnMap,
) -> pd.DataFrame:
    assignments = metadata.copy()
    assignments["microstate_id"] = labels[:, 0]
    assignments["basin_id"] = labels[:, 1]

    lookup = (
        original_df
        .drop_duplicates(subset=[cmap.timestamp])
        .set_index(cmap.timestamp)
    )
    for canonical, col in cmap.features.items():
        assignments[canonical] = assignments["timestamp_utc"].map(lookup[col])
    return assignments


# =============================================================================
# STRUCTURAL SUMMARIES
# =============================================================================

def build_transition_table(
    assignments: pd.DataFrame,
    level_col: str,
) -> pd.DataFrame:
    rows: list[tuple[int, int, int]] = []

    for (year, seq_id), group in assignments.groupby(
        ["year", "sequence_id"], sort=False
    ):
        group = group.sort_values("sequence_position")
        values = group[level_col].to_numpy()
        if len(values) < 2:
            continue
        for source, target in zip(values[:-1], values[1:]):
            rows.append((int(year), int(source), int(target)))

    trans = pd.DataFrame(rows, columns=["year", "source", "target"])
    if trans.empty:
        return trans

    counts = (
        trans.groupby(["year", "source", "target"])
        .size()
        .rename("count")
        .reset_index()
    )
    totals = counts.groupby(["year", "source"])["count"].transform("sum")
    counts["probability"] = counts["count"] / totals
    return counts


def graph_from_transitions(transitions: pd.DataFrame) -> nx.DiGraph:
    graph = nx.DiGraph()
    if transitions.empty:
        return graph

    combined = (
        transitions.groupby(["source", "target"])["count"]
        .sum()
        .reset_index()
    )
    for row in combined.itertuples(index=False):
        if int(row.count) >= MIN_TRANSITION_COUNT:
            graph.add_edge(
                int(row.source),
                int(row.target),
                weight=int(row.count),
                distance=1.0 / max(1, int(row.count)),
            )
    return graph


def basin_profiles(
    assignments: pd.DataFrame,
    feature_names: list[str],
) -> pd.DataFrame:
    profiles = (
        assignments.groupby("basin_id")[feature_names]
        .agg(["mean", "median", "std"])
    )
    profiles.columns = [
        f"{feature}_{stat}" for feature, stat in profiles.columns
    ]
    return profiles.reset_index()


def basin_metrics(
    assignments: pd.DataFrame,
    transitions: pd.DataFrame,
) -> pd.DataFrame:
    rows = []
    total = len(assignments)

    for basin_id, group in assignments.groupby("basin_id"):
        outgoing = transitions.loc[transitions["source"].eq(basin_id)]
        self_prob = outgoing.loc[
            outgoing["target"].eq(basin_id), "probability"
        ].sum()
        probs = outgoing["probability"].to_numpy(dtype=float)
        rows.append(
            {
                "basin_id": int(basin_id),
                "n_observations": int(len(group)),
                "fraction_observations": float(len(group) / total),
                "self_transition_probability": float(self_prob),
                "outgoing_transition_entropy_bits": entropy_from_probabilities(probs),
                "mean_dwell_proxy": (
                    float(1.0 / max(1e-12, 1.0 - self_prob))
                    if self_prob < 1.0 else None
                ),
            }
        )
    return pd.DataFrame(rows)


def top_bottlenecks(transitions: pd.DataFrame) -> pd.DataFrame:
    graph = graph_from_transitions(transitions)
    if graph.number_of_nodes() <= 1:
        return pd.DataFrame(
            columns=["source", "target", "edge_betweenness", "is_top_bottleneck"]
        )

    undirected = graph.to_undirected()
    edge_bw = nx.edge_betweenness_centrality(
        undirected, weight="distance"
    )
    rows = [
        {
            "source": int(edge[0]),
            "target": int(edge[1]),
            "edge_betweenness": float(score),
        }
        for edge, score in edge_bw.items()
    ]
    table = pd.DataFrame(rows).sort_values(
        "edge_betweenness", ascending=False
    )
    cutoff = max(
        1, int(math.ceil(len(table) * BOTTLENECK_TOP_FRACTION))
    )
    table["is_top_bottleneck"] = False
    table.iloc[:cutoff, table.columns.get_loc("is_top_bottleneck")] = True
    return table


def transition_concentration(transitions: pd.DataFrame) -> float:
    if transitions.empty:
        return 0.0
    combined = (
        transitions.groupby(["source", "target"])["count"]
        .sum()
        .reset_index()
    )
    counts = combined["count"].to_numpy(dtype=float)
    probs = counts / counts.sum()
    return float(np.square(probs).sum())


def summarize_run(
    assignments: pd.DataFrame,
    scaled_states: np.ndarray,
    labels: np.ndarray,
    feature_names: list[str],
    sample_seed: int,
) -> dict[str, Any]:
    transitions = build_transition_table(assignments, "basin_id")
    metrics = basin_metrics(assignments, transitions)
    profiles = basin_profiles(assignments, feature_names)

    rng = np.random.default_rng(sample_seed)
    if len(scaled_states) > MAX_SILHOUETTE_STATES:
        idx = rng.choice(
            len(scaled_states),
            MAX_SILHOUETTE_STATES,
            replace=False,
        )
    else:
        idx = np.arange(len(scaled_states))

    silhouette = None
    try:
        silhouette = float(
            silhouette_score(
                scaled_states[idx],
                labels[idx, 1],
                metric="euclidean",
            )
        )
    except Exception:
        pass

    return {
        "transitions": transitions,
        "metrics": metrics,
        "profiles": profiles,
        "bottlenecks": top_bottlenecks(transitions),
        "silhouette": silhouette,
        "mean_persistence": safe_float(
            metrics["self_transition_probability"].mean()
        ),
        "transition_concentration": transition_concentration(transitions),
    }


# =============================================================================
# LABEL ALIGNMENT AND COMPARISON
# =============================================================================

def profile_matrix(
    profiles: pd.DataFrame,
    feature_names: list[str],
) -> tuple[np.ndarray, np.ndarray]:
    cols = [f"{feature}_mean" for feature in feature_names]
    matrix = profiles[cols].to_numpy(dtype=float)
    ids = profiles["basin_id"].to_numpy(dtype=int)

    center = np.nanmedian(matrix, axis=0)
    scale = np.nanmedian(np.abs(matrix - center), axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    normalized = (matrix - center) / scale
    return ids, normalized


def align_profiles(
    reference_profiles: pd.DataFrame,
    candidate_profiles: pd.DataFrame,
    feature_names: list[str],
) -> tuple[dict[int, int], float]:
    ref_ids, ref = profile_matrix(reference_profiles, feature_names)
    cand_ids, cand = profile_matrix(candidate_profiles, feature_names)

    # Euclidean cost between normalized regime profiles.
    cost = np.linalg.norm(ref[:, None, :] - cand[None, :, :], axis=2)
    row_ind, col_ind = linear_sum_assignment(cost)

    mapping = {
        int(cand_ids[c]): int(ref_ids[r])
        for r, c in zip(row_ind, col_ind)
    }
    similarity = np.exp(-cost[row_ind, col_ind])
    return mapping, float(np.mean(similarity))


def aligned_ari(
    reference_labels: np.ndarray,
    candidate_labels: np.ndarray,
    mapping: dict[int, int],
) -> float:
    mapped = np.array(
        [mapping.get(int(label), -1) for label in candidate_labels],
        dtype=int,
    )
    valid = mapped >= 0
    if valid.sum() < 2:
        return float("nan")
    return float(adjusted_rand_score(reference_labels[valid], mapped[valid]))


def aligned_edge_set(
    bottlenecks: pd.DataFrame,
    mapping: dict[int, int] | None = None,
) -> set[tuple[int, int]]:
    if bottlenecks.empty:
        return set()

    top = bottlenecks.loc[bottlenecks["is_top_bottleneck"]]
    edges: set[tuple[int, int]] = set()
    for row in top.itertuples(index=False):
        a, b = int(row.source), int(row.target)
        if mapping is not None:
            if a not in mapping or b not in mapping:
                continue
            a, b = mapping[a], mapping[b]
        edges.add(tuple(sorted((a, b))))
    return edges


# =============================================================================
# VALIDATION TESTS
# =============================================================================

def seed_stability_test(
    states: np.ndarray,
    metadata: pd.DataFrame,
    original_df: pd.DataFrame,
    cmap: ColumnMap,
    config: RepresentationConfig,
    feature_names: list[str],
    logger: logging.Logger,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    logger.info("Running seed stability test")

    primary_model, primary_labels = fit_structural_model(
        states, config, RANDOM_SEED
    )
    primary_assignments = build_assignments(
        metadata, primary_labels, original_df, cmap
    )
    primary_summary = summarize_run(
        primary_assignments,
        primary_model.scaler.transform(states),
        primary_labels,
        feature_names,
        RANDOM_SEED,
    )

    primary_edges = aligned_edge_set(primary_summary["bottlenecks"])
    rows = []

    for seed in SEED_LIST:
        model, labels = fit_structural_model(states, config, seed)
        assignments = build_assignments(
            metadata, labels, original_df, cmap
        )
        summary = summarize_run(
            assignments,
            model.scaler.transform(states),
            labels,
            feature_names,
            seed,
        )

        mapping, profile_similarity = align_profiles(
            primary_summary["profiles"],
            summary["profiles"],
            feature_names,
        )
        ari = aligned_ari(
            primary_labels[:, 1],
            labels[:, 1],
            mapping,
        )
        candidate_edges = aligned_edge_set(
            summary["bottlenecks"], mapping
        )
        edge_recurrence = (
            len(primary_edges & candidate_edges) / max(1, len(primary_edges))
        )

        rows.append(
            {
                "seed": seed,
                "aligned_basin_ari": ari,
                "profile_similarity": profile_similarity,
                "bottleneck_recurrence_fraction": edge_recurrence,
                "mean_persistence": summary["mean_persistence"],
                "transition_concentration": summary["transition_concentration"],
                "silhouette_basin": summary["silhouette"],
            }
        )

    result = pd.DataFrame(rows)
    aggregate = {
        "median_aligned_ari": safe_float(
            result["aligned_basin_ari"].median()
        ),
        "median_profile_similarity": safe_float(
            result["profile_similarity"].median()
        ),
        "median_bottleneck_recurrence": safe_float(
            result["bottleneck_recurrence_fraction"].median()
        ),
    }
    return result, aggregate


def generate_parameter_configs() -> list[RepresentationConfig]:
    base = RepresentationConfig(**BASELINE)
    configs = {base.config_id: base}

    # One-factor-at-a-time sensitivity around the baseline.
    for key, values in PARAMETER_GRID.items():
        for value in values:
            params = dict(BASELINE)
            params[key] = value
            config = RepresentationConfig(**params)
            configs[config.config_id] = config

    return list(configs.values())


def parameter_stability_test(
    df: pd.DataFrame,
    cmap: ColumnMap,
    baseline_profiles: pd.DataFrame,
    feature_names: list[str],
    logger: logging.Logger,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    logger.info("Running parameter stability test")
    rows = []

    for config in generate_parameter_configs():
        try:
            metadata, states, _ = build_state_matrix(df, cmap, config)
            model, labels = fit_structural_model(
                states, config, RANDOM_SEED
            )
            assignments = build_assignments(
                metadata, labels, df, cmap
            )
            summary = summarize_run(
                assignments,
                model.scaler.transform(states),
                labels,
                feature_names,
                RANDOM_SEED,
            )
            _, similarity = align_profiles(
                baseline_profiles,
                summary["profiles"],
                feature_names,
            )
            rows.append(
                {
                    "config_id": config.config_id,
                    **asdict(config),
                    "n_states": len(states),
                    "profile_similarity_vs_baseline": similarity,
                    "mean_persistence": summary["mean_persistence"],
                    "transition_concentration": summary["transition_concentration"],
                    "silhouette_basin": summary["silhouette"],
                    "status": "completed",
                }
            )
        except Exception as exc:
            logger.warning(
                "Parameter configuration failed: %s | %s",
                config.config_id,
                exc,
            )
            rows.append(
                {
                    "config_id": config.config_id,
                    **asdict(config),
                    "status": f"failed: {exc}",
                }
            )

    result = pd.DataFrame(rows)
    completed = result.loc[result["status"].eq("completed")]
    aggregate = {
        "median_profile_similarity": safe_float(
            completed["profile_similarity_vs_baseline"].median()
        ) if not completed.empty else None,
        "minimum_profile_similarity": safe_float(
            completed["profile_similarity_vs_baseline"].min()
        ) if not completed.empty else None,
    }
    return result, aggregate


def temporal_transfer_test(
    df: pd.DataFrame,
    cmap: ColumnMap,
    config: RepresentationConfig,
    feature_names: list[str],
    logger: logging.Logger,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    logger.info("Running temporal transfer test")
    years = sorted(int(y) for y in df[cmap.year].dropna().unique())
    rows = []

    for train_year in years:
        for test_year in years:
            if train_year == test_year:
                continue

            train_df = df.loc[df[cmap.year].eq(train_year)].copy()
            test_df = df.loc[df[cmap.year].eq(test_year)].copy()

            try:
                train_meta, train_states, _ = build_state_matrix(
                    train_df, cmap, config
                )
                test_meta, test_states, _ = build_state_matrix(
                    test_df, cmap, config
                )

                model, train_labels = fit_structural_model(
                    train_states, config, RANDOM_SEED
                )
                test_labels = assign_with_model(test_states, model)

                train_assignments = build_assignments(
                    train_meta, train_labels, train_df, cmap
                )
                transfer_assignments = build_assignments(
                    test_meta, test_labels, test_df, cmap
                )

                # Independent representation on the test year for comparison.
                independent_model, independent_labels = fit_structural_model(
                    test_states, config, RANDOM_SEED
                )
                independent_assignments = build_assignments(
                    test_meta, independent_labels, test_df, cmap
                )

                train_profiles = basin_profiles(
                    train_assignments, feature_names
                )
                transfer_profiles = basin_profiles(
                    transfer_assignments, feature_names
                )
                independent_profiles = basin_profiles(
                    independent_assignments, feature_names
                )

                _, train_to_transfer = align_profiles(
                    train_profiles, transfer_profiles, feature_names
                )
                mapping, transfer_to_independent = align_profiles(
                    independent_profiles,
                    transfer_profiles,
                    feature_names,
                )
                ari = aligned_ari(
                    independent_labels[:, 1],
                    test_labels[:, 1],
                    mapping,
                )

                rows.append(
                    {
                        "train_year": train_year,
                        "test_year": test_year,
                        "train_to_transfer_profile_similarity": train_to_transfer,
                        "transfer_to_independent_profile_similarity": (
                            transfer_to_independent
                        ),
                        "aligned_ari_vs_independent_test_atlas": ari,
                        "n_train_states": len(train_states),
                        "n_test_states": len(test_states),
                        "status": "completed",
                    }
                )
            except Exception as exc:
                logger.warning(
                    "Temporal transfer failed %s -> %s: %s",
                    train_year,
                    test_year,
                    exc,
                )
                rows.append(
                    {
                        "train_year": train_year,
                        "test_year": test_year,
                        "status": f"failed: {exc}",
                    }
                )

    result = pd.DataFrame(rows)
    completed = result.loc[result["status"].eq("completed")]
    aggregate = {
        "median_transfer_profile_similarity": safe_float(
            completed["transfer_to_independent_profile_similarity"].median()
        ) if not completed.empty else None,
        "median_transfer_aligned_ari": safe_float(
            completed["aligned_ari_vs_independent_test_atlas"].median()
        ) if not completed.empty else None,
    }
    return result, aggregate


def block_bootstrap_dataframe(
    df: pd.DataFrame,
    cmap: ColumnMap,
    block_length: int,
    rng: np.random.Generator,
) -> pd.DataFrame:
    sampled_groups = []

    for (_, _), group in df.groupby(
        [cmap.year, cmap.sequence], sort=False
    ):
        group = group.sort_values(cmap.timestamp).reset_index(drop=True)
        if len(group) < block_length:
            continue

        n_blocks = max(1, math.ceil(len(group) / block_length))
        blocks = []
        for _ in range(n_blocks):
            start = int(rng.integers(0, len(group) - block_length + 1))
            block = group.iloc[start:start + block_length].copy()
            blocks.append(block)

        sampled = pd.concat(blocks, ignore_index=True)
        sampled_groups.append(sampled)

    if not sampled_groups:
        raise RuntimeError("No sequences were long enough for block bootstrap.")

    boot = pd.concat(sampled_groups, ignore_index=True)
    boot.sort_values([cmap.year, cmap.sequence, cmap.timestamp], inplace=True)
    boot.reset_index(drop=True, inplace=True)
    return boot


def bootstrap_stability_test(
    df: pd.DataFrame,
    cmap: ColumnMap,
    config: RepresentationConfig,
    baseline_profiles: pd.DataFrame,
    feature_names: list[str],
    logger: logging.Logger,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    logger.info("Running block-bootstrap stability test")
    rows = []

    for replicate in range(N_BOOTSTRAPS):
        rng = np.random.default_rng(RANDOM_SEED + replicate + 1)
        try:
            boot_df = block_bootstrap_dataframe(
                df, cmap, BLOCK_LENGTH, rng
            )
            metadata, states, _ = build_state_matrix(
                boot_df, cmap, config
            )
            model, labels = fit_structural_model(
                states, config, RANDOM_SEED + replicate + 1
            )
            assignments = build_assignments(
                metadata, labels, boot_df, cmap
            )
            summary = summarize_run(
                assignments,
                model.scaler.transform(states),
                labels,
                feature_names,
                RANDOM_SEED + replicate + 1,
            )
            _, similarity = align_profiles(
                baseline_profiles,
                summary["profiles"],
                feature_names,
            )

            rows.append(
                {
                    "replicate": replicate,
                    "n_rows": len(boot_df),
                    "n_states": len(states),
                    "profile_similarity_vs_baseline": similarity,
                    "mean_persistence": summary["mean_persistence"],
                    "transition_concentration": summary["transition_concentration"],
                    "silhouette_basin": summary["silhouette"],
                    "status": "completed",
                }
            )
        except Exception as exc:
            logger.warning(
                "Bootstrap replicate %s failed: %s",
                replicate,
                exc,
            )
            rows.append(
                {
                    "replicate": replicate,
                    "status": f"failed: {exc}",
                }
            )

    result = pd.DataFrame(rows)
    completed = result.loc[result["status"].eq("completed")]
    aggregate = {
        "median_profile_similarity": safe_float(
            completed["profile_similarity_vs_baseline"].median()
        ) if not completed.empty else None,
    }
    return result, aggregate


# =============================================================================
# NULL MODELS
# =============================================================================

def full_time_shuffle(
    df: pd.DataFrame,
    cmap: ColumnMap,
    rng: np.random.Generator,
) -> pd.DataFrame:
    surrogate = df.copy()
    values = surrogate[list(cmap.features.values())].to_numpy(copy=True)
    surrogate[list(cmap.features.values())] = values[
        rng.permutation(len(values))
    ]
    return surrogate


def within_feature_shuffle(
    df: pd.DataFrame,
    cmap: ColumnMap,
    rng: np.random.Generator,
) -> pd.DataFrame:
    surrogate = df.copy()
    for col in cmap.features.values():
        surrogate[col] = rng.permutation(
            surrogate[col].to_numpy(copy=True)
        )
    return surrogate


def sequence_order_shuffle(
    df: pd.DataFrame,
    cmap: ColumnMap,
    rng: np.random.Generator,
) -> pd.DataFrame:
    surrogate = df.copy()
    for (_, _), index in surrogate.groupby(
        [cmap.year, cmap.sequence], sort=False
    ).groups.items():
        index = np.asarray(list(index))
        feature_values = surrogate.loc[
            index, list(cmap.features.values())
        ].to_numpy(copy=True)
        surrogate.loc[
            index, list(cmap.features.values())
        ] = feature_values[rng.permutation(len(feature_values))]
    return surrogate


def phase_randomize_series(
    values: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    centered = values - np.nanmean(values)
    spectrum = np.fft.rfft(centered)

    phases = rng.uniform(0, 2 * np.pi, size=len(spectrum))
    phases[0] = 0.0
    if len(values) % 2 == 0:
        phases[-1] = 0.0

    randomized = np.abs(spectrum) * np.exp(1j * phases)
    result = np.fft.irfft(randomized, n=len(values))
    return result + np.nanmean(values)


def phase_randomized_surrogate(
    df: pd.DataFrame,
    cmap: ColumnMap,
    rng: np.random.Generator,
) -> pd.DataFrame:
    surrogate = df.copy()
    for (_, _), index in surrogate.groupby(
        [cmap.year, cmap.sequence], sort=False
    ).groups.items():
        index = np.asarray(list(index))
        for col in cmap.features.values():
            values = surrogate.loc[index, col].to_numpy(dtype=float)
            if len(values) >= 8:
                surrogate.loc[index, col] = phase_randomize_series(
                    values, rng
                )
    return surrogate


NULL_GENERATORS = {
    "full_time_shuffle": full_time_shuffle,
    "within_feature_shuffle": within_feature_shuffle,
    "sequence_order_shuffle": sequence_order_shuffle,
    "phase_randomized": phase_randomized_surrogate,
}


def null_model_test(
    df: pd.DataFrame,
    cmap: ColumnMap,
    config: RepresentationConfig,
    real_summary: dict[str, Any],
    feature_names: list[str],
    logger: logging.Logger,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    logger.info("Running null-model separation test")
    rows = []

    for null_name, generator in NULL_GENERATORS.items():
        for replicate in range(NULL_REPLICATES):
            seed = RANDOM_SEED + 10_000 + replicate
            rng = np.random.default_rng(seed)
            try:
                surrogate = generator(df, cmap, rng)
                metadata, states, _ = build_state_matrix(
                    surrogate, cmap, config
                )
                model, labels = fit_structural_model(
                    states, config, seed
                )
                assignments = build_assignments(
                    metadata, labels, surrogate, cmap
                )
                summary = summarize_run(
                    assignments,
                    model.scaler.transform(states),
                    labels,
                    feature_names,
                    seed,
                )
                rows.append(
                    {
                        "dataset_type": "null",
                        "null_model": null_name,
                        "replicate": replicate,
                        "mean_persistence": summary["mean_persistence"],
                        "transition_concentration": (
                            summary["transition_concentration"]
                        ),
                        "silhouette_basin": summary["silhouette"],
                        "status": "completed",
                    }
                )
            except Exception as exc:
                logger.warning(
                    "Null model %s replicate %s failed: %s",
                    null_name,
                    replicate,
                    exc,
                )
                rows.append(
                    {
                        "dataset_type": "null",
                        "null_model": null_name,
                        "replicate": replicate,
                        "status": f"failed: {exc}",
                    }
                )

    # Repeat the real result to create a tidy comparison table.
    for replicate in range(max(2, NULL_REPLICATES)):
        rows.append(
            {
                "dataset_type": "real",
                "null_model": "none",
                "replicate": replicate,
                "mean_persistence": real_summary["mean_persistence"],
                "transition_concentration": (
                    real_summary["transition_concentration"]
                ),
                "silhouette_basin": real_summary["silhouette"],
                "status": "completed",
            }
        )

    result = pd.DataFrame(rows)
    completed = result.loc[result["status"].eq("completed")]
    real = completed.loc[completed["dataset_type"].eq("real")]
    null = completed.loc[completed["dataset_type"].eq("null")]

    aggregate = {
        "effect_size_persistence": cohen_d(
            real["mean_persistence"],
            null["mean_persistence"],
        ),
        "effect_size_transition_concentration": cohen_d(
            real["transition_concentration"],
            null["transition_concentration"],
        ),
        "real_mean_persistence": safe_float(
            real["mean_persistence"].mean()
        ),
        "null_mean_persistence": safe_float(
            null["mean_persistence"].mean()
        ),
        "real_transition_concentration": safe_float(
            real["transition_concentration"].mean()
        ),
        "null_transition_concentration": safe_float(
            null["transition_concentration"].mean()
        ),
    }
    return result, aggregate


# =============================================================================
# ENTITLEMENT
# =============================================================================

def evaluate_entitlement(
    seed_summary: dict[str, Any],
    parameter_summary: dict[str, Any],
    transfer_summary: dict[str, Any],
    bootstrap_summary: dict[str, Any],
    null_summary: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    tests = [
        {
            "test_id": "seed_stability",
            "measurement": "median_seed_aligned_ari",
            "threshold": THRESHOLDS["median_seed_aligned_ari"],
            "result": seed_summary.get("median_aligned_ari"),
            "direction": ">=",
        },
        {
            "test_id": "parameter_stability",
            "measurement": "median_parameter_profile_similarity",
            "threshold": THRESHOLDS[
                "median_parameter_profile_similarity"
            ],
            "result": parameter_summary.get(
                "median_profile_similarity"
            ),
            "direction": ">=",
        },
        {
            "test_id": "temporal_transfer",
            "measurement": "median_temporal_transfer_profile_similarity",
            "threshold": THRESHOLDS[
                "median_temporal_transfer_profile_similarity"
            ],
            "result": transfer_summary.get(
                "median_transfer_profile_similarity"
            ),
            "direction": ">=",
        },
        {
            "test_id": "bootstrap_stability",
            "measurement": "median_bootstrap_profile_similarity",
            "threshold": THRESHOLDS[
                "median_bootstrap_profile_similarity"
            ],
            "result": bootstrap_summary.get(
                "median_profile_similarity"
            ),
            "direction": ">=",
        },
        {
            "test_id": "null_persistence",
            "measurement": "null_effect_size_persistence",
            "threshold": THRESHOLDS[
                "null_effect_size_persistence"
            ],
            "result": null_summary.get(
                "effect_size_persistence"
            ),
            "direction": ">=",
        },
        {
            "test_id": "null_transition_concentration",
            "measurement": "null_effect_size_transition_concentration",
            "threshold": THRESHOLDS[
                "null_effect_size_transition_concentration"
            ],
            "result": null_summary.get(
                "effect_size_transition_concentration"
            ),
            "direction": ">=",
        },
        {
            "test_id": "bottleneck_recurrence",
            "measurement": "bottleneck_recurrence_fraction",
            "threshold": THRESHOLDS[
                "bottleneck_recurrence_fraction"
            ],
            "result": seed_summary.get(
                "median_bottleneck_recurrence"
            ),
            "direction": ">=",
        },
    ]

    for test in tests:
        result = test["result"]
        test["passed"] = (
            result is not None
            and math.isfinite(float(result))
            and float(result) >= float(test["threshold"])
        )
        test["critical"] = test["test_id"] in CRITICAL_TESTS

    table = pd.DataFrame(tests)
    n_passed = int(table["passed"].sum())
    critical_passed = bool(
        table.loc[table["critical"], "passed"].all()
    )

    if n_passed == len(table) and critical_passed:
        status = "QUALIFIED"
    elif n_passed >= 5 and critical_passed:
        status = "PROVISIONALLY QUALIFIED"
    else:
        status = "NOT QUALIFIED"

    summary = {
        "status": status,
        "tests_passed": n_passed,
        "tests_total": len(table),
        "critical_tests_passed": critical_passed,
    }
    return table, summary


# =============================================================================
# REPORTING
# =============================================================================

def make_report(
    started: str,
    cmap: ColumnMap,
    baseline_config: RepresentationConfig,
    baseline_summary: dict[str, Any],
    seed_summary: dict[str, Any],
    parameter_summary: dict[str, Any],
    transfer_summary: dict[str, Any],
    bootstrap_summary: dict[str, Any],
    null_summary: dict[str, Any],
    entitlement_table: pd.DataFrame,
    entitlement_summary: dict[str, Any],
) -> str:
    lines = [
        "# M1D Solar Organizational Atlas Validation",
        "",
        f"- Project: **{PROJECT_NAME}**",
        f"- Milestone: **{MILESTONE}**",
        f"- Validation mode: **{VALIDATION_MODE}**",
        f"- Run started: `{started}`",
        f"- Input: `{INPUT_FILE}`",
        "",
        "## Scientific question",
        "",
        "Are the inferred solar organizational regimes reproducible properties "
        "of the observations, or are they artifacts of seed choice, parameter "
        "selection, temporal sampling, or generic time-series structure?",
        "",
        "## Baseline representation",
        "",
        "```json",
        json.dumps(asdict(baseline_config), indent=2),
        "```",
        "",
        "## Resolved features",
        "",
    ]

    for name, col in cmap.features.items():
        lines.append(f"- {name}: `{col}`")

    lines.extend(
        [
            "",
            "## Baseline structural summary",
            "",
            f"- Basin silhouette: **{baseline_summary['silhouette']}**",
            f"- Mean self-transition probability: "
            f"**{baseline_summary['mean_persistence']}**",
            f"- Transition concentration: "
            f"**{baseline_summary['transition_concentration']}**",
            "",
            "## Validation summaries",
            "",
            "### Seed stability",
            "",
            "```json",
            json.dumps(seed_summary, indent=2),
            "```",
            "",
            "### Parameter stability",
            "",
            "```json",
            json.dumps(parameter_summary, indent=2),
            "```",
            "",
            "### Temporal transfer",
            "",
            "```json",
            json.dumps(transfer_summary, indent=2),
            "```",
            "",
            "### Block-bootstrap stability",
            "",
            "```json",
            json.dumps(bootstrap_summary, indent=2),
            "```",
            "",
            "### Null-model separation",
            "",
            "```json",
            json.dumps(null_summary, indent=2),
            "```",
            "",
            "## Representation entitlement scorecard",
            "",
            entitlement_table.to_markdown(index=False, floatfmt=".4f"),
            "",
            f"## Qualification decision: "
            f"**{entitlement_summary['status']}**",
            "",
            f"- Tests passed: "
            f"**{entitlement_summary['tests_passed']} / "
            f"{entitlement_summary['tests_total']}**",
            f"- Critical tests passed: "
            f"**{entitlement_summary['critical_tests_passed']}**",
            "",
            "## Interpretation guardrails",
            "",
            "- Qualification supports structural interpretation; it does not "
            "establish a physical mechanism.",
            "- Organizational regime identifiers remain empirical labels.",
            "- Failure of qualification is informative and requires "
            "representation revision before physical interpretation.",
            "- No market data, market target, or cross-domain correspondence "
            "is used in this milestone.",
            "",
        ]
    )
    return "\n".join(lines)


# =============================================================================
# MAIN
# =============================================================================

def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    TABLE_DIR.mkdir(parents=True, exist_ok=True)

    logger = configure_logging(REPORT_DIR / "m1d_run_log.txt")
    started = datetime.now(timezone.utc).isoformat()

    logger.info("%s — %s", PROJECT_NAME, DESCRIPTION)
    logger.info("Validation mode: %s", VALIDATION_MODE)
    logger.info("Loading %s", INPUT_FILE)

    df, cmap = load_data(INPUT_FILE)
    feature_names = list(cmap.features.keys())
    baseline_config = RepresentationConfig(**BASELINE)

    logger.info("Usable rows: %s", f"{len(df):,}")
    logger.info("Resolved features: %s", cmap.features)

    # Baseline atlas.
    baseline_metadata, baseline_states, embedded_names = build_state_matrix(
        df, cmap, baseline_config
    )
    baseline_model, baseline_labels = fit_structural_model(
        baseline_states, baseline_config, RANDOM_SEED
    )
    baseline_assignments = build_assignments(
        baseline_metadata, baseline_labels, df, cmap
    )
    baseline_summary = summarize_run(
        baseline_assignments,
        baseline_model.scaler.transform(baseline_states),
        baseline_labels,
        feature_names,
        RANDOM_SEED,
    )

    logger.info(
        "Baseline states: %s | dimensions: %s",
        f"{len(baseline_states):,}",
        baseline_states.shape[1],
    )

    # Validation modules.
    seed_table, seed_summary = seed_stability_test(
        baseline_states,
        baseline_metadata,
        df,
        cmap,
        baseline_config,
        feature_names,
        logger,
    )

    parameter_table, parameter_summary = parameter_stability_test(
        df,
        cmap,
        baseline_summary["profiles"],
        feature_names,
        logger,
    )

    transfer_table, transfer_summary = temporal_transfer_test(
        df,
        cmap,
        baseline_config,
        feature_names,
        logger,
    )

    bootstrap_table, bootstrap_summary = bootstrap_stability_test(
        df,
        cmap,
        baseline_config,
        baseline_summary["profiles"],
        feature_names,
        logger,
    )

    null_table, null_summary = null_model_test(
        df,
        cmap,
        baseline_config,
        baseline_summary,
        feature_names,
        logger,
    )

    entitlement_table, entitlement_summary = evaluate_entitlement(
        seed_summary,
        parameter_summary,
        transfer_summary,
        bootstrap_summary,
        null_summary,
    )

    # Tables.
    outputs = {
        "m1d_seed_stability.csv": seed_table,
        "m1d_parameter_stability.csv": parameter_table,
        "m1d_temporal_transfer.csv": transfer_table,
        "m1d_bootstrap_stability.csv": bootstrap_table,
        "m1d_null_comparison.csv": null_table,
        "m1d_entitlement_scorecard.csv": entitlement_table,
        "m1d_baseline_basin_metrics.csv": baseline_summary["metrics"],
        "m1d_baseline_basin_profiles.csv": baseline_summary["profiles"],
        "m1d_baseline_basin_transitions.csv": baseline_summary["transitions"],
        "m1d_baseline_bottlenecks.csv": baseline_summary["bottlenecks"],
    }
    for filename, frame in outputs.items():
        path = TABLE_DIR / filename
        write_csv(frame, path)
        logger.info("Wrote %s (%s rows)", path, f"{len(frame):,}")

    # Machine-readable manifest and summary.
    manifest = {
        "project": PROJECT_NAME,
        "milestone": MILESTONE,
        "description": DESCRIPTION,
        "validation_mode": VALIDATION_MODE,
        "run_started_utc": started,
        "run_completed_utc": datetime.now(timezone.utc).isoformat(),
        "input_file": str(INPUT_FILE),
        "resolved_columns": asdict(cmap),
        "baseline_config": asdict(baseline_config),
        "embedded_feature_names": embedded_names,
        "n_input_rows": len(df),
        "n_baseline_states": len(baseline_states),
        "baseline_state_dimension": baseline_states.shape[1],
        "thresholds": THRESHOLDS,
        "seed_summary": seed_summary,
        "parameter_summary": parameter_summary,
        "temporal_transfer_summary": transfer_summary,
        "bootstrap_summary": bootstrap_summary,
        "null_summary": null_summary,
        "entitlement_summary": entitlement_summary,
        "guardrails": {
            "solar_only": True,
            "no_market_target": True,
            "no_cross_domain_correspondence": True,
            "no_causal_claim": True,
            "physical_interpretation_deferred": True,
        },
    }
    (REPORT_DIR / "m1d_summary.json").write_text(
        json.dumps(manifest, indent=2),
        encoding="utf-8",
    )

    report = make_report(
        started,
        cmap,
        baseline_config,
        baseline_summary,
        seed_summary,
        parameter_summary,
        transfer_summary,
        bootstrap_summary,
        null_summary,
        entitlement_table,
        entitlement_summary,
    )
    (REPORT_DIR / "m1d_validation_report.md").write_text(
        report,
        encoding="utf-8",
    )

    logger.info(
        "M1D completed — qualification decision: %s",
        entitlement_summary["status"],
    )
    logger.info(
        "Review %s",
        REPORT_DIR / "m1d_validation_report.md",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
