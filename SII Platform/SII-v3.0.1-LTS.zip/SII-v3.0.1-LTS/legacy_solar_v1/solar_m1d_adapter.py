#!/usr/bin/env python3
"""
Structural Intelligence Qualification Framework
Solar M1D Integration Adapter

This module connects the original Solar Organizational Atlas construction code
in ``run_m1d_solar_atlas_validation.py`` to the domain-neutral Phase 1
Representation Qualification interface.

The legacy script remains the source of the established Solar representation
logic:

- source-column resolution
- time-delay state construction
- robust scaling
- MiniBatchKMeans microstates
- agglomerative basin construction
- assignment of physical feature values
- basin profile construction

This adapter does not import or execute the legacy validation tests. It reuses
only the representation-building functions and translates their outputs into
the new ``RepresentationRun`` and ``RepresentationArtifacts`` contracts.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType
from typing import Any, Mapping

import numpy as np
import pandas as pd

from phase1_representation import RepresentationRun, make_representation_run
from qualification_config import QualificationProtocolConfig
from qualification_types import (
    AtlasMetadata,
    AtlasQualification,
    AtlasState,
    OrganizationalAtlas,
    RepresentationArtifacts,
    RepresentationConfig,
)


# =============================================================================
# EXCEPTIONS
# =============================================================================

class LegacyModuleError(RuntimeError):
    """Raised when the legacy Solar M1D module cannot be loaded or validated."""


class SolarAdapterError(RuntimeError):
    """Raised when Solar data cannot be adapted to the new framework."""


# =============================================================================
# LEGACY MODULE LOADING
# =============================================================================

REQUIRED_LEGACY_FUNCTIONS = (
    "load_data",
    "build_state_matrix",
    "fit_structural_model",
    "build_assignments",
    "basin_profiles",
)


def load_legacy_module(
    script_path: Path | str = Path("run_m1d_solar_atlas_validation.py"),
    *,
    module_name: str = "_legacy_m1d_solar_atlas_validation",
) -> ModuleType:
    """
    Load the original M1D script without calling its ``main()`` function.

    Python executes top-level declarations during import, but the legacy
    ``if __name__ == '__main__'`` block is not run.
    """
    path = Path(script_path).expanduser().resolve()
    if not path.exists():
        raise LegacyModuleError(
            f"Legacy M1D script was not found: {path}"
        )

    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise LegacyModuleError(
            f"Could not create an import specification for: {path}"
        )

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module

    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        sys.modules.pop(module_name, None)
        raise LegacyModuleError(
            f"Failed to import legacy M1D script {path}: {exc}"
        ) from exc

    missing = [
        name
        for name in REQUIRED_LEGACY_FUNCTIONS
        if not callable(getattr(module, name, None))
    ]
    if missing:
        raise LegacyModuleError(
            "Legacy module is missing required construction functions: "
            + ", ".join(missing)
        )

    return module


# =============================================================================
# DATA CONTRACT
# =============================================================================

@dataclass
class SolarDataset:
    """Loaded Solar data together with the resolved legacy column map."""

    data: pd.DataFrame
    column_map: Any
    feature_names: list[str]
    source_path: Path

    def validate(self) -> None:
        if self.data.empty:
            raise SolarAdapterError("Solar dataset contains no usable rows.")
        if not self.feature_names:
            raise SolarAdapterError("No Solar features were resolved.")

        required = [
            self.column_map.timestamp,
            self.column_map.year,
            self.column_map.sequence,
            *self.column_map.features.values(),
        ]
        missing = [column for column in required if column not in self.data.columns]
        if missing:
            raise SolarAdapterError(
                f"Loaded Solar data is missing columns: {missing}"
            )


@dataclass
class SolarM1DAdapter:
    """
    Callable Phase 1 representation builder backed by the legacy M1D functions.

    An instance satisfies the ``RepresentationBuilder`` protocol used by
    ``run_phase1_representation``.
    """

    protocol: QualificationProtocolConfig
    legacy_script_path: Path = Path("run_m1d_solar_atlas_validation.py")
    legacy_module: ModuleType | None = None
    column_map: Any | None = None
    feature_names: list[str] = field(default_factory=list)
    source_path: Path | None = None

    def __post_init__(self) -> None:
        self.protocol.validate()
        if self.legacy_module is None:
            self.legacy_module = load_legacy_module(
                self.legacy_script_path
            )

    # -------------------------------------------------------------------------
    # Loading and column resolution
    # -------------------------------------------------------------------------

    def load_data(
        self,
        path: Path | str | None = None,
    ) -> SolarDataset:
        """Load the analysis-ready Solar dataset using the established loader."""
        source = Path(path or self.protocol.paths.input_file)
        try:
            data, column_map = self.legacy_module.load_data(source)
        except Exception as exc:
            raise SolarAdapterError(
                f"Could not load Solar data from {source}: {exc}"
            ) from exc

        dataset = SolarDataset(
            data=data,
            column_map=column_map,
            feature_names=list(column_map.features.keys()),
            source_path=source,
        )
        dataset.validate()

        self.column_map = column_map
        self.feature_names = dataset.feature_names
        self.source_path = source
        return dataset

    def bind_dataframe(
        self,
        data: pd.DataFrame,
    ) -> SolarDataset:
        """
        Resolve columns for an already loaded DataFrame.

        This is useful when a caller has loaded or filtered the dataset outside
        the adapter.
        """
        columns = list(data.columns)
        legacy = self.legacy_module

        try:
            column_map = legacy.ColumnMap(
                timestamp=legacy.resolve_column(
                    columns,
                    list(self.protocol.columns.timestamp_aliases),
                ),
                year=legacy.resolve_column(
                    columns,
                    list(self.protocol.columns.period_aliases),
                ),
                sequence=legacy.resolve_column(
                    columns,
                    list(self.protocol.columns.sequence_aliases),
                ),
                sequence_length=legacy.resolve_column(
                    columns,
                    list(self.protocol.columns.sequence_length_aliases),
                    required=False,
                ),
                features={
                    canonical: legacy.resolve_column(
                        columns,
                        list(aliases),
                    )
                    for canonical, aliases
                    in self.protocol.columns.feature_aliases.items()
                },
            )
        except Exception as exc:
            raise SolarAdapterError(
                f"Could not resolve Solar columns: {exc}"
            ) from exc

        dataset = SolarDataset(
            data=data,
            column_map=column_map,
            feature_names=list(column_map.features.keys()),
            source_path=self.source_path or self.protocol.paths.input_file,
        )
        dataset.validate()

        self.column_map = column_map
        self.feature_names = dataset.feature_names
        return dataset

    # -------------------------------------------------------------------------
    # Configuration translation
    # -------------------------------------------------------------------------

    def to_legacy_config(
        self,
        config: RepresentationConfig,
    ) -> Any:
        """Translate the framework configuration into the legacy dataclass."""
        return self.legacy_module.RepresentationConfig(
            include_first_differences=config.include_first_differences,
            embedding_dimension=config.embedding_dimension,
            embedding_lag_minutes=config.embedding_lag_minutes,
            n_microstates=config.n_microstates,
            n_basins=config.n_basins,
        )

    # -------------------------------------------------------------------------
    # Bootstrap-safe source preparation
    # -------------------------------------------------------------------------

    def _prepare_source(
        self,
        data: pd.DataFrame,
    ) -> pd.DataFrame:
        """
        Normalize temporary bootstrap sequence IDs for legacy compatibility.

        The new adaptive bootstrap intentionally assigns unique string sequence
        IDs to sampled blocks so transitions never bridge block boundaries. The
        legacy state builder casts sequence IDs to integers. Factorization here
        preserves block boundaries while satisfying that requirement.
        """
        if self.column_map is None:
            self.bind_dataframe(data)

        source = data.copy()
        sequence_column = self.column_map.sequence
        year_column = self.column_map.year
        timestamp_column = self.column_map.timestamp

        source[timestamp_column] = pd.to_datetime(
            source[timestamp_column],
            utc=True,
            errors="coerce",
        )
        source[year_column] = pd.to_numeric(
            source[year_column],
            errors="coerce",
        )

        numeric_sequence = pd.to_numeric(
            source[sequence_column],
            errors="coerce",
        )
        if numeric_sequence.isna().any():
            codes, _ = pd.factorize(
                source[sequence_column].astype(str),
                sort=False,
            )
            source[sequence_column] = codes.astype(np.int64)
        else:
            source[sequence_column] = numeric_sequence.astype(np.int64)

        for column in self.column_map.features.values():
            source[column] = pd.to_numeric(
                source[column],
                errors="coerce",
            )

        required = [
            timestamp_column,
            year_column,
            sequence_column,
            *self.column_map.features.values(),
        ]
        source = source.dropna(subset=required).copy()
        source.sort_values(
            [year_column, sequence_column, timestamp_column],
            inplace=True,
        )
        source.reset_index(drop=True, inplace=True)

        if source.empty:
            raise SolarAdapterError(
                "No usable rows remained after source normalization."
            )
        return source

    # -------------------------------------------------------------------------
    # Profile translation
    # -------------------------------------------------------------------------

    def _profile_matrix(
        self,
        profiles: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Return profiles, occupancies, and basin IDs in a shared row order.

        Profiles use robustly normalized basin means so comparisons are not
        dominated by feature scale.
        """
        mean_columns = [
            f"{feature}_mean"
            for feature in self.feature_names
        ]
        missing = [
            column for column in mean_columns
            if column not in profiles.columns
        ]
        if missing:
            raise SolarAdapterError(
                f"Legacy basin profile table is missing: {missing}"
            )

        ordered = profiles.sort_values("basin_id").reset_index(drop=True)
        matrix = ordered[mean_columns].to_numpy(dtype=float)

        center = np.nanmedian(matrix, axis=0)
        scale = np.nanmedian(
            np.abs(matrix - center),
            axis=0,
        )
        scale = np.where(
            (~np.isfinite(scale)) | (scale == 0.0),
            1.0,
            scale,
        )
        normalized = (matrix - center) / scale
        normalized = np.nan_to_num(
            normalized,
            nan=0.0,
            posinf=0.0,
            neginf=0.0,
        )

        basin_ids = ordered["basin_id"].to_numpy(dtype=int)
        return normalized, basin_ids, matrix

    # -------------------------------------------------------------------------
    # RepresentationBuilder implementation
    # -------------------------------------------------------------------------

    def __call__(
        self,
        data: pd.DataFrame,
        config: RepresentationConfig,
        seed: int,
        run_id: str,
    ) -> RepresentationRun:
        if self.column_map is None:
            self.bind_dataframe(data)

        source = self._prepare_source(data)
        legacy_config = self.to_legacy_config(config)
        legacy = self.legacy_module

        try:
            metadata, states, embedded_names = legacy.build_state_matrix(
                source,
                self.column_map,
                legacy_config,
            )
            model, labels = legacy.fit_structural_model(
                states,
                legacy_config,
                seed,
            )
            assignments = legacy.build_assignments(
                metadata,
                labels,
                source,
                self.column_map,
            )
            profiles = legacy.basin_profiles(
                assignments,
                self.feature_names,
            )
        except Exception as exc:
            raise SolarAdapterError(
                f"Representation run {run_id} failed: {exc}"
            ) from exc

        scaled_states = model.scaler.transform(states)
        basin_profiles, basin_ids, raw_profile_means = (
            self._profile_matrix(profiles)
        )

        occupancy_counts = (
            assignments["basin_id"]
            .value_counts()
            .reindex(basin_ids, fill_value=0)
            .to_numpy(dtype=float)
        )

        representation = RepresentationArtifacts(
            metadata=metadata.copy(),
            embedded_feature_names=list(embedded_names),
            embedded_states=np.asarray(states, dtype=float),
            scaled_states=np.asarray(scaled_states, dtype=float),
            microstate_assignments=np.asarray(
                labels[:, 0],
                dtype=int,
            ),
            basin_assignments=np.asarray(
                labels[:, 1],
                dtype=int,
            ),
            coordinate_matrix=np.asarray(
                scaled_states,
                dtype=float,
            ),
            scaler=model.scaler,
            microstate_model=model.microstate_model,
            basin_model=model.basin_model,
            microstate_to_basin=np.asarray(
                model.microstate_to_basin,
                dtype=int,
            ),
        )
        representation.validate()

        run = make_representation_run(
            run_id=run_id,
            seed=seed,
            config_id=config.config_id,
            assignments=labels[:, 1],
            microstate_assignments=labels[:, 0],
            basin_profiles=basin_profiles,
            basin_occupancy=occupancy_counts,
            representation=representation,
            metadata={
                "source_rows": int(len(source)),
                "n_states": int(len(states)),
                "feature_names": list(self.feature_names),
                "embedded_feature_names": list(embedded_names),
                "basin_ids_in_profile_order": basin_ids.tolist(),
                "raw_basin_profile_means": raw_profile_means.tolist(),
                "legacy_script": str(
                    Path(self.legacy_script_path)
                ),
            },
        )
        return run


# =============================================================================
# ATLAS INITIALIZATION
# =============================================================================

def initialize_solar_atlas(
    *,
    protocol: QualificationProtocolConfig,
    dataset: SolarDataset,
) -> OrganizationalAtlas:
    """Create the initial OrganizationalAtlas object for Solar qualification."""
    metadata = AtlasMetadata(
        project=protocol.identity.project_name,
        atlas_name=protocol.identity.atlas_name,
        atlas_version=protocol.identity.atlas_version,
        qualification_protocol_version=(
            protocol.identity.qualification_protocol_version
        ),
        dataset_name=protocol.identity.dataset_name,
        dataset_version=protocol.identity.dataset_version,
        representation_method=protocol.identity.representation_method,
        representation_version=protocol.identity.representation_version,
        feature_names=list(dataset.feature_names),
        representation_config=protocol.baseline_representation,
        random_seed=protocol.identity.random_seed,
        n_observations=int(len(dataset.data)),
        input_path=dataset.source_path,
        source_periods=[
            str(value)
            for value in sorted(
                dataset.data[
                    dataset.column_map.year
                ].dropna().unique()
            )
        ],
    )

    qualification = AtlasQualification(
        protocol_version=(
            protocol.identity.qualification_protocol_version
        )
    )

    atlas = OrganizationalAtlas(
        metadata=metadata,
        state=AtlasState.INITIALIZED,
        qualification=qualification,
    )
    atlas.validate()
    return atlas


# =============================================================================
# INTEGRATION CHECKS
# =============================================================================

def adapter_diagnostics(
    adapter: SolarM1DAdapter,
    dataset: SolarDataset,
) -> dict[str, Any]:
    """Return a compact, serializable adapter readiness record."""
    legacy = adapter.legacy_module
    return {
        "legacy_script": str(
            Path(adapter.legacy_script_path).resolve()
        ),
        "legacy_functions_available": {
            name: callable(getattr(legacy, name, None))
            for name in REQUIRED_LEGACY_FUNCTIONS
        },
        "source_path": str(dataset.source_path),
        "usable_rows": int(len(dataset.data)),
        "feature_names": list(dataset.feature_names),
        "resolved_columns": {
            "timestamp": dataset.column_map.timestamp,
            "period": dataset.column_map.year,
            "sequence": dataset.column_map.sequence,
            "sequence_length": dataset.column_map.sequence_length,
            "features": dict(dataset.column_map.features),
        },
        "baseline_config_id": (
            adapter.protocol.baseline_representation.config_id
        ),
        "ready": True,
    }


def write_adapter_diagnostics(
    diagnostics: Mapping[str, Any],
    path: Path | str,
) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(diagnostics, indent=2, default=str),
        encoding="utf-8",
    )


# =============================================================================
# CONVENIENCE FACTORY
# =============================================================================

def create_solar_phase1_context(
    *,
    protocol: QualificationProtocolConfig,
    legacy_script_path: Path | str = Path(
        "run_m1d_solar_atlas_validation.py"
    ),
    input_path: Path | str | None = None,
) -> tuple[
    SolarM1DAdapter,
    SolarDataset,
    OrganizationalAtlas,
]:
    """
    Create the adapter, load the dataset, and initialize the atlas.

    This is the simplest entry point for the future qualification driver.
    """
    adapter = SolarM1DAdapter(
        protocol=protocol,
        legacy_script_path=Path(legacy_script_path),
    )
    dataset = adapter.load_data(input_path)
    atlas = initialize_solar_atlas(
        protocol=protocol,
        dataset=dataset,
    )
    return adapter, dataset, atlas


if __name__ == "__main__":
    from qualification_config import ACTIVE_PROTOCOL

    adapter, dataset, atlas = create_solar_phase1_context(
        protocol=ACTIVE_PROTOCOL,
    )
    diagnostics = adapter_diagnostics(adapter, dataset)
    print(json.dumps(diagnostics, indent=2))
    print(f"Initialized atlas: {atlas.atlas_id}")
