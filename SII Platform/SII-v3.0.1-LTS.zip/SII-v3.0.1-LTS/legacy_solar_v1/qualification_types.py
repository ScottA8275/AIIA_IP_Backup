#!/usr/bin/env python3
"""
Structural Intelligence Qualification Framework
Core scientific data types for Organizational Atlas construction and qualification.

This module is intentionally domain-neutral. Solar, Bell, protein, world-model,
financial, and future atlases should all use the same scientific object model.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Mapping, Sequence

import networkx as nx
import numpy as np
import pandas as pd


# =============================================================================
# ENUMERATIONS
# =============================================================================

class AtlasState(str, Enum):
    """Lifecycle state of an Organizational Atlas."""

    INITIALIZED = "initialized"
    CONSTRUCTED = "constructed"
    REPRESENTATION_REVIEWED = "representation_reviewed"
    ORGANIZATION_REVIEWED = "organization_reviewed"
    TEMPORAL_REVIEWED = "temporal_reviewed"
    NULL_REVIEWED = "null_reviewed"
    QUALIFIED = "qualified"


class QualificationLevel(str, Enum):
    """Scientific maturity of an Organizational Atlas."""

    EXPLORATORY = "exploratory"
    EMERGING = "emerging"
    QUALIFIED = "qualified"
    REFERENCE = "reference"


class ReviewStatus(str, Enum):
    """Status of an individual scientific review."""

    NOT_EVALUATED = "not_evaluated"
    INCOMPLETE = "incomplete"
    CONCERN = "concern"
    SUPPORTED = "supported"
    STRONGLY_SUPPORTED = "strongly_supported"


class RecommendationCode(str, Enum):
    """Standardized next-step recommendations."""

    CONTINUE = "continue"
    REVISE_REPRESENTATION = "revise_representation"
    REFINE_PARAMETERS = "refine_parameters"
    INCREASE_SAMPLE = "increase_sample"
    COLLECT_ADDITIONAL_PERIODS = "collect_additional_periods"
    INVESTIGATE_IMBALANCE = "investigate_imbalance"
    REPAIR_BOOTSTRAP = "repair_bootstrap"
    EXPAND_NULL_MODELS = "expand_null_models"
    NO_FURTHER_ACTION = "no_further_action"


class EvidenceKind(str, Enum):
    """Type of evidence attached to a scientific review."""

    METRIC = "metric"
    TABLE = "table"
    FIGURE = "figure"
    DISTRIBUTION = "distribution"
    NOTE = "note"


# =============================================================================
# SERIALIZATION HELPERS
# =============================================================================

def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc)


def _to_serializable(value: Any) -> Any:
    """Convert framework objects into JSON-compatible values."""
    if value is None:
        return None
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, pd.DataFrame):
        return value.to_dict(orient="records")
    if isinstance(value, pd.Series):
        return value.to_list()
    if isinstance(value, nx.Graph):
        return nx.node_link_data(value)
    if is_dataclass(value):
        return {
            key: _to_serializable(item)
            for key, item in asdict(value).items()
        }
    if isinstance(value, Mapping):
        return {
            str(key): _to_serializable(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple, set)):
        return [_to_serializable(item) for item in value]
    return value


class SerializableMixin:
    """Provides consistent dictionary serialization for framework objects."""

    def to_dict(self) -> dict[str, Any]:
        result = _to_serializable(self)
        if not isinstance(result, dict):
            raise TypeError(
                f"{self.__class__.__name__}.to_dict() did not produce a dictionary."
            )
        return result


# =============================================================================
# CONFIGURATION AND PROVENANCE
# =============================================================================

@dataclass(frozen=True)
class RepresentationConfig(SerializableMixin):
    """Parameters used to construct an Organizational Atlas representation."""

    include_first_differences: bool
    embedding_dimension: int
    embedding_lag_minutes: int
    n_microstates: int
    n_basins: int

    @property
    def config_id(self) -> str:
        diff = "diff" if self.include_first_differences else "level"
        return (
            f"micro{self.n_microstates}_"
            f"basin{self.n_basins}_"
            f"dim{self.embedding_dimension}_"
            f"lag{self.embedding_lag_minutes}_"
            f"{diff}"
        )

    def validate(self) -> None:
        if self.embedding_dimension < 1:
            raise ValueError("embedding_dimension must be at least 1.")
        if self.embedding_lag_minutes < 1:
            raise ValueError("embedding_lag_minutes must be at least 1.")
        if self.n_microstates < 2:
            raise ValueError("n_microstates must be at least 2.")
        if self.n_basins < 2:
            raise ValueError("n_basins must be at least 2.")
        if self.n_basins > self.n_microstates:
            raise ValueError("n_basins cannot exceed n_microstates.")


@dataclass
class AtlasMetadata(SerializableMixin):
    """Scientific provenance and reproducibility metadata."""

    project: str
    atlas_name: str
    atlas_version: str
    qualification_protocol_version: str
    dataset_name: str
    dataset_version: str
    representation_method: str
    representation_version: str
    feature_names: list[str]
    representation_config: RepresentationConfig
    random_seed: int

    created_utc: datetime = field(default_factory=utc_now)
    qualified_utc: datetime | None = None

    n_observations: int = 0
    n_states: int = 0
    state_dimension: int = 0

    input_path: Path | None = None
    source_periods: list[str] = field(default_factory=list)
    code_version: str | None = None
    notes: list[str] = field(default_factory=list)

    def validate(self) -> None:
        self.representation_config.validate()
        if not self.project.strip():
            raise ValueError("project must not be empty.")
        if not self.atlas_name.strip():
            raise ValueError("atlas_name must not be empty.")
        if not self.feature_names:
            raise ValueError("feature_names must not be empty.")
        if self.n_observations < 0 or self.n_states < 0 or self.state_dimension < 0:
            raise ValueError("Atlas counts cannot be negative.")


# =============================================================================
# REPRESENTATION AND ORGANIZATION
# =============================================================================

@dataclass
class RepresentationArtifacts(SerializableMixin):
    """
    Computational artifacts produced during representation construction.

    Estimator objects are stored as Any so this module remains independent of
    specific clustering libraries.
    """

    metadata: pd.DataFrame
    embedded_feature_names: list[str]
    embedded_states: np.ndarray
    scaled_states: np.ndarray
    microstate_assignments: np.ndarray
    basin_assignments: np.ndarray
    coordinate_matrix: np.ndarray | None = None

    scaler: Any | None = field(default=None, repr=False)
    microstate_model: Any | None = field(default=None, repr=False)
    basin_model: Any | None = field(default=None, repr=False)
    microstate_to_basin: np.ndarray | None = None

    def validate(self) -> None:
        n_states = len(self.embedded_states)
        if len(self.metadata) != n_states:
            raise ValueError("metadata and embedded_states must have equal length.")
        if len(self.scaled_states) != n_states:
            raise ValueError("scaled_states and embedded_states must have equal length.")
        if len(self.microstate_assignments) != n_states:
            raise ValueError("microstate_assignments length does not match states.")
        if len(self.basin_assignments) != n_states:
            raise ValueError("basin_assignments length does not match states.")
        if self.coordinate_matrix is not None and len(self.coordinate_matrix) != n_states:
            raise ValueError("coordinate_matrix length does not match states.")


@dataclass
class OrganizationalCoordinate(SerializableMixin):
    """Organizational location assigned to a single observation or state."""

    observation_id: str
    timestamp_utc: datetime | None
    sequence_id: str | int | None
    sequence_position: int | None

    microstate_id: int
    basin_id: int
    neighborhood_id: int | None = None
    corridor_id: str | None = None

    persistence: float | None = None
    local_entropy_bits: float | None = None
    confidence: float | None = None
    qualification_level: QualificationLevel = QualificationLevel.EXPLORATORY

    attributes: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        if self.confidence is not None and not 0.0 <= self.confidence <= 1.0:
            raise ValueError("coordinate confidence must be between 0 and 1.")
        if self.persistence is not None and not 0.0 <= self.persistence <= 1.0:
            raise ValueError("coordinate persistence must be between 0 and 1.")


@dataclass
class OrganizationArtifacts(SerializableMixin):
    """Empirical organization inferred from the representation."""

    assignments: pd.DataFrame
    basin_profiles: pd.DataFrame
    basin_metrics: pd.DataFrame
    transition_table: pd.DataFrame
    transition_graph: nx.DiGraph

    neighborhoods: pd.DataFrame = field(default_factory=pd.DataFrame)
    corridors: pd.DataFrame = field(default_factory=pd.DataFrame)
    bottlenecks: pd.DataFrame = field(default_factory=pd.DataFrame)
    topology_metrics: dict[str, Any] = field(default_factory=dict)
    structural_summary: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        required_assignment_columns = {"microstate_id", "basin_id"}
        missing = required_assignment_columns - set(self.assignments.columns)
        if missing:
            raise ValueError(
                f"assignments missing required columns: {sorted(missing)}"
            )

        if "self_transition_probability" in self.basin_metrics.columns:
            values = pd.to_numeric(
                self.basin_metrics["self_transition_probability"],
                errors="coerce",
            ).dropna()
            invalid = values[(values < 0.0) | (values > 1.0)]
            if not invalid.empty:
                raise ValueError(
                    "self_transition_probability must remain within [0, 1]."
                )


# =============================================================================
# EVIDENCE AND SCIENTIFIC REVIEWS
# =============================================================================

@dataclass
class EvidenceReference(SerializableMixin):
    """Reference to evidence generated by a qualification phase."""

    evidence_id: str
    title: str
    kind: EvidenceKind
    path: Path | None = None
    description: str = ""
    metric_names: list[str] = field(default_factory=list)


@dataclass
class ValidationEvidence(SerializableMixin):
    """Quantitative and documentary evidence supporting a review."""

    metrics: dict[str, Any] = field(default_factory=dict)
    tables: dict[str, pd.DataFrame] = field(default_factory=dict)
    figures: list[EvidenceReference] = field(default_factory=list)
    distributions: dict[str, Sequence[float]] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def add_metric(self, name: str, value: Any) -> None:
        self.metrics[name] = value

    def add_table(self, name: str, table: pd.DataFrame) -> None:
        self.tables[name] = table

    def add_note(self, note: str) -> None:
        if note and note not in self.notes:
            self.notes.append(note)


@dataclass
class ReviewRecommendation(SerializableMixin):
    """Action generated by a scientific review."""

    code: RecommendationCode
    priority: int
    rationale: str
    required_before_advancement: bool = False

    def validate(self) -> None:
        if self.priority < 1:
            raise ValueError("Recommendation priority must be at least 1.")


@dataclass
class ScientificReview(SerializableMixin):
    """Base class for all qualification reviews."""

    phase_id: str
    phase_name: str
    status: ReviewStatus = ReviewStatus.NOT_EVALUATED
    confidence: float | None = None

    strengths: list[str] = field(default_factory=list)
    concerns: list[str] = field(default_factory=list)
    limitations: list[str] = field(default_factory=list)
    recommendations: list[ReviewRecommendation] = field(default_factory=list)
    evidence: ValidationEvidence = field(default_factory=ValidationEvidence)
    narrative: str = ""

    started_utc: datetime | None = None
    completed_utc: datetime | None = None

    def validate(self) -> None:
        if self.confidence is not None and not 0.0 <= self.confidence <= 1.0:
            raise ValueError("Review confidence must be between 0 and 1.")
        for recommendation in self.recommendations:
            recommendation.validate()

    def begin(self) -> None:
        self.started_utc = utc_now()

    def complete(
        self,
        status: ReviewStatus,
        confidence: float | None,
    ) -> None:
        self.status = status
        self.confidence = confidence
        self.completed_utc = utc_now()
        self.validate()

    @property
    def evaluated(self) -> bool:
        return self.status != ReviewStatus.NOT_EVALUATED


@dataclass
class RepresentationReview(ScientificReview):
    """Review of representation reproducibility and robustness."""

    phase_id: str = "phase1"
    phase_name: str = "Representation Review"

    seed_stability: dict[str, Any] = field(default_factory=dict)
    parameter_stability: dict[str, Any] = field(default_factory=dict)
    occupancy_stability: dict[str, Any] = field(default_factory=dict)
    hierarchical_stability: dict[str, Any] = field(default_factory=dict)
    split_merge_analysis: dict[str, Any] = field(default_factory=dict)


@dataclass
class OrganizationalReview(ScientificReview):
    """Review of the inferred atlas organization."""

    phase_id: str = "phase2"
    phase_name: str = "Organizational Review"

    neighborhood_stability: dict[str, Any] = field(default_factory=dict)
    transition_stability: dict[str, Any] = field(default_factory=dict)
    corridor_stability: dict[str, Any] = field(default_factory=dict)
    bottleneck_stability: dict[str, Any] = field(default_factory=dict)
    topology_stability: dict[str, Any] = field(default_factory=dict)


@dataclass
class TemporalReview(ScientificReview):
    """Review of temporal transfer, conservation, and novelty."""

    phase_id: str = "phase3"
    phase_name: str = "Temporal Review"

    shared_scaffold: dict[str, Any] = field(default_factory=dict)
    coordinate_transfer: dict[str, Any] = field(default_factory=dict)
    occupancy_shift: dict[str, Any] = field(default_factory=dict)
    persistent_regions: dict[str, Any] = field(default_factory=dict)
    novel_regions: dict[str, Any] = field(default_factory=dict)


@dataclass
class NullReview(ScientificReview):
    """Review against independently evaluated null-model families."""

    phase_id: str = "phase4"
    phase_name: str = "Null Review"

    null_families: dict[str, dict[str, Any]] = field(default_factory=dict)

    def add_null_family(
        self,
        name: str,
        metrics: dict[str, Any],
    ) -> None:
        self.null_families[name] = metrics


# =============================================================================
# QUALIFICATION
# =============================================================================

@dataclass
class AtlasQualification(SerializableMixin):
    """Consolidated scientific qualification record."""

    protocol_version: str
    representation_review: RepresentationReview = field(
        default_factory=RepresentationReview
    )
    organizational_review: OrganizationalReview = field(
        default_factory=OrganizationalReview
    )
    temporal_review: TemporalReview = field(
        default_factory=TemporalReview
    )
    null_review: NullReview = field(default_factory=NullReview)

    overall_confidence: float | None = None
    qualification_level: QualificationLevel = QualificationLevel.EXPLORATORY
    entitlement: bool = False

    limitations: list[str] = field(default_factory=list)
    recommendations: list[ReviewRecommendation] = field(default_factory=list)
    rationale: str = ""
    issued_utc: datetime | None = None

    def validate(self) -> None:
        reviews = [
            self.representation_review,
            self.organizational_review,
            self.temporal_review,
            self.null_review,
        ]
        for review in reviews:
            review.validate()

        if (
            self.overall_confidence is not None
            and not 0.0 <= self.overall_confidence <= 1.0
        ):
            raise ValueError("overall_confidence must be between 0 and 1.")

        if self.qualification_level in {
            QualificationLevel.QUALIFIED,
            QualificationLevel.REFERENCE,
        } and not self.entitlement:
            raise ValueError(
                "Qualified or Reference atlases must have entitlement=True."
            )

    def all_reviews(self) -> list[ScientificReview]:
        return [
            self.representation_review,
            self.organizational_review,
            self.temporal_review,
            self.null_review,
        ]

    def aggregate_limitations(self) -> list[str]:
        combined = list(self.limitations)
        for review in self.all_reviews():
            combined.extend(review.limitations)
        return list(dict.fromkeys(item for item in combined if item))

    def aggregate_recommendations(self) -> list[ReviewRecommendation]:
        combined = list(self.recommendations)
        for review in self.all_reviews():
            combined.extend(review.recommendations)

        deduplicated: dict[tuple[str, str], ReviewRecommendation] = {}
        for item in combined:
            key = (item.code.value, item.rationale)
            deduplicated[key] = item

        return sorted(
            deduplicated.values(),
            key=lambda item: (
                not item.required_before_advancement,
                item.priority,
                item.code.value,
            ),
        )


# =============================================================================
# ORGANIZATIONAL ATLAS
# =============================================================================

@dataclass
class OrganizationalAtlas(SerializableMixin):
    """First-class scientific object representing an Organizational Atlas."""

    metadata: AtlasMetadata
    state: AtlasState = AtlasState.INITIALIZED

    representation: RepresentationArtifacts | None = None
    organization: OrganizationArtifacts | None = None
    coordinates: list[OrganizationalCoordinate] = field(default_factory=list)
    qualification: AtlasQualification | None = None

    reports: dict[str, Path] = field(default_factory=dict)
    figures: dict[str, Path] = field(default_factory=dict)
    tables: dict[str, Path] = field(default_factory=dict)

    lifecycle_notes: list[str] = field(default_factory=list)

    def validate(self) -> None:
        self.metadata.validate()

        if self.representation is not None:
            self.representation.validate()

        if self.organization is not None:
            self.organization.validate()

        for coordinate in self.coordinates:
            coordinate.validate()

        if self.qualification is not None:
            self.qualification.validate()

        if self.state == AtlasState.CONSTRUCTED:
            if self.representation is None or self.organization is None:
                raise ValueError(
                    "A constructed atlas requires representation and organization."
                )

        if self.state == AtlasState.QUALIFIED:
            if self.qualification is None:
                raise ValueError(
                    "A qualified atlas requires an AtlasQualification record."
                )
            if self.qualification.qualification_level not in {
                QualificationLevel.QUALIFIED,
                QualificationLevel.REFERENCE,
            }:
                raise ValueError(
                    "AtlasState.QUALIFIED requires QUALIFIED or REFERENCE level."
                )

    def advance_state(self, new_state: AtlasState, note: str | None = None) -> None:
        order = list(AtlasState)
        current_index = order.index(self.state)
        new_index = order.index(new_state)

        if new_index < current_index:
            raise ValueError(
                f"Cannot move atlas backward from {self.state.value} "
                f"to {new_state.value}."
            )
        if new_index > current_index + 1:
            raise ValueError(
                f"Cannot skip lifecycle states from {self.state.value} "
                f"to {new_state.value}."
            )

        self.state = new_state
        if note:
            self.lifecycle_notes.append(note)
        self.validate()

    def register_output(
        self,
        category: str,
        name: str,
        path: Path,
    ) -> None:
        category_map = {
            "report": self.reports,
            "figure": self.figures,
            "table": self.tables,
        }
        if category not in category_map:
            raise ValueError(
                "category must be one of: report, figure, table."
            )
        category_map[category][name] = path

    @property
    def atlas_id(self) -> str:
        safe_name = "_".join(self.metadata.atlas_name.lower().split())
        return f"{safe_name}_v{self.metadata.atlas_version}"

    def qualification_summary(self) -> dict[str, Any]:
        if self.qualification is None:
            return {
                "atlas_id": self.atlas_id,
                "state": self.state.value,
                "qualification_level": QualificationLevel.EXPLORATORY.value,
                "overall_confidence": None,
                "entitlement": False,
            }

        return {
            "atlas_id": self.atlas_id,
            "state": self.state.value,
            "qualification_level": self.qualification.qualification_level.value,
            "overall_confidence": self.qualification.overall_confidence,
            "entitlement": self.qualification.entitlement,
            "limitations": self.qualification.aggregate_limitations(),
            "recommendations": [
                item.to_dict()
                for item in self.qualification.aggregate_recommendations()
            ],
        }
