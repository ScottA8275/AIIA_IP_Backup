#!/usr/bin/env python3
"""
Structural Intelligence Qualification Framework
Mathematical metrics for Organizational Atlas qualification.

This module provides:

- self-documenting metric results
- confidence and evidence accounting
- occupancy and imbalance diagnostics
- basin alignment and split/merge analysis
- transition and topology comparisons
- corridor and bottleneck recurrence
- temporal scaffold and novelty metrics
- null-model effect sizes
- phase-confidence aggregation

The implementation is domain-neutral.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from math import exp, log2, sqrt
from typing import Any, Callable, Iterable, Mapping, Sequence

import networkx as nx
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist, jensenshannon
from scipy.stats import mannwhitneyu
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

from qualification_config import (
    MetricDirection,
    MetricThreshold,
    PhasePolicy,
    QualificationPolicy,
    ThresholdSeverity,
)
from qualification_types import ReviewStatus


# =============================================================================
# RESULT TYPES
# =============================================================================

class MetricState(str, Enum):
    SUPPORTED = "supported"
    NOT_SUPPORTED = "not_supported"
    NOT_EVALUATED = "not_evaluated"
    INVALID = "invalid"


@dataclass
class MetricResult:
    """Self-documenting output for one qualification metric."""

    metric_id: str
    display_name: str
    value: float | None
    confidence: float | None
    state: MetricState
    n_evidence: int = 0

    effect_size: float | None = None
    threshold: float | tuple[float, float] | None = None
    direction: MetricDirection | None = None
    severity: ThresholdSeverity | None = None

    distribution: list[float] = field(default_factory=list)
    components: dict[str, Any] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    limitations: list[str] = field(default_factory=list)
    failure_reason: str | None = None
    recommendation: str | None = None

    @property
    def evaluated(self) -> bool:
        return self.state not in {MetricState.NOT_EVALUATED, MetricState.INVALID}

    @property
    def supported(self) -> bool | None:
        if self.state == MetricState.SUPPORTED:
            return True
        if self.state == MetricState.NOT_SUPPORTED:
            return False
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "metric_id": self.metric_id,
            "display_name": self.display_name,
            "value": self.value,
            "confidence": self.confidence,
            "state": self.state.value,
            "supported": self.supported,
            "n_evidence": self.n_evidence,
            "effect_size": self.effect_size,
            "threshold": self.threshold,
            "direction": self.direction.value if self.direction else None,
            "severity": self.severity.value if self.severity else None,
            "distribution": self.distribution,
            "components": self.components,
            "notes": self.notes,
            "limitations": self.limitations,
            "failure_reason": self.failure_reason,
            "recommendation": self.recommendation,
        }


@dataclass
class PhaseScore:
    """Aggregated evidence and confidence for one review phase."""

    phase_id: str
    display_name: str
    confidence: float | None
    status: ReviewStatus
    evaluated_weight_fraction: float
    supported_weight_fraction: float
    critical_failures: list[str] = field(default_factory=list)
    unavailable_critical_metrics: list[str] = field(default_factory=list)
    metric_results: dict[str, MetricResult] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "phase_id": self.phase_id,
            "display_name": self.display_name,
            "confidence": self.confidence,
            "status": self.status.value,
            "evaluated_weight_fraction": self.evaluated_weight_fraction,
            "supported_weight_fraction": self.supported_weight_fraction,
            "critical_failures": self.critical_failures,
            "unavailable_critical_metrics": self.unavailable_critical_metrics,
            "metric_results": {
                key: value.to_dict()
                for key, value in self.metric_results.items()
            },
            "notes": self.notes,
        }


# =============================================================================
# NUMERICAL UTILITIES
# =============================================================================

EPS = 1e-12


def finite_array(values: Sequence[float] | np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float).ravel()
    return arr[np.isfinite(arr)]


def clip01(value: float) -> float:
    return float(np.clip(value, 0.0, 1.0))


def safe_divide(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return float(numerator / denominator)


def normalize_distribution(values: Sequence[float]) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    arr = np.clip(arr, 0.0, None)
    total = arr.sum()
    if total <= 0:
        return np.zeros_like(arr)
    return arr / total


def entropy_bits(values: Sequence[float], *, normalized: bool = False) -> float:
    probabilities = normalize_distribution(values)
    positive = probabilities[probabilities > 0]
    if positive.size == 0:
        return 0.0
    entropy = float(-(positive * np.log2(positive)).sum())
    if normalized and len(probabilities) > 1:
        entropy /= log2(len(probabilities))
    return entropy


def effective_category_count(values: Sequence[float]) -> float:
    return float(2.0 ** entropy_bits(values))


def gini_index(values: Sequence[float]) -> float:
    arr = finite_array(values)
    arr = arr[arr >= 0]
    if arr.size == 0 or np.allclose(arr.sum(), 0.0):
        return 0.0
    arr = np.sort(arr)
    n = arr.size
    cumulative = np.cumsum(arr)
    return float((n + 1 - 2 * np.sum(cumulative) / cumulative[-1]) / n)


def coefficient_of_variation(values: Sequence[float]) -> float | None:
    arr = finite_array(values)
    if arr.size < 2:
        return None
    mean = float(np.mean(arr))
    if abs(mean) < EPS:
        return None
    return float(np.std(arr, ddof=1) / abs(mean))


def confidence_from_evidence(
    *,
    n_evidence: int,
    agreement: float | None = None,
    effect_size: float | None = None,
    dispersion: float | None = None,
    target_n: int = 10,
) -> float:
    """
    Derive confidence from evidence quantity, agreement, effect size, and spread.

    This score is an evidence-strength measure, not the qualification metric itself.
    """
    n_score = 1.0 - exp(-max(n_evidence, 0) / max(target_n, 1))
    agreement_score = 0.5 if agreement is None else clip01(agreement)
    effect_score = 0.5 if effect_size is None else clip01(abs(effect_size) / 2.0)
    dispersion_score = (
        0.5
        if dispersion is None
        else clip01(1.0 / (1.0 + max(dispersion, 0.0)))
    )
    return clip01(
        0.35 * n_score
        + 0.30 * agreement_score
        + 0.20 * effect_score
        + 0.15 * dispersion_score
    )


def threshold_state(
    value: float | None,
    threshold: MetricThreshold | None,
) -> MetricState:
    if value is None:
        return MetricState.NOT_EVALUATED
    if not np.isfinite(value):
        return MetricState.INVALID
    if threshold is None:
        return MetricState.SUPPORTED
    return (
        MetricState.SUPPORTED
        if threshold.is_supported(float(value))
        else MetricState.NOT_SUPPORTED
    )


def build_metric_result(
    metric_id: str,
    display_name: str,
    value: float | None,
    *,
    threshold: MetricThreshold | None = None,
    confidence: float | None = None,
    n_evidence: int = 0,
    effect_size: float | None = None,
    distribution: Sequence[float] = (),
    components: Mapping[str, Any] | None = None,
    notes: Sequence[str] = (),
    limitations: Sequence[str] = (),
    failure_reason: str | None = None,
    recommendation: str | None = None,
) -> MetricResult:
    state = threshold_state(value, threshold)
    if state == MetricState.NOT_SUPPORTED and failure_reason is None:
        failure_reason = "Observed value did not meet the configured threshold."
    return MetricResult(
        metric_id=metric_id,
        display_name=display_name,
        value=None if value is None else float(value),
        confidence=confidence,
        state=state,
        n_evidence=n_evidence,
        effect_size=effect_size,
        threshold=threshold.threshold if threshold else None,
        direction=threshold.direction if threshold else None,
        severity=threshold.severity if threshold else None,
        distribution=[float(x) for x in finite_array(distribution)],
        components=dict(components or {}),
        notes=list(notes),
        limitations=list(limitations),
        failure_reason=failure_reason,
        recommendation=recommendation,
    )


# =============================================================================
# OCCUPANCY AND IMBALANCE
# =============================================================================

def occupancy_counts(
    assignments: Sequence[int],
    labels: Sequence[int] | None = None,
) -> pd.Series:
    series = pd.Series(assignments, dtype="int64")
    counts = series.value_counts().sort_index()
    if labels is not None:
        counts = counts.reindex(labels, fill_value=0)
    return counts.astype(int)


def occupancy_profile(
    assignments: Sequence[int],
    labels: Sequence[int] | None = None,
) -> pd.DataFrame:
    counts = occupancy_counts(assignments, labels)
    total = int(counts.sum())
    frame = counts.rename("count").to_frame()
    frame["fraction"] = frame["count"] / max(total, 1)
    frame.index.name = "basin_id"
    return frame.reset_index()


def occupancy_diagnostics(
    assignments: Sequence[int],
    *,
    rare_threshold: float = 0.01,
) -> dict[str, float]:
    counts = occupancy_counts(assignments)
    fractions = normalize_distribution(counts.values)
    if fractions.size == 0:
        return {
            "n_basins": 0.0,
            "occupancy_entropy_bits": 0.0,
            "normalized_occupancy_entropy": 0.0,
            "effective_number_of_basins": 0.0,
            "maximum_basin_occupancy": 0.0,
            "rare_basin_fraction": 0.0,
            "tail_occupancy_fraction": 0.0,
            "occupancy_gini": 0.0,
        }

    sorted_fraction = np.sort(fractions)[::-1]
    rare_mask = fractions < rare_threshold
    tail_fraction = float(sorted_fraction[1:].sum()) if len(sorted_fraction) > 1 else 0.0

    return {
        "n_basins": float(len(fractions)),
        "occupancy_entropy_bits": entropy_bits(fractions),
        "normalized_occupancy_entropy": entropy_bits(fractions, normalized=True),
        "effective_number_of_basins": effective_category_count(fractions),
        "maximum_basin_occupancy": float(np.max(fractions)),
        "rare_basin_fraction": float(np.mean(rare_mask)),
        "tail_occupancy_fraction": tail_fraction,
        "occupancy_gini": gini_index(fractions),
    }


def maximum_basin_occupancy_result(
    assignments: Sequence[int],
    threshold: MetricThreshold | None = None,
) -> MetricResult:
    diagnostics = occupancy_diagnostics(assignments)
    maximum = diagnostics["maximum_basin_occupancy"]
    confidence = confidence_from_evidence(
        n_evidence=len(assignments),
        agreement=1.0 - maximum,
        target_n=10_000,
    )
    reason = None
    recommendation = None
    if threshold and not threshold.is_supported(maximum):
        reason = (
            "One basin contains a disproportionate share of observations. "
            "This may represent a true dominant regime or atlas collapse."
        )
        recommendation = (
            "Inspect dominant-basin internal structure and run hierarchical "
            "split analysis before interpreting rare basins."
        )
    return build_metric_result(
        "maximum_basin_occupancy",
        "Maximum single-basin occupancy",
        maximum,
        threshold=threshold,
        confidence=confidence,
        n_evidence=len(assignments),
        components=diagnostics,
        failure_reason=reason,
        recommendation=recommendation,
    )


# =============================================================================
# BASIN ALIGNMENT AND REPRESENTATION STABILITY
# =============================================================================

def contingency_matrix(
    reference: Sequence[int],
    candidate: Sequence[int],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    ref = np.asarray(reference)
    cand = np.asarray(candidate)
    if len(ref) != len(cand):
        raise ValueError("Assignment vectors must have equal length.")
    ref_labels = np.unique(ref)
    cand_labels = np.unique(cand)
    matrix = np.zeros((len(ref_labels), len(cand_labels)), dtype=int)
    ref_index = {label: i for i, label in enumerate(ref_labels)}
    cand_index = {label: i for i, label in enumerate(cand_labels)}
    for r, c in zip(ref, cand):
        matrix[ref_index[r], cand_index[c]] += 1
    return matrix, ref_labels, cand_labels


def align_labels_hungarian(
    reference: Sequence[int],
    candidate: Sequence[int],
) -> tuple[np.ndarray, dict[int, int], pd.DataFrame]:
    matrix, ref_labels, cand_labels = contingency_matrix(reference, candidate)
    if matrix.size == 0:
        return np.asarray(candidate), {}, pd.DataFrame()

    row_ind, col_ind = linear_sum_assignment(-matrix)
    mapping = {
        int(cand_labels[col]): int(ref_labels[row])
        for row, col in zip(row_ind, col_ind)
    }

    next_label = int(np.max(ref_labels)) + 1 if len(ref_labels) else 0
    for label in cand_labels:
        if int(label) not in mapping:
            mapping[int(label)] = next_label
            next_label += 1

    aligned = np.array([mapping[int(x)] for x in candidate], dtype=int)
    table = pd.DataFrame(matrix, index=ref_labels, columns=cand_labels)
    table.index.name = "reference_basin"
    table.columns.name = "candidate_basin"
    return aligned, mapping, table


def aligned_ari(
    reference: Sequence[int],
    candidate: Sequence[int],
) -> float:
    aligned, _, _ = align_labels_hungarian(reference, candidate)
    return float(adjusted_rand_score(reference, aligned))


def dominant_minor_stability(
    reference: Sequence[int],
    candidate: Sequence[int],
) -> dict[str, float]:
    ref = np.asarray(reference)
    aligned, _, _ = align_labels_hungarian(reference, candidate)
    counts = occupancy_counts(ref)
    dominant = int(counts.idxmax())
    dominant_mask = ref == dominant
    minor_mask = ~dominant_mask

    dominant_score = (
        float(np.mean(aligned[dominant_mask] == ref[dominant_mask]))
        if dominant_mask.any()
        else np.nan
    )
    minor_score = (
        float(np.mean(aligned[minor_mask] == ref[minor_mask]))
        if minor_mask.any()
        else np.nan
    )

    return {
        "dominant_basin_id": float(dominant),
        "dominant_basin_stability": dominant_score,
        "minor_basin_stability": minor_score,
        "overall_accuracy_after_alignment": float(np.mean(aligned == ref)),
    }


def split_merge_analysis(
    reference: Sequence[int],
    candidate: Sequence[int],
    *,
    purity_threshold: float = 0.70,
) -> dict[str, Any]:
    matrix, ref_labels, cand_labels = contingency_matrix(reference, candidate)
    if matrix.size == 0:
        return {
            "split_count": 0,
            "merge_count": 0,
            "split_merge_consistency": None,
            "reference_detail": pd.DataFrame(),
            "candidate_detail": pd.DataFrame(),
        }

    ref_detail = []
    for i, label in enumerate(ref_labels):
        row = matrix[i].astype(float)
        total = row.sum()
        proportions = row / max(total, 1.0)
        ref_detail.append({
            "reference_basin": int(label),
            "count": int(total),
            "max_candidate_fraction": float(proportions.max(initial=0.0)),
            "n_material_candidate_basins": int(np.sum(proportions >= (1.0 - purity_threshold))),
        })

    cand_detail = []
    for j, label in enumerate(cand_labels):
        column = matrix[:, j].astype(float)
        total = column.sum()
        proportions = column / max(total, 1.0)
        cand_detail.append({
            "candidate_basin": int(label),
            "count": int(total),
            "max_reference_fraction": float(proportions.max(initial=0.0)),
            "n_material_reference_basins": int(np.sum(proportions >= (1.0 - purity_threshold))),
        })

    ref_frame = pd.DataFrame(ref_detail)
    cand_frame = pd.DataFrame(cand_detail)

    split_count = int((ref_frame["max_candidate_fraction"] < purity_threshold).sum())
    merge_count = int((cand_frame["max_reference_fraction"] < purity_threshold).sum())

    weighted_purity_ref = float(
        np.average(
            ref_frame["max_candidate_fraction"],
            weights=ref_frame["count"],
        )
    )
    weighted_purity_cand = float(
        np.average(
            cand_frame["max_reference_fraction"],
            weights=cand_frame["count"],
        )
    )
    consistency = float(sqrt(weighted_purity_ref * weighted_purity_cand))

    return {
        "split_count": split_count,
        "merge_count": merge_count,
        "weighted_reference_purity": weighted_purity_ref,
        "weighted_candidate_purity": weighted_purity_cand,
        "split_merge_consistency": consistency,
        "reference_detail": ref_frame,
        "candidate_detail": cand_frame,
    }


def pairwise_seed_stability(
    assignments_by_seed: Mapping[int, Sequence[int]],
) -> pd.DataFrame:
    seeds = sorted(assignments_by_seed)
    records: list[dict[str, Any]] = []

    for i, seed_a in enumerate(seeds):
        for seed_b in seeds[i + 1:]:
            a = np.asarray(assignments_by_seed[seed_a])
            b = np.asarray(assignments_by_seed[seed_b])
            if len(a) != len(b):
                raise ValueError("All seed assignment arrays must have equal length.")

            aligned_b, _, _ = align_labels_hungarian(a, b)
            dom_minor = dominant_minor_stability(a, b)
            split_merge = split_merge_analysis(a, b)

            records.append({
                "seed_a": seed_a,
                "seed_b": seed_b,
                "aligned_ari": adjusted_rand_score(a, aligned_b),
                "nmi": normalized_mutual_info_score(a, b),
                "dominant_basin_stability": dom_minor["dominant_basin_stability"],
                "minor_basin_stability": dom_minor["minor_basin_stability"],
                "aligned_accuracy": dom_minor["overall_accuracy_after_alignment"],
                "split_merge_consistency": split_merge["split_merge_consistency"],
            })

    return pd.DataFrame.from_records(records)


def seed_stability_results(
    assignments_by_seed: Mapping[int, Sequence[int]],
    thresholds: Mapping[str, MetricThreshold],
) -> dict[str, MetricResult]:
    pairwise = pairwise_seed_stability(assignments_by_seed)
    if pairwise.empty:
        limitation = "At least two completed seed runs are required."
        return {
            metric_id: build_metric_result(
                metric_id,
                thresholds[metric_id].display_name,
                None,
                threshold=thresholds[metric_id],
                limitations=[limitation],
                failure_reason=limitation,
            )
            for metric_id in (
                "seed_median_aligned_ari",
                "seed_dominant_basin_stability",
                "seed_minor_basin_stability",
            )
        }

    metric_columns = {
        "seed_median_aligned_ari": "aligned_ari",
        "seed_dominant_basin_stability": "dominant_basin_stability",
        "seed_minor_basin_stability": "minor_basin_stability",
    }

    results: dict[str, MetricResult] = {}
    for metric_id, column in metric_columns.items():
        values = finite_array(pairwise[column])
        median = float(np.median(values)) if values.size else None
        dispersion = coefficient_of_variation(values)
        confidence = confidence_from_evidence(
            n_evidence=len(values),
            agreement=median,
            dispersion=dispersion,
            target_n=10,
        )
        results[metric_id] = build_metric_result(
            metric_id,
            thresholds[metric_id].display_name,
            median,
            threshold=thresholds[metric_id],
            confidence=confidence,
            n_evidence=len(values),
            distribution=values,
            components={
                "median": median,
                "minimum": float(np.min(values)) if values.size else None,
                "maximum": float(np.max(values)) if values.size else None,
                "pairwise_table": pairwise.to_dict(orient="records"),
            },
            recommendation=(
                thresholds[metric_id].recommendation_on_failure.value
                if thresholds[metric_id].recommendation_on_failure
                else None
            ),
        )
    return results


# =============================================================================
# PROFILE AND PARAMETER SIMILARITY
# =============================================================================

def weighted_profile_similarity(
    reference_profiles: np.ndarray,
    candidate_profiles: np.ndarray,
    reference_weights: Sequence[float] | None = None,
) -> float:
    """
    Align basin profiles by cosine distance and return occupancy-weighted similarity.
    """
    ref = np.asarray(reference_profiles, dtype=float)
    cand = np.asarray(candidate_profiles, dtype=float)
    if ref.ndim != 2 or cand.ndim != 2 or ref.shape[1] != cand.shape[1]:
        raise ValueError("Profile matrices must be 2D with matching feature columns.")
    if ref.shape[0] == 0 or cand.shape[0] == 0:
        return 0.0

    ref_norm = ref / np.maximum(np.linalg.norm(ref, axis=1, keepdims=True), EPS)
    cand_norm = cand / np.maximum(np.linalg.norm(cand, axis=1, keepdims=True), EPS)
    similarity = ref_norm @ cand_norm.T
    row_ind, col_ind = linear_sum_assignment(-similarity)

    matched = similarity[row_ind, col_ind]
    if reference_weights is None:
        return float(np.mean(np.clip(matched, -1.0, 1.0)))

    weights = normalize_distribution(reference_weights)
    matched_weights = weights[row_ind]
    if matched_weights.sum() <= 0:
        return float(np.mean(np.clip(matched, -1.0, 1.0)))
    return float(
        np.average(np.clip(matched, -1.0, 1.0), weights=matched_weights)
    )


# =============================================================================
# TRANSITION METRICS
# =============================================================================

def transition_counts(
    assignments: Sequence[int],
    sequence_ids: Sequence[Any] | None = None,
) -> pd.DataFrame:
    labels = np.asarray(assignments)
    if sequence_ids is None:
        sequence_ids = np.zeros(len(labels), dtype=int)
    sequences = np.asarray(sequence_ids)
    if len(labels) != len(sequences):
        raise ValueError("assignments and sequence_ids must have equal length.")

    records: list[tuple[int, int]] = []
    for i in range(len(labels) - 1):
        if sequences[i] != sequences[i + 1]:
            continue
        records.append((int(labels[i]), int(labels[i + 1])))

    if not records:
        return pd.DataFrame(columns=["source", "target", "count", "probability"])

    frame = (
        pd.DataFrame(records, columns=["source", "target"])
        .value_counts()
        .rename("count")
        .reset_index()
    )
    totals = frame.groupby("source")["count"].transform("sum")
    frame["probability"] = frame["count"] / totals
    return frame.sort_values(["source", "target"]).reset_index(drop=True)


def self_transition_probability(
    assignments: Sequence[int],
    sequence_ids: Sequence[Any] | None = None,
) -> float | None:
    """
    Correct persistence calculation.

    Numerator: valid within-sequence transitions whose target equals source.
    Denominator: all valid within-sequence transitions.
    """
    labels = np.asarray(assignments)
    if sequence_ids is None:
        sequence_ids = np.zeros(len(labels), dtype=int)
    sequences = np.asarray(sequence_ids)

    if len(labels) != len(sequences):
        raise ValueError("assignments and sequence_ids must have equal length.")
    if len(labels) < 2:
        return None

    valid = sequences[:-1] == sequences[1:]
    denominator = int(valid.sum())
    if denominator == 0:
        return None
    numerator = int(np.sum((labels[:-1] == labels[1:]) & valid))
    probability = numerator / denominator

    if not 0.0 <= probability <= 1.0:
        raise RuntimeError("Persistence calculation escaped the [0, 1] interval.")
    return float(probability)


def basin_persistence_table(
    assignments: Sequence[int],
    sequence_ids: Sequence[Any] | None = None,
) -> pd.DataFrame:
    labels = np.asarray(assignments)
    if sequence_ids is None:
        sequence_ids = np.zeros(len(labels), dtype=int)
    sequences = np.asarray(sequence_ids)

    records = []
    for basin in np.unique(labels):
        source_mask = labels[:-1] == basin
        sequence_mask = sequences[:-1] == sequences[1:]
        valid = source_mask & sequence_mask
        n_outgoing = int(valid.sum())
        n_self = int(np.sum(valid & (labels[1:] == basin)))
        probability = n_self / n_outgoing if n_outgoing else np.nan
        records.append({
            "basin_id": int(basin),
            "n_outgoing_transitions": n_outgoing,
            "n_self_transitions": n_self,
            "self_transition_probability": probability,
        })
    return pd.DataFrame(records)


def transition_matrix(
    table: pd.DataFrame,
    labels: Sequence[int] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    if labels is None:
        labels = sorted(
            set(table.get("source", pd.Series(dtype=int)).tolist())
            | set(table.get("target", pd.Series(dtype=int)).tolist())
        )
    labels_arr = np.asarray(labels, dtype=int)
    index = {label: i for i, label in enumerate(labels_arr)}
    matrix = np.zeros((len(labels_arr), len(labels_arr)), dtype=float)
    for row in table.itertuples(index=False):
        if row.source in index and row.target in index:
            matrix[index[row.source], index[row.target]] = float(row.probability)
    return matrix, labels_arr


def transition_graph_similarity(
    reference_table: pd.DataFrame,
    candidate_table: pd.DataFrame,
) -> dict[str, float]:
    labels = sorted(
        set(reference_table.get("source", pd.Series(dtype=int)).tolist())
        | set(reference_table.get("target", pd.Series(dtype=int)).tolist())
        | set(candidate_table.get("source", pd.Series(dtype=int)).tolist())
        | set(candidate_table.get("target", pd.Series(dtype=int)).tolist())
    )
    if not labels:
        return {
            "weighted_jensen_shannon_similarity": 1.0,
            "edge_jaccard_similarity": 1.0,
            "combined_similarity": 1.0,
        }

    ref, _ = transition_matrix(reference_table, labels)
    cand, _ = transition_matrix(candidate_table, labels)

    row_weights = normalize_distribution(ref.sum(axis=1) + cand.sum(axis=1))
    row_similarities = []
    for i in range(len(labels)):
        p = normalize_distribution(ref[i])
        q = normalize_distribution(cand[i])
        if np.allclose(p.sum(), 0) and np.allclose(q.sum(), 0):
            similarity = 1.0
        elif np.allclose(p.sum(), 0) or np.allclose(q.sum(), 0):
            similarity = 0.0
        else:
            similarity = 1.0 - float(jensenshannon(p, q, base=2.0))
        row_similarities.append(similarity)

    weighted_js = (
        float(np.average(row_similarities, weights=row_weights))
        if row_weights.sum() > 0
        else float(np.mean(row_similarities))
    )

    ref_edges = set(
        zip(
            reference_table.loc[reference_table["count"] > 0, "source"],
            reference_table.loc[reference_table["count"] > 0, "target"],
        )
    )
    cand_edges = set(
        zip(
            candidate_table.loc[candidate_table["count"] > 0, "source"],
            candidate_table.loc[candidate_table["count"] > 0, "target"],
        )
    )
    union = ref_edges | cand_edges
    edge_jaccard = len(ref_edges & cand_edges) / len(union) if union else 1.0
    combined = sqrt(max(weighted_js, 0.0) * max(edge_jaccard, 0.0))

    return {
        "weighted_jensen_shannon_similarity": weighted_js,
        "edge_jaccard_similarity": float(edge_jaccard),
        "combined_similarity": float(combined),
    }


def transition_concentration(table: pd.DataFrame, top_k: int = 10) -> float:
    if table.empty or table["count"].sum() == 0:
        return 0.0
    counts = table["count"].sort_values(ascending=False)
    return float(counts.head(top_k).sum() / counts.sum())


def transition_entropy(table: pd.DataFrame) -> float:
    if table.empty:
        return 0.0
    return entropy_bits(table["count"].to_numpy())


# =============================================================================
# TOPOLOGY METRICS
# =============================================================================

def graph_from_transition_table(
    table: pd.DataFrame,
    *,
    minimum_count: int = 1,
) -> nx.DiGraph:
    graph = nx.DiGraph()
    for row in table.itertuples(index=False):
        if int(row.count) < minimum_count:
            continue
        graph.add_edge(
            int(row.source),
            int(row.target),
            count=int(row.count),
            probability=float(row.probability),
            weight=float(row.probability),
        )
    return graph


def topology_descriptors(graph: nx.DiGraph) -> dict[str, float | None]:
    if graph.number_of_nodes() == 0:
        return {
            "n_nodes": 0.0,
            "n_edges": 0.0,
            "weak_components": 0.0,
            "strong_components": 0.0,
            "density": 0.0,
            "average_clustering": None,
            "assortativity": None,
            "spectral_gap": None,
            "hub_dominance": None,
            "mean_betweenness": None,
        }

    undirected = graph.to_undirected()
    betweenness = nx.betweenness_centrality(graph, weight=None, normalized=True)
    out_degree = np.array([d for _, d in graph.out_degree()], dtype=float)
    max_possible = max(graph.number_of_nodes() - 1, 1)

    adjacency = nx.to_numpy_array(graph, weight="probability", dtype=float)
    eigenvalues = np.linalg.eigvals(adjacency)
    magnitudes = np.sort(np.abs(eigenvalues))[::-1]
    spectral_gap = (
        float(magnitudes[0] - magnitudes[1])
        if len(magnitudes) >= 2
        else float(magnitudes[0]) if len(magnitudes) == 1 else None
    )

    try:
        assortativity = float(nx.degree_assortativity_coefficient(undirected))
        if not np.isfinite(assortativity):
            assortativity = None
    except Exception:
        assortativity = None

    return {
        "n_nodes": float(graph.number_of_nodes()),
        "n_edges": float(graph.number_of_edges()),
        "weak_components": float(nx.number_weakly_connected_components(graph)),
        "strong_components": float(nx.number_strongly_connected_components(graph)),
        "density": float(nx.density(graph)),
        "average_clustering": float(nx.average_clustering(undirected)),
        "assortativity": assortativity,
        "spectral_gap": spectral_gap,
        "hub_dominance": float(out_degree.max(initial=0.0) / max_possible),
        "mean_betweenness": float(np.mean(list(betweenness.values()))),
    }


def topology_similarity(
    reference_graph: nx.DiGraph,
    candidate_graph: nx.DiGraph,
) -> dict[str, Any]:
    ref_desc = topology_descriptors(reference_graph)
    cand_desc = topology_descriptors(candidate_graph)

    comparable = [
        "density",
        "average_clustering",
        "spectral_gap",
        "hub_dominance",
        "mean_betweenness",
    ]
    component_scores = {}
    for key in comparable:
        a = ref_desc.get(key)
        b = cand_desc.get(key)
        if a is None or b is None:
            continue
        denominator = max(abs(float(a)), abs(float(b)), EPS)
        component_scores[key] = clip01(1.0 - abs(float(a) - float(b)) / denominator)

    ref_edges = set(reference_graph.edges())
    cand_edges = set(candidate_graph.edges())
    edge_union = ref_edges | cand_edges
    edge_jaccard = len(ref_edges & cand_edges) / len(edge_union) if edge_union else 1.0

    descriptor_similarity = (
        float(np.mean(list(component_scores.values())))
        if component_scores
        else None
    )
    combined = (
        sqrt(edge_jaccard * descriptor_similarity)
        if descriptor_similarity is not None
        else float(edge_jaccard)
    )

    return {
        "edge_jaccard_similarity": float(edge_jaccard),
        "descriptor_similarity": descriptor_similarity,
        "combined_similarity": float(combined),
        "descriptor_components": component_scores,
        "reference_descriptors": ref_desc,
        "candidate_descriptors": cand_desc,
    }


# =============================================================================
# CORRIDORS AND BOTTLENECKS
# =============================================================================

def recurrent_edge_fraction(
    reference_edges: Iterable[tuple[int, int]],
    candidate_edges: Iterable[tuple[int, int]],
) -> float:
    ref = set(reference_edges)
    cand = set(candidate_edges)
    if not ref:
        return 1.0 if not cand else 0.0
    return float(len(ref & cand) / len(ref))


def top_bottleneck_edges(
    graph: nx.DiGraph,
    *,
    top_fraction: float = 0.10,
) -> set[tuple[int, int]]:
    if graph.number_of_edges() == 0:
        return set()
    centrality = nx.edge_betweenness_centrality(graph, normalized=True)
    n_top = max(1, int(np.ceil(len(centrality) * top_fraction)))
    return {
        edge
        for edge, _ in sorted(
            centrality.items(),
            key=lambda item: item[1],
            reverse=True,
        )[:n_top]
    }


# =============================================================================
# TEMPORAL SCAFFOLD, TRANSFER, AND NOVELTY
# =============================================================================

def centroid_assignment(
    states: np.ndarray,
    centroids: np.ndarray,
) -> np.ndarray:
    if len(states) == 0 or len(centroids) == 0:
        return np.array([], dtype=int)
    distances = cdist(np.asarray(states, dtype=float), np.asarray(centroids, dtype=float))
    return np.argmin(distances, axis=1).astype(int)


def shared_scaffold_similarity(
    reference_profiles: np.ndarray,
    candidate_profiles: np.ndarray,
    reference_transitions: pd.DataFrame,
    candidate_transitions: pd.DataFrame,
    reference_weights: Sequence[float] | None = None,
) -> dict[str, float]:
    profile_score = weighted_profile_similarity(
        reference_profiles,
        candidate_profiles,
        reference_weights,
    )
    transition_score = transition_graph_similarity(
        reference_transitions,
        candidate_transitions,
    )["combined_similarity"]
    combined = sqrt(max(profile_score, 0.0) * max(transition_score, 0.0))
    return {
        "profile_similarity": float(profile_score),
        "transition_similarity": float(transition_score),
        "shared_scaffold_similarity": float(combined),
    }


def occupancy_shift(
    reference_assignments: Sequence[int],
    candidate_assignments: Sequence[int],
) -> dict[str, float]:
    labels = sorted(
        set(np.asarray(reference_assignments).tolist())
        | set(np.asarray(candidate_assignments).tolist())
    )
    ref = normalize_distribution(occupancy_counts(reference_assignments, labels).values)
    cand = normalize_distribution(occupancy_counts(candidate_assignments, labels).values)
    js_distance = float(jensenshannon(ref, cand, base=2.0))
    total_variation = float(0.5 * np.abs(ref - cand).sum())
    return {
        "jensen_shannon_distance": js_distance,
        "jensen_shannon_similarity": 1.0 - js_distance,
        "total_variation_distance": total_variation,
    }


def novel_region_analysis(
    reference_centroids: np.ndarray,
    candidate_states: np.ndarray,
    *,
    novelty_quantile: float = 0.99,
    calibration_states: np.ndarray | None = None,
) -> dict[str, Any]:
    ref_centroids = np.asarray(reference_centroids, dtype=float)
    candidate = np.asarray(candidate_states, dtype=float)

    if len(ref_centroids) == 0 or len(candidate) == 0:
        return {
            "novel_fraction": None,
            "novel_count": 0,
            "threshold": None,
            "distances": np.array([]),
        }

    candidate_distances = cdist(candidate, ref_centroids).min(axis=1)

    if calibration_states is not None and len(calibration_states):
        calibration_distances = cdist(
            np.asarray(calibration_states, dtype=float),
            ref_centroids,
        ).min(axis=1)
        threshold = float(np.quantile(calibration_distances, novelty_quantile))
    else:
        threshold = float(np.quantile(candidate_distances, novelty_quantile))

    novel_mask = candidate_distances > threshold
    return {
        "novel_fraction": float(np.mean(novel_mask)),
        "novel_count": int(novel_mask.sum()),
        "threshold": threshold,
        "distances": candidate_distances,
        "novel_mask": novel_mask,
    }


# =============================================================================
# NULL-MODEL EFFECT SIZES
# =============================================================================

def cohens_d(observed: Sequence[float], null: Sequence[float]) -> float | None:
    x = finite_array(observed)
    y = finite_array(null)
    if len(x) < 2 or len(y) < 2:
        return None
    pooled_variance = (
        ((len(x) - 1) * np.var(x, ddof=1) + (len(y) - 1) * np.var(y, ddof=1))
        / (len(x) + len(y) - 2)
    )
    if pooled_variance <= EPS:
        return 0.0 if np.isclose(np.mean(x), np.mean(y)) else np.inf
    return float((np.mean(x) - np.mean(y)) / sqrt(pooled_variance))


def cliffs_delta(observed: Sequence[float], null: Sequence[float]) -> float | None:
    x = finite_array(observed)
    y = finite_array(null)
    if len(x) == 0 or len(y) == 0:
        return None
    greater = 0
    less = 0
    for value in x:
        greater += int(np.sum(value > y))
        less += int(np.sum(value < y))
    return float((greater - less) / (len(x) * len(y)))


def null_separation(
    observed: Sequence[float],
    null: Sequence[float],
    *,
    higher_is_better: bool = True,
) -> dict[str, float | None]:
    x = finite_array(observed)
    y = finite_array(null)
    if len(x) == 0 or len(y) == 0:
        return {
            "cohens_d": None,
            "cliffs_delta": None,
            "mann_whitney_p": None,
            "directional_effect_size": None,
        }

    d = cohens_d(x, y)
    delta = cliffs_delta(x, y)
    alternative = "greater" if higher_is_better else "less"
    _, p = mannwhitneyu(x, y, alternative=alternative)

    directional = d if higher_is_better else (-d if d is not None else None)
    return {
        "cohens_d": d,
        "cliffs_delta": delta,
        "mann_whitney_p": float(p),
        "directional_effect_size": directional,
    }


def null_family_supported_fraction(
    family_results: Mapping[str, MetricResult],
) -> float | None:
    evaluated = [result for result in family_results.values() if result.evaluated]
    if not evaluated:
        return None
    return float(np.mean([result.state == MetricState.SUPPORTED for result in evaluated]))


# =============================================================================
# PHASE AGGREGATION
# =============================================================================

def aggregate_phase_score(
    phase_policy: PhasePolicy,
    thresholds: Mapping[str, MetricThreshold],
    metric_results: Mapping[str, MetricResult],
    *,
    unavailable_critical_blocks: bool = True,
) -> PhaseScore:
    phase_thresholds = [
        threshold
        for threshold in thresholds.values()
        if threshold.phase_id == phase_policy.phase_id
    ]

    total_weight = sum(threshold.weight for threshold in phase_thresholds)
    evaluated_weight = 0.0
    supported_weight = 0.0
    confidence_weighted_sum = 0.0
    confidence_weight = 0.0

    critical_failures: list[str] = []
    unavailable_critical: list[str] = []

    for threshold in phase_thresholds:
        result = metric_results.get(threshold.metric_id)
        if result is None or not result.evaluated:
            if threshold.metric_id in phase_policy.critical_metric_ids:
                unavailable_critical.append(threshold.metric_id)
            continue

        evaluated_weight += threshold.weight
        if result.state == MetricState.SUPPORTED:
            supported_weight += threshold.weight

        if result.confidence is not None:
            metric_support = 1.0 if result.state == MetricState.SUPPORTED else 0.0
            confidence_weighted_sum += (
                result.confidence * metric_support * threshold.weight
            )
            confidence_weight += threshold.weight

        if (
            threshold.metric_id in phase_policy.critical_metric_ids
            and result.state == MetricState.NOT_SUPPORTED
        ):
            critical_failures.append(threshold.metric_id)

    evaluated_fraction = safe_divide(evaluated_weight, total_weight)
    supported_fraction = safe_divide(supported_weight, evaluated_weight)
    confidence = (
        safe_divide(confidence_weighted_sum, confidence_weight)
        if confidence_weight > 0
        else None
    )

    if evaluated_fraction < phase_policy.minimum_evaluated_weight_fraction:
        status = ReviewStatus.INCOMPLETE
    elif critical_failures:
        status = ReviewStatus.CONCERN
    elif unavailable_critical and unavailable_critical_blocks:
        status = ReviewStatus.INCOMPLETE
    elif (
        confidence is not None
        and confidence >= 0.85
        and supported_fraction >= 0.90
    ):
        status = ReviewStatus.STRONGLY_SUPPORTED
    elif (
        confidence is not None
        and confidence >= phase_policy.minimum_confidence_for_support
        and supported_fraction >= 0.70
    ):
        status = ReviewStatus.SUPPORTED
    else:
        status = ReviewStatus.CONCERN

    notes = []
    if unavailable_critical:
        notes.append(
            "Critical evidence unavailable: "
            + ", ".join(unavailable_critical)
        )
    if critical_failures:
        notes.append(
            "Critical criteria not supported: "
            + ", ".join(critical_failures)
        )

    return PhaseScore(
        phase_id=phase_policy.phase_id,
        display_name=phase_policy.display_name,
        confidence=confidence,
        status=status,
        evaluated_weight_fraction=evaluated_fraction,
        supported_weight_fraction=supported_fraction,
        critical_failures=critical_failures,
        unavailable_critical_metrics=unavailable_critical,
        metric_results={
            key: value
            for key, value in metric_results.items()
            if key in {threshold.metric_id for threshold in phase_thresholds}
        },
        notes=notes,
    )


def aggregate_atlas_confidence(
    phase_scores: Mapping[str, PhaseScore],
    phase_policies: Sequence[PhasePolicy],
) -> float | None:
    weighted_sum = 0.0
    weight_sum = 0.0
    for policy in phase_policies:
        score = phase_scores.get(policy.phase_id)
        if score is None or score.confidence is None:
            continue
        evidence_factor = score.evaluated_weight_fraction
        effective_weight = policy.phase_weight * evidence_factor
        weighted_sum += score.confidence * effective_weight
        weight_sum += effective_weight
    if weight_sum == 0:
        return None
    return clip01(weighted_sum / weight_sum)


def score_all_phases(
    policy: QualificationPolicy,
    metric_results: Mapping[str, MetricResult],
) -> dict[str, PhaseScore]:
    thresholds = policy.threshold_map()
    return {
        phase_policy.phase_id: aggregate_phase_score(
            phase_policy,
            thresholds,
            metric_results,
            unavailable_critical_blocks=(
                policy.unavailable_critical_metric_blocks_qualification
            ),
        )
        for phase_policy in policy.phase_policies
    }


# =============================================================================
# PUBLIC SUMMARY
# =============================================================================

def metric_library_summary() -> dict[str, list[str]]:
    return {
        "representation": [
            "occupancy_diagnostics",
            "align_labels_hungarian",
            "aligned_ari",
            "dominant_minor_stability",
            "split_merge_analysis",
            "pairwise_seed_stability",
            "weighted_profile_similarity",
        ],
        "organization": [
            "self_transition_probability",
            "basin_persistence_table",
            "transition_graph_similarity",
            "transition_concentration",
            "transition_entropy",
            "topology_descriptors",
            "topology_similarity",
            "recurrent_edge_fraction",
            "top_bottleneck_edges",
        ],
        "temporal": [
            "shared_scaffold_similarity",
            "occupancy_shift",
            "novel_region_analysis",
            "centroid_assignment",
        ],
        "nulls": [
            "cohens_d",
            "cliffs_delta",
            "null_separation",
            "null_family_supported_fraction",
        ],
        "aggregation": [
            "aggregate_phase_score",
            "aggregate_atlas_confidence",
            "score_all_phases",
        ],
    }


if __name__ == "__main__":
    import json
    print(json.dumps(metric_library_summary(), indent=2))
