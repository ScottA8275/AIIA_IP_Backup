# SII v2.8 Instrument Validation Log

Release: `2.8.0`

Capability: Structural Optimization Study

Validated components:

- preserved independent Solar Phase 1 requalification;
- comparative scientific evaluation;
- generation of study candidates from a validated intervention-family replay contract;
- bounded split-count search;
- scientific qualification loss stopping rule;
- split/merge regression stopping rule;
- plateau stopping rule;
- optimization study JSON and human-readable reporting;
- backward compatibility with materialized v0.6.1 requalification requests.

Test result:

```text
16 passed
```

The scientific qualification protocol and underlying Solar qualification thresholds remain unchanged.

## v2.8 dataset-wrapper integration correction

`execute_solar_requalification()` now passes `dataset.data` explicitly into
`run_phase1_representation()` while continuing to pass the full loaded dataset
wrapper into `initialize_solar_atlas()`.

Validated with the complete test suite: **16 passed**.

## SII v2.9 — Structural Entitlement and Optimal Region Detection

- Added observed-peak equivalence testing.
- Added optimal-set and contiguous optimal-region detection.
- Added lowest-complexity recommendation within the entitled set.
- Preserved independent qualification, optimization stopping rules, and candidate provenance boundaries.

## SII v3.0 — Recursive Scientific Discovery

Added an evidence-grounded discovery layer that:

- reads completed v2.9 optimization, comparison, and entitlement records;
- detects registered evidence signatures;
- produces a scientific diagnosis;
- generates a ranked portfolio of falsifiable hypotheses;
- selects a bounded next study;
- preserves a mandatory human authorization gate by default.

The first registered cycle prioritizes multi-seed replication of the observed entitlement region before proposing a new engineering intervention family.
