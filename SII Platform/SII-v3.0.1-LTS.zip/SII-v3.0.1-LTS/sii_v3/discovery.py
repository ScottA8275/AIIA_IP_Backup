from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence
import hashlib
import json
import math


@dataclass(frozen=True)
class DiscoveryPolicy:
    """Governance and prioritization policy for one discovery cycle."""

    minimum_evidence_candidates: int = 3
    replication_seed_count: int = 5
    max_hypotheses: int = 3
    require_human_authorization: bool = True
    score_equivalence_tolerance: float = 0.01

    def validate(self) -> None:
        if self.minimum_evidence_candidates < 2:
            raise ValueError("minimum_evidence_candidates must be at least 2.")
        if self.replication_seed_count < 2:
            raise ValueError("replication_seed_count must be at least 2.")
        if self.max_hypotheses < 1:
            raise ValueError("max_hypotheses must be at least 1.")
        if self.score_equivalence_tolerance < 0:
            raise ValueError("score_equivalence_tolerance cannot be negative.")


@dataclass(frozen=True)
class EvidenceSignature:
    signature_id: str
    present: bool
    strength: float
    evidence: tuple[str, ...]


@dataclass(frozen=True)
class ScientificHypothesis:
    hypothesis_id: str
    title: str
    claim: str
    rationale: str
    intervention_family: str
    study_type: str
    independent_variable: str
    expected_observations: tuple[str, ...]
    falsification_criteria: tuple[str, ...]
    evidence_signature_ids: tuple[str, ...]
    evidence_strength: float
    information_gain: float
    feasibility: float
    scientific_risk: float
    priority_score: float
    status: str = "proposed"


@dataclass(frozen=True)
class DiscoveryCycle:
    cycle_id: str
    created_at: str
    source_study_id: str
    diagnosis: Mapping[str, Any]
    evidence_signatures: tuple[EvidenceSignature, ...]
    hypotheses: tuple[ScientificHypothesis, ...]
    selected_hypothesis_id: str | None
    next_study_request: Mapping[str, Any] | None
    authorization_status: str
    governance: Mapping[str, Any]


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Required SII evidence file does not exist: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return payload


def load_study_evidence(study_directory: Path) -> dict[str, Any]:
    """Load the complete v2.9 evidence bundle used by the discovery layer."""
    study_directory = Path(study_directory).resolve()
    optimization = _read_json(study_directory / "structural_optimization_study.json")
    entitlement = _read_json(study_directory / "structural_entitlement.json")
    comparison = _read_json(study_directory / "comparative_qualification.json")
    summary = _read_json(study_directory / "structural_optimization_summary.json")
    return {
        "study_directory": str(study_directory),
        "optimization": optimization,
        "entitlement": entitlement,
        "comparison": comparison,
        "summary": summary,
    }


def _finite(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)) and math.isfinite(float(value)):
        return float(value)
    return None


def _candidate_rows(evidence: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows = evidence["optimization"].get("evaluated_candidates", [])
    return [dict(row) for row in rows if isinstance(row, Mapping)]


def _optimal_splits(evidence: Mapping[str, Any]) -> list[int]:
    rows = evidence["entitlement"].get("optimal_set", [])
    result: list[int] = []
    for row in rows:
        if isinstance(row, Mapping) and isinstance(row.get("split_count"), int):
            result.append(int(row["split_count"]))
        elif isinstance(row, int):
            result.append(row)
    return sorted(set(result))


def _signature(identifier: str, present: bool, strength: float, *evidence: str) -> EvidenceSignature:
    return EvidenceSignature(
        signature_id=identifier,
        present=present,
        strength=max(0.0, min(1.0, float(strength))),
        evidence=tuple(evidence),
    )


def diagnose_evidence(evidence: Mapping[str, Any], policy: DiscoveryPolicy) -> tuple[dict[str, Any], tuple[EvidenceSignature, ...]]:
    rows = sorted(_candidate_rows(evidence), key=lambda row: int(row.get("split_count", 0)))
    if len(rows) < policy.minimum_evidence_candidates:
        raise ValueError(
            f"Discovery requires at least {policy.minimum_evidence_candidates} evaluated candidates; "
            f"found {len(rows)}."
        )

    splits = [int(row["split_count"]) for row in rows]
    margins = [_finite(row.get("normalized_margin_score")) for row in rows]
    valid_margin_rows = [(split_, margin) for split_, margin in zip(splits, margins) if margin is not None]
    peak_split, peak_margin = max(valid_margin_rows, key=lambda item: item[1])
    optimal = _optimal_splits(evidence)
    recommended_split = evidence["entitlement"].get("recommended_split_count")
    stop_reason = str(evidence["optimization"].get("stop_reason") or "unknown")

    monotonic_pre_peak = True
    pre_peak = [margin for split_, margin in valid_margin_rows if split_ <= min(optimal or [peak_split])]
    if len(pre_peak) >= 2:
        monotonic_pre_peak = all(right >= left for left, right in zip(pre_peak, pre_peak[1:]))

    post_peak_rows = [(split_, margin) for split_, margin in valid_margin_rows if split_ > peak_split]
    post_peak_decline = bool(post_peak_rows and any(margin < peak_margin - policy.score_equivalence_tolerance for _, margin in post_peak_rows))

    split_merge = [
        (int(row["split_count"]), _finite(row.get("split_merge_consistency")))
        for row in rows
    ]
    split_merge_valid = [(split_, value) for split_, value in split_merge if value is not None]
    split_merge_declining = len(split_merge_valid) >= 3 and all(
        right <= left for (_, left), (_, right) in zip(split_merge_valid, split_merge_valid[1:])
    )
    total_split_merge_regression = (
        split_merge_valid[0][1] - split_merge_valid[-1][1]
        if len(split_merge_valid) >= 2 else 0.0
    )

    all_supported = all(str(row.get("status", "")).lower() in {"supported", "pass", "passed"} for row in rows)
    optimal_region_present = len(optimal) >= 2
    complexity_selected = recommended_split == min(optimal) if optimal else False

    signatures = (
        _signature(
            "optimization_plateau",
            stop_reason == "optimization_plateau",
            1.0 if stop_reason == "optimization_plateau" else 0.0,
            f"Stopping reason was {stop_reason}.",
        ),
        _signature(
            "bounded_optimal_region",
            optimal_region_present,
            min(1.0, len(optimal) / 2.0) if optimal_region_present else 0.0,
            f"Observed entitlement set was {optimal}.",
            f"Peak-score split was {peak_split}; minimum-complexity recommendation was {recommended_split}.",
        ),
        _signature(
            "pre_peak_structural_gain",
            monotonic_pre_peak,
            0.9 if monotonic_pre_peak else 0.2,
            "Comparative margin increased through the beginning of the entitled region.",
        ),
        _signature(
            "post_peak_complexity_penalty",
            post_peak_decline,
            0.9 if post_peak_decline else 0.2,
            f"At least one evaluated split above the peak fell more than {policy.score_equivalence_tolerance} below the peak.",
        ),
        _signature(
            "split_merge_tradeoff",
            split_merge_declining,
            min(1.0, max(0.0, total_split_merge_regression / 0.10)) if split_merge_declining else 0.0,
            f"Split/merge consistency changed by {-total_split_merge_regression:.6f} across the evaluated range.",
        ),
        _signature(
            "qualification_preserved",
            all_supported,
            1.0 if all_supported else 0.0,
            f"All {len(rows)} evaluated candidates retained supported status.",
        ),
        _signature(
            "minimum_complexity_selection",
            complexity_selected,
            1.0 if complexity_selected else 0.0,
            "The recommended candidate is the lowest-complexity member of the entitled region.",
        ),
    )

    diagnosis = {
        "schema": "aiia.sii.discovery-diagnosis",
        "schema_version": "1.0",
        "instrument_version": "3.0.0",
        "evaluated_splits": splits,
        "peak_score_split": peak_split,
        "peak_margin_score": peak_margin,
        "optimal_set": optimal,
        "recommended_split": recommended_split,
        "stop_reason": stop_reason,
        "all_candidates_supported": all_supported,
        "split_merge_declining": split_merge_declining,
        "total_split_merge_regression": total_split_merge_regression,
        "diagnostic_conclusion": (
            "The registered split-count intervention family reached a bounded entitlement region, "
            "after which additional complexity did not produce meaningful scientific gain. The next "
            "discovery cycle should test robustness of the entitled region before proposing a new "
            "engineering family, while preserving the observed split/merge tradeoff as an explicit constraint."
        ),
    }
    return diagnosis, signatures


def _priority(evidence_strength: float, information_gain: float, feasibility: float, scientific_risk: float) -> float:
    # Transparent bounded score; scientific risk is a penalty.
    value = 0.35 * evidence_strength + 0.35 * information_gain + 0.20 * feasibility - 0.10 * scientific_risk
    return round(max(0.0, min(1.0, value)), 6)


def generate_hypotheses(
    diagnosis: Mapping[str, Any],
    signatures: Sequence[EvidenceSignature],
    policy: DiscoveryPolicy,
) -> tuple[ScientificHypothesis, ...]:
    by_id = {signature.signature_id: signature for signature in signatures}
    optimal = list(diagnosis.get("optimal_set", []))
    region_label = f"{min(optimal)}-{max(optimal)}" if optimal else "the observed optimum"

    hypotheses: list[ScientificHypothesis] = []

    strength = min(
        by_id["bounded_optimal_region"].strength,
        by_id["qualification_preserved"].strength,
    )
    hypotheses.append(ScientificHypothesis(
        hypothesis_id="H-RSD-001",
        title="Entitlement-region replication",
        claim=f"The structural entitlement region {region_label} will persist across independent random seeds.",
        rationale=(
            "The current entitlement conclusion is internally coherent but was produced under one configured "
            "random seed. Replication is the highest-value next test because it determines whether the region "
            "is a stable property of the representation or a seed-contingent observation."
        ),
        intervention_family="dominant_basin_hierarchical_split",
        study_type="multi_seed_replication",
        independent_variable="random_seed",
        expected_observations=(
            f"Most seed-level studies retain an optimal region overlapping {region_label}.",
            "The lowest-complexity entitled split remains stable or changes only within the observed optimal set.",
            "No replicated candidate introduces blocking qualification evidence.",
        ),
        falsification_criteria=(
            "A majority of seed-level studies produce non-overlapping entitlement regions.",
            "The recommended split varies beyond the observed optimal set without a consistent evidence pattern.",
            "Qualification is lost for the currently recommended representation in two or more seed-level studies.",
        ),
        evidence_signature_ids=("bounded_optimal_region", "qualification_preserved", "minimum_complexity_selection"),
        evidence_strength=strength,
        information_gain=0.95,
        feasibility=0.95,
        scientific_risk=0.10,
        priority_score=_priority(strength, 0.95, 0.95, 0.10),
    ))

    tradeoff_strength = by_id["split_merge_tradeoff"].strength
    hypotheses.append(ScientificHypothesis(
        hypothesis_id="H-RSD-002",
        title="Stability-constrained structural refinement",
        claim=(
            "A refinement intervention that explicitly preserves split/merge consistency can retain the "
            "structural gains of the entitled region without increasing representational complexity."
        ),
        rationale=(
            "The split-count family improved aggregate structural evidence but produced a monotonic tradeoff in "
            "split/merge consistency. This suggests the next engineering target should be boundary quality rather "
            "than additional splitting."
        ),
        intervention_family="stability_constrained_boundary_refinement",
        study_type="new_intervention_family_comparison",
        independent_variable="boundary_refinement_strength",
        expected_observations=(
            "Comparative margin is non-inferior to the recommended split from the current entitlement region.",
            "Split/merge consistency improves relative to the current recommended candidate.",
            "The candidate remains scientifically supported with no newly blocking metrics.",
        ),
        falsification_criteria=(
            "Split/merge consistency does not improve by a registered minimum effect size.",
            "Aggregate threshold margin falls outside the current equivalence tolerance.",
            "The intervention introduces blocking evidence or unstable microbasins.",
        ),
        evidence_signature_ids=("split_merge_tradeoff", "optimization_plateau", "qualification_preserved"),
        evidence_strength=tradeoff_strength,
        information_gain=0.85,
        feasibility=0.55,
        scientific_risk=0.35,
        priority_score=_priority(tradeoff_strength, 0.85, 0.55, 0.35),
    ))

    plateau_strength = by_id["optimization_plateau"].strength
    hypotheses.append(ScientificHypothesis(
        hypothesis_id="H-RSD-003",
        title="Intervention-family exhaustion",
        claim=(
            "Additional split-count complexity within the current hierarchical intervention family will not "
            "produce a scientifically meaningful improvement beyond the entitled region."
        ),
        rationale=(
            "The optimization stopped after consecutive non-improvements and a post-peak decline. A bounded "
            "challenge study can determine whether this is a true family-level limit or an artifact of the "
            "configured stopping policy."
        ),
        intervention_family="dominant_basin_hierarchical_split",
        study_type="plateau_challenge",
        independent_variable="split_count",
        expected_observations=(
            "Additional prespecified split counts remain below the peak by at least the equivalence tolerance.",
            "Split/merge consistency continues to decline or fails to recover materially.",
        ),
        falsification_criteria=(
            "A prespecified higher split exceeds the existing peak by the minimum meaningful-improvement threshold.",
            "A second, disjoint entitled region is detected with preserved qualification.",
        ),
        evidence_signature_ids=("optimization_plateau", "post_peak_complexity_penalty", "split_merge_tradeoff"),
        evidence_strength=plateau_strength,
        information_gain=0.55,
        feasibility=0.90,
        scientific_risk=0.20,
        priority_score=_priority(plateau_strength, 0.55, 0.90, 0.20),
    ))

    hypotheses.sort(key=lambda item: (-item.priority_score, item.hypothesis_id))
    return tuple(hypotheses[: policy.max_hypotheses])


def _study_request(hypothesis: ScientificHypothesis, policy: DiscoveryPolicy, diagnosis: Mapping[str, Any]) -> dict[str, Any]:
    optimal = list(diagnosis.get("optimal_set", []))
    recommended = diagnosis.get("recommended_split")
    if hypothesis.study_type == "multi_seed_replication":
        seeds = [42 + 1009 * index for index in range(policy.replication_seed_count)]
        design = {
            "study_type": "multi_seed_replication",
            "intervention_family": hypothesis.intervention_family,
            "split_range": [min(optimal), max(optimal)] if optimal else [recommended, recommended],
            "include_boundary_challenges": True,
            "boundary_splits": [max(2, min(optimal) - 1), max(optimal) + 1] if optimal else [],
            "random_seeds": seeds,
            "qualification_profile": "validated-solar-phase1",
            "entitlement_policy": {
                "score_equivalence_tolerance": policy.score_equivalence_tolerance,
                "prefer_lower_complexity": True,
            },
        }
    else:
        design = {
            "study_type": hypothesis.study_type,
            "intervention_family": hypothesis.intervention_family,
            "requires_aiia_engineering_definition": True,
            "qualification_profile": "validated-solar-phase1",
        }

    return {
        "schema": "aiia.sii.next-study-request",
        "schema_version": "1.0",
        "instrument_version": "3.0.0",
        "request_id": f"study-request-{hypothesis.hypothesis_id.lower()}",
        "hypothesis_id": hypothesis.hypothesis_id,
        "scientific_question": hypothesis.claim,
        "design": design,
        "expected_observations": list(hypothesis.expected_observations),
        "falsification_criteria": list(hypothesis.falsification_criteria),
        "authorization_required": policy.require_human_authorization,
        "authorization_status": "pending_human_authorization" if policy.require_human_authorization else "authorized",
        "execution_boundary": (
            "SII generated this bounded scientific study request from registered evidence rules. "
            "It has not modified AIIA engineering code or executed a new intervention family."
        ),
    }


def _cycle_id(evidence: Mapping[str, Any], hypotheses: Sequence[ScientificHypothesis]) -> str:
    canonical = json.dumps({
        "summary": evidence["summary"],
        "hypotheses": [asdict(item) for item in hypotheses],
    }, sort_keys=True, default=str).encode("utf-8")
    return "rsd-" + hashlib.sha256(canonical).hexdigest()[:16]


def build_discovery_cycle(evidence: Mapping[str, Any], policy: DiscoveryPolicy) -> DiscoveryCycle:
    policy.validate()
    diagnosis, signatures = diagnose_evidence(evidence, policy)
    hypotheses = generate_hypotheses(diagnosis, signatures, policy)
    selected = hypotheses[0] if hypotheses else None
    request = _study_request(selected, policy, diagnosis) if selected else None
    source_study_id = str(
        evidence["summary"].get("schema") or evidence["optimization"].get("schema") or "unknown-study"
    )
    return DiscoveryCycle(
        cycle_id=_cycle_id(evidence, hypotheses),
        created_at=datetime.now(timezone.utc).isoformat(),
        source_study_id=source_study_id,
        diagnosis=diagnosis,
        evidence_signatures=signatures,
        hypotheses=hypotheses,
        selected_hypothesis_id=selected.hypothesis_id if selected else None,
        next_study_request=request,
        authorization_status=(
            "pending_human_authorization" if policy.require_human_authorization else "authorized"
        ),
        governance={
            "mode": "bounded_rule_grounded_discovery",
            "autonomous_execution": False,
            "hypothesis_generation": "registered evidence-signature rules",
            "qualification_authority": "SII preserved",
            "engineering_authority": "AIIA or human-authorized implementation",
            "claim_limit": (
                "The cycle proposes falsifiable next studies; it does not treat a generated hypothesis as a finding."
            ),
        },
    )


def _cycle_payload(cycle: DiscoveryCycle) -> dict[str, Any]:
    return {
        "schema": "aiia.sii.recursive-scientific-discovery-cycle",
        "schema_version": "1.0",
        "instrument_version": "3.0.0",
        "cycle_id": cycle.cycle_id,
        "created_at": cycle.created_at,
        "source_study_id": cycle.source_study_id,
        "diagnosis": dict(cycle.diagnosis),
        "evidence_signatures": [asdict(item) for item in cycle.evidence_signatures],
        "hypotheses": [asdict(item) for item in cycle.hypotheses],
        "selected_hypothesis_id": cycle.selected_hypothesis_id,
        "next_study_request": cycle.next_study_request,
        "authorization_status": cycle.authorization_status,
        "governance": dict(cycle.governance),
    }


def write_discovery_outputs(cycle: DiscoveryCycle, output_directory: Path) -> dict[str, Path]:
    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    payload = _cycle_payload(cycle)

    paths = {
        "cycle": output_directory / "recursive_discovery_cycle.json",
        "diagnosis": output_directory / "discovery_diagnosis.json",
        "portfolio": output_directory / "hypothesis_portfolio.json",
        "request": output_directory / "next_study_request.json",
        "report": output_directory / "recursive_discovery_report.txt",
    }
    paths["cycle"].write_text(json.dumps(payload, indent=2), encoding="utf-8")
    paths["diagnosis"].write_text(json.dumps(payload["diagnosis"], indent=2), encoding="utf-8")
    paths["portfolio"].write_text(json.dumps({
        "schema": "aiia.sii.hypothesis-portfolio",
        "schema_version": "1.0",
        "instrument_version": "3.0.0",
        "cycle_id": cycle.cycle_id,
        "hypotheses": payload["hypotheses"],
        "selected_hypothesis_id": cycle.selected_hypothesis_id,
    }, indent=2), encoding="utf-8")
    if cycle.next_study_request is not None:
        paths["request"].write_text(json.dumps(cycle.next_study_request, indent=2), encoding="utf-8")

    lines = [
        "STRUCTURAL INTELLIGENCE INSTRUMENT v3.0",
        "RECURSIVE SCIENTIFIC DISCOVERY — CYCLE REPORT",
        "=" * 72,
        "",
        f"Cycle ID: {cycle.cycle_id}",
        f"Authorization: {cycle.authorization_status}",
        "",
        "DIAGNOSIS",
        str(cycle.diagnosis.get("diagnostic_conclusion")),
        "",
        "HYPOTHESIS PORTFOLIO",
    ]
    for index, hypothesis in enumerate(cycle.hypotheses, start=1):
        lines.extend([
            f"{index}. {hypothesis.hypothesis_id} — {hypothesis.title}",
            f"   Priority: {hypothesis.priority_score:.6f}",
            f"   Claim: {hypothesis.claim}",
            f"   Study type: {hypothesis.study_type}",
        ])
    lines.extend([
        "",
        f"SELECTED NEXT HYPOTHESIS: {cycle.selected_hypothesis_id}",
        "",
        "EXECUTION BOUNDARY",
        str(cycle.governance.get("claim_limit")),
        "A human authorization step is required before the next study is executed.",
    ])
    paths["report"].write_text("\n".join(lines) + "\n", encoding="utf-8")
    return paths
