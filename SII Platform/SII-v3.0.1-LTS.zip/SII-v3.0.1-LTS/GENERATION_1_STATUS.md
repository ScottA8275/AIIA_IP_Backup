# Generation 1 status

Release: SII-v3.0.1-LTS
Status: Frozen LTS baseline
Validation: 24 passed

Changes require a new version. The frozen scientific or engineering behavior must not be altered in place.
