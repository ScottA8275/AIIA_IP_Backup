# Structural Intelligence Instrument v2.9

## Structural Entitlement and Optimal Region Detection

SII v2.9 extends the v2.8 Structural Optimization Study by distinguishing the **numerical peak** from the **scientifically entitled optimal region**.

The optimization stage remains unchanged: SII searches a registered intervention family, independently requalifies each candidate, and stops under registered plateau, qualification-loss, or split/merge-regression rules.

The new entitlement stage then:

1. excludes candidates that are unsupported or contain blocking evidence;
2. identifies the observed peak comparative margin;
3. forms an optimal set from eligible candidates within the registered score-equivalence tolerance;
4. detects contiguous optimal regions in the evaluated complexity sequence;
5. recommends the lowest-complexity member of the optimal set.

Default policy:

```python
SCORE_EQUIVALENCE_TOLERANCE = 0.01
PREFER_LOWER_COMPLEXITY = True
```

For the observed v2.8 curve, splits 4 and 5 are score-equivalent under this policy. SII v2.9 therefore reports the optimal region as **4–5** and recommends **split 4** because it achieves equivalent scientific performance with lower representational complexity.

## Run

Edit the inline configuration in:

```text
examples/run_structural_optimization.py
```

Then run:

```powershell
python examples\run_structural_optimization.py
```

## New outputs

```text
structural_entitlement.json
structural_entitlement.txt
```

The existing optimization and comparative reports are retained.

## Governance

Structural entitlement applies only to candidates actually evaluated, scientifically supported, and within the registered equivalence tolerance of the observed peak. It does not interpolate between candidates, extrapolate beyond the evaluated range, alter qualification, or convert an SII-generated study candidate into an AIIA Representation Product.
