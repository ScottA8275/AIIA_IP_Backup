# Structural Intelligence Instrument v2.8

## Structural Optimization Study

SII v2.8 extends independent candidate requalification and comparative scientific evaluation into a bounded structural optimization study.

The instrument evaluates a registered intervention family across an inline split-count search range, independently replays each candidate through the preserved Solar Phase 1 protocol, compares the resulting evidence, and stops when additional complexity is no longer scientifically justified.

## Primary runner

```text
examples/run_structural_optimization.py
```

Edit the inline configuration block and run the file directly in PyCharm:

```powershell
python examples\run_structural_optimization.py
```

## Default search

```python
MIN_SPLIT = 2
MAX_SPLIT = 10

MINIMUM_MARGIN_IMPROVEMENT = 0.01
MAXIMUM_SPLIT_MERGE_REGRESSION = 0.05
MAXIMUM_CANDIDATES_WITHOUT_IMPROVEMENT = 2
```

The study stops when any of the following occurs:

1. scientific qualification is lost;
2. the configured one-step split/merge consistency regression is exceeded;
3. the normalized comparative margin fails to improve meaningfully for the configured number of consecutive candidates;
4. the maximum split is reached.

## Candidate sources

For split counts already materialized by AIIA, SII uses the validated requalification request and candidate lineage.

For additional split counts in the registered search range, SII creates an explicitly labeled optimization-study candidate from the validated intervention replay contract. These generated study candidates are not represented as AIIA-materialized Representation Products.

## Outputs

```text
sii_v2_8_structural_optimization/
    dominant_basin_split_2/
    dominant_basin_split_3/
    ...
    comparative_qualification.json
    comparative_qualification.txt
    structural_optimization_study.json
    structural_optimization_study.txt
    structural_optimization_summary.json
```

The optimization report contains:

- the evaluated split sequence;
- qualification status for every evaluated candidate;
- normalized threshold-margin curve;
- split/merge consistency curve;
- stopping decisions and stopping reason;
- comparative ranking and Pareto frontier;
- recommended split and candidate.

## Scientific governance

SII searches only within the registered intervention family. Optimization ranking does not replace qualification, alter candidate packages, or expand scientific entitlement.

## Validation

```text
16 tests passed
```
