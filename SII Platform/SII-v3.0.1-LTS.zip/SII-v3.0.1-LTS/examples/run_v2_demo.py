#!/usr/bin/env python3
"""Compatibility entry point for the v2.1 executable investigation."""
from run_first_investigation import main

if __name__ == "__main__":
    main()
