from __future__ import annotations

import json
import shutil
from pathlib import Path

from sii_v2.comparison import build_comparative_evaluation, compare_candidate, write_comparative_reports
from sii_v2.entitlement import EntitlementPolicy, detect_structural_entitlement, write_entitlement_reports
from sii_v2.optimization import (
    OptimizationPolicy,
    build_optimization_study,
    derive_optimization_job,
    evaluate_stopping_rule,
    write_optimization_reports,
)
from sii_v2.request_loader import load_requalification_request
from sii_v2.requalification import execute_solar_requalification


# =============================================================================
# Structural Entitlement and Optimal Region Detection Configuration
# =============================================================================
# Edit only this block for the local SII v2.9 investigation.

WORKSPACE_ROOT = Path(r"C:\Users\scott\PyCharmMiscProject")
PROJECT = "solar"

REQUEST_DIRECTORY = (
    WORKSPACE_ROOT
    / "examples"
    / "aiia_platform_v0_6_1"
    / PROJECT
    / "sii_requalification_requests"
)

DATASET_PATH = (
    WORKSPACE_ROOT
    / "data"
    / "Goldilocks v2"
    / "ANALYSIS_READY"
    / "dataset_B_core_solar_all.csv.gz"
)

OUTPUT_DIRECTORY = (
    WORKSPACE_ROOT
    / "examples"
    / "sii_v2_9_structural_entitlement"
)

QUALIFICATION_PROFILE = "validated-solar-phase1"
RANDOM_SEED = 42

MIN_SPLIT = 2
MAX_SPLIT = 10

MINIMUM_MARGIN_IMPROVEMENT = 0.01
MAXIMUM_SPLIT_MERGE_REGRESSION = 0.05
MAXIMUM_CANDIDATES_WITHOUT_IMPROVEMENT = 2

SCORE_EQUIVALENCE_TOLERANCE = 0.01
PREFER_LOWER_COMPLEXITY = True

OVERWRITE_EXISTING = True
SII_PROJECT_ROOT = Path(__file__).resolve().parents[1]


# =============================================================================
# Investigation Execution
# =============================================================================

def _policy() -> OptimizationPolicy:
    policy = OptimizationPolicy(
        min_split=MIN_SPLIT,
        max_split=MAX_SPLIT,
        minimum_margin_improvement=MINIMUM_MARGIN_IMPROVEMENT,
        maximum_split_merge_regression=MAXIMUM_SPLIT_MERGE_REGRESSION,
        maximum_candidates_without_improvement=MAXIMUM_CANDIDATES_WITHOUT_IMPROVEMENT,
    )
    policy.validate()
    return policy


def _validate_configuration(policy: OptimizationPolicy) -> None:
    if not WORKSPACE_ROOT.exists():
        raise FileNotFoundError(f"WORKSPACE_ROOT does not exist: {WORKSPACE_ROOT}")
    if not REQUEST_DIRECTORY.is_dir():
        raise FileNotFoundError(f"REQUEST_DIRECTORY does not exist: {REQUEST_DIRECTORY}")
    if not DATASET_PATH.is_file():
        raise FileNotFoundError(f"DATASET_PATH does not exist: {DATASET_PATH}")
    if not QUALIFICATION_PROFILE:
        raise ValueError("QUALIFICATION_PROFILE cannot be empty.")
    policy.validate()


def _load_request_templates():
    request_paths = sorted(REQUEST_DIRECTORY.glob("*.json"))
    if not request_paths:
        raise FileNotFoundError(f"No JSON request files found in: {REQUEST_DIRECTORY}")
    jobs = [load_requalification_request(path) for path in request_paths]
    jobs_by_split = {job.split_count: job for job in jobs}
    template = jobs_by_split.get(MIN_SPLIT) or min(jobs, key=lambda item: item.split_count)
    return jobs_by_split, template


def _decision_payload(split_count: int, decision) -> dict:
    return {
        "split_count": split_count,
        "stop": decision.stop,
        "reason": decision.reason,
        "meaningful_improvement": decision.meaningful_improvement,
        "consecutive_without_improvement": decision.consecutive_without_improvement,
        "margin_score": decision.margin_score,
        "best_margin_score": decision.best_margin_score,
        "split_merge_value": decision.split_merge_value,
        "split_merge_step_regression": decision.split_merge_step_regression,
    }


def main() -> None:
    policy = _policy()
    _validate_configuration(policy)
    materialized_jobs, template_job = _load_request_templates()

    print("=" * 68)
    print("STRUCTURAL INTELLIGENCE INSTRUMENT v2.9")
    print("Structural Entitlement and Optimal Region Detection")
    print("=" * 68)
    print(f"Workspace:                         {WORKSPACE_ROOT.resolve()}")
    print(f"Project:                           {PROJECT}")
    print(f"Request directory:                 {REQUEST_DIRECTORY.resolve()}")
    print(f"Dataset:                           {DATASET_PATH.resolve()}")
    print(f"Output:                            {OUTPUT_DIRECTORY.resolve()}")
    print(f"Qualification profile:             {QUALIFICATION_PROFILE}")
    print(f"Random seed:                       {RANDOM_SEED}")
    print(f"Split search range:                {MIN_SPLIT} through {MAX_SPLIT}")
    print(f"Minimum margin improvement:        {MINIMUM_MARGIN_IMPROVEMENT}")
    print(f"Maximum split/merge regression:    {MAXIMUM_SPLIT_MERGE_REGRESSION}")
    print(f"Plateau patience:                  {MAXIMUM_CANDIDATES_WITHOUT_IMPROVEMENT}")
    print(f"Score equivalence tolerance:       {SCORE_EQUIVALENCE_TOLERANCE}")
    print(f"Prefer lower complexity:           {PREFER_LOWER_COMPLEXITY}")
    print(f"Overwrite existing:                {OVERWRITE_EXISTING}")
    print("Configuration:                     VALID")

    evaluated: list[tuple[int, dict]] = []
    decisions: list[dict] = []
    best_margin_score = None
    consecutive_without_improvement = 0
    previous_split_merge_value = None
    stop_reason = None

    for split_count in range(policy.min_split, policy.max_split + 1):
        job = materialized_jobs.get(split_count)
        source = "AIIA materialized candidate"
        if job is None:
            job = derive_optimization_job(template_job, split_count)
            source = "SII optimization-generated study candidate"

        request_profile = str(job.request.get("requested_profile") or "")
        if request_profile and QUALIFICATION_PROFILE not in request_profile:
            raise ValueError(
                f"Request {job.request['object_id']} specifies profile {request_profile!r}, "
                f"which does not match configured profile {QUALIFICATION_PROFILE!r}."
            )

        candidate_output = OUTPUT_DIRECTORY / f"dominant_basin_split_{split_count}"
        print(f"\nPreflight PASS: split {split_count} | {job.candidate_id}")
        print(f"Candidate source: {source}")

        if candidate_output.exists():
            if not OVERWRITE_EXISTING:
                raise FileExistsError(
                    f"Output already exists for split {split_count}: {candidate_output}. "
                    "Set OVERWRITE_EXISTING = True to replace it."
                )
            shutil.rmtree(candidate_output)

        result = execute_solar_requalification(
            job=job,
            project_root=SII_PROJECT_ROOT,
            dataset_path=DATASET_PATH,
            output_dir=candidate_output,
        )
        evaluated.append((split_count, result))
        comparison = compare_candidate(result, split_count=split_count)
        decision = evaluate_stopping_rule(
            comparison=comparison,
            policy=policy,
            best_margin_score=best_margin_score,
            consecutive_without_improvement=consecutive_without_improvement,
            previous_split_merge_value=previous_split_merge_value,
        )
        decisions.append(_decision_payload(split_count, decision))
        best_margin_score = decision.best_margin_score
        consecutive_without_improvement = decision.consecutive_without_improvement
        previous_split_merge_value = decision.split_merge_value

        print(f"Completed: split {split_count} | status={result['status']}")
        print(f"Margin score: {decision.margin_score:.6f}")
        print(f"Meaningful improvement: {decision.meaningful_improvement}")
        if decision.stop:
            stop_reason = decision.reason
            print(f"Stopping rule triggered: {stop_reason}")
            break

    OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)
    comparative_payload = build_comparative_evaluation(evaluated)
    write_comparative_reports(comparative_payload, OUTPUT_DIRECTORY)

    optimization_payload = build_optimization_study(
        evaluated=evaluated,
        decisions=decisions,
        policy=policy,
        comparative_payload=comparative_payload,
        stop_reason=stop_reason,
    )
    write_optimization_reports(optimization_payload, OUTPUT_DIRECTORY)

    entitlement_policy = EntitlementPolicy(
        score_equivalence_tolerance=SCORE_EQUIVALENCE_TOLERANCE,
        prefer_lower_complexity=PREFER_LOWER_COMPLEXITY,
    )
    entitlement_payload = detect_structural_entitlement(
        evaluated_candidates=optimization_payload["evaluated_candidates"],
        policy=entitlement_policy,
        intervention_family=optimization_payload["intervention_family"],
        stop_reason=optimization_payload["stop_reason"],
    )
    write_entitlement_reports(entitlement_payload, OUTPUT_DIRECTORY)

    summary_payload = {
        "schema": "aiia.sii.structural-optimization-summary",
        "schema_version": "1.0",
        "instrument_version": "2.9.0",
        "project": PROJECT,
        "qualification_profile": QUALIFICATION_PROFILE,
        "random_seed": RANDOM_SEED,
        "evaluated_splits": [split for split, _ in evaluated],
        "stop_reason": optimization_payload["stop_reason"],
        "peak_score_candidate_id": comparative_payload["recommended_candidate_id"],
        "peak_score_split_count": comparative_payload["recommended_split_count"],
        "entitlement_status": entitlement_payload["entitlement_status"],
        "optimal_set": entitlement_payload["optimal_set"],
        "optimal_regions": entitlement_payload["optimal_regions"],
        "recommended_candidate_id": entitlement_payload["recommended_candidate_id"],
        "recommended_split_count": entitlement_payload["recommended_split_count"],
        "recommendation_reason": entitlement_payload.get("recommendation_reason"),
        "ranking": comparative_payload["ranking"],
        "pareto_frontier": comparative_payload["pareto_frontier"],
    }
    (OUTPUT_DIRECTORY / "structural_optimization_summary.json").write_text(
        json.dumps(summary_payload, indent=2), encoding="utf-8"
    )

    print("\nSII v2.9 structural entitlement study complete.")
    print(f"Candidates evaluated: {len(evaluated)}")
    print(f"Stop reason:          {optimization_payload['stop_reason']}")
    print(f"Peak-score split:     {comparative_payload['recommended_split_count']}")
    print(f"Optimal set:          {[row['split_count'] for row in entitlement_payload['optimal_set']]}")
    print(f"Recommended split:    {entitlement_payload['recommended_split_count']}")
    print(f"Recommended candidate:{entitlement_payload['recommended_candidate_id']}")
    print(f"Recommendation reason:{entitlement_payload.get('recommendation_reason')}")
    print(f"Output: {OUTPUT_DIRECTORY.resolve()}")


if __name__ == "__main__":
    main()
