
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path


REQUIRED = ("numpy", "pandas", "networkx", "scipy", "sklearn")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    legacy = root / "legacy_solar_v1"
    result = {
        "release": "SII v2.2.0-alpha.1",
        "dataset": str(args.dataset.resolve()),
        "dataset_exists": args.dataset.exists(),
        "legacy_directory": str(legacy),
        "legacy_files": {},
        "dependencies": {},
    }
    for name in (
        "phase1_representation.py", "qualification_config.py",
        "qualification_metrics.py", "qualification_types.py",
        "solar_m1d_adapter.py", "run_m1d_solar_atlas_validation.py",
    ):
        result["legacy_files"][name] = (legacy / name).exists()
    for name in REQUIRED:
        result["dependencies"][name] = importlib.util.find_spec(name) is not None
    result["ready"] = (
        result["dataset_exists"]
        and all(result["legacy_files"].values())
        and all(result["dependencies"].values())
    )
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["ready"] else 2)


if __name__ == "__main__":
    main()
