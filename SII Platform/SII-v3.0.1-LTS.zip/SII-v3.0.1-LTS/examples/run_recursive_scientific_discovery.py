from __future__ import annotations

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from sii_v3.discovery import (  # noqa: E402
    DiscoveryPolicy,
    build_discovery_cycle,
    load_study_evidence,
    write_discovery_outputs,
)


# =============================================================================
# Inline Parameters
# =============================================================================

WORKSPACE_ROOT = Path(r"C:\Users\scott\PyCharmMiscProject")

STUDY_DIRECTORY = (
    WORKSPACE_ROOT
    / "examples"
    / "sii_v2_9_structural_entitlement"
)

OUTPUT_DIRECTORY = (
    WORKSPACE_ROOT
    / "examples"
    / "sii_v3_0_recursive_scientific_discovery"
)

MINIMUM_EVIDENCE_CANDIDATES = 3
REPLICATION_SEED_COUNT = 5
MAX_HYPOTHESES = 3
SCORE_EQUIVALENCE_TOLERANCE = 0.01
REQUIRE_HUMAN_AUTHORIZATION = True


# =============================================================================
# Discovery Execution
# =============================================================================

def main() -> None:
    policy = DiscoveryPolicy(
        minimum_evidence_candidates=MINIMUM_EVIDENCE_CANDIDATES,
        replication_seed_count=REPLICATION_SEED_COUNT,
        max_hypotheses=MAX_HYPOTHESES,
        require_human_authorization=REQUIRE_HUMAN_AUTHORIZATION,
        score_equivalence_tolerance=SCORE_EQUIVALENCE_TOLERANCE,
    )
    policy.validate()

    print("=" * 72)
    print("STRUCTURAL INTELLIGENCE INSTRUMENT v3.0")
    print("Recursive Scientific Discovery — Evidence-Grounded Hypothesis Cycle")
    print("=" * 72)
    print(f"Workspace:                     {WORKSPACE_ROOT.resolve()}")
    print(f"Source study:                  {STUDY_DIRECTORY.resolve()}")
    print(f"Output:                        {OUTPUT_DIRECTORY.resolve()}")
    print(f"Replication seed count:        {REPLICATION_SEED_COUNT}")
    print(f"Maximum hypotheses:            {MAX_HYPOTHESES}")
    print(f"Human authorization required:  {REQUIRE_HUMAN_AUTHORIZATION}")
    print("Configuration:                 VALID")

    evidence = load_study_evidence(STUDY_DIRECTORY)
    cycle = build_discovery_cycle(evidence, policy)
    write_discovery_outputs(cycle, OUTPUT_DIRECTORY)

    print("\nDiscovery cycle complete.")
    print(f"Cycle ID:             {cycle.cycle_id}")
    print(f"Hypotheses generated: {len(cycle.hypotheses)}")
    print(f"Selected hypothesis: {cycle.selected_hypothesis_id}")
    print(f"Authorization status:{cycle.authorization_status}")
    print(f"Output:               {OUTPUT_DIRECTORY.resolve()}")
    if cycle.hypotheses:
        selected = next(item for item in cycle.hypotheses if item.hypothesis_id == cycle.selected_hypothesis_id)
        print(f"Next study:           {selected.title}")


if __name__ == "__main__":
    main()
