from pathlib import Path
import re

V23_REPORT=Path(r"C:\Users\scott\PyCharmMiscProject\examples\sii_v2_3_full_qualification\investigation_report.txt")
OUTPUT_REPORT=Path(r"C:\Users\scott\PyCharmMiscProject\examples\sii_v2_4_improvement_plan\improvement_plan.txt")

def parse_checks(text):
    pattern=re.compile(r"  \[(?P<state>[^\]]+)\] (?P<name>[^\n]+)\n    Check ID: (?P<id>[^\n]+)\n    Value: (?P<value>[^\n]+)\n    Criterion: (?P<criterion>[^\n]+)\n    Evidence count: (?P<count>[^\n]+)\n    Rationale: (?P<rationale>[^\n]+)")
    return [m.groupdict() for m in pattern.finditer(text)]

def main():
    checks=parse_checks(V23_REPORT.read_text(encoding="utf-8")); failed={c["id"]:c for c in checks if c["state"].startswith("FAIL")}
    diagnoses=[]; candidates=[]
    if {"seed_median_aligned_ari","seed_minor_basin_stability"}&failed.keys():
        diagnoses.append("Seed-sensitive basin boundaries: minor basin identity is unstable across seeds.")
        candidates.append(("consensus_seed_initialization","Run 10 aligned seeds and select the aligned-medoid initialization.","ARI >= 0.50; minor basin stability >= 0.45","Parameter similarity must remain >= 0.65."))
    if "maximum_basin_occupancy" in failed:
        diagnoses.append("Dominant-basin overconcentration: the largest basin may contain unresolved regimes.")
        candidates.insert(0,("hierarchical_split_of_dominant_basin","Preserve global coordinates and test 2-, 3-, and 4-way local splits inside the largest basin.","Maximum occupancy <= 0.90; ARI should increase","Bootstrap similarity must remain >= 0.65; no critical pass may regress."))
    lines=["STRUCTURAL INTELLIGENCE INSTRUMENT v2.4","CLOSED-LOOP REPRESENTATION IMPROVEMENT PLAN","="*72,"","STRUCTURAL DIAGNOSES"]+[f"  - {x}" for x in diagnoses]+["","ORDERED CANDIDATE EXPERIMENTS"]
    for i,(name,action,target,guard) in enumerate(candidates,1): lines += [f"  {i}. {name}",f"     Action: {action}",f"     Success criteria: {target}",f"     Guardrail: {guard}",""]
    lines += ["SELECTION RULE","  Accept a candidate only if it improves a failed target, passes every critical check,","  and does not materially degrade a previously passing check.","","NEXT EXECUTION","  1. Build candidate representation.","  2. Re-run full Phase 1 qualification.","  3. Compare baseline and candidate metrics.","  4. Publish an Improvement Trial."]
    OUTPUT_REPORT.parent.mkdir(parents=True,exist_ok=True); OUTPUT_REPORT.write_text("\n".join(lines)+"\n",encoding="utf-8")
    print("\n".join(lines)); print(f"\nReport: {OUTPUT_REPORT}")
if __name__=="__main__": main()
