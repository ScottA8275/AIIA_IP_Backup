#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sii_v2 import (
    DatasetRecord,
    ExperimentDefinition,
    FileStructuralKnowledgeRepository,
    Investigation,
    ScientificQuestion,
    StructuralIntelligenceInstrument,
    write_investigation_report,
)
from sii_v2.adapters import V1RepresentationEngineBridge
from sii_v2.engines import BaselineDiscoveryEngine, BaselinePublicationEngine, BaselineQualificationEngine


def solar_representation(dataset: DatasetRecord, experiment: ExperimentDefinition, seed: int) -> dict:
    """Deterministic v1-compatible payload for the executable architecture release.

    This is intentionally an adapter fixture, not a replacement for validated Solar/RIX code.
    """
    return {
        "configuration_id": f"solar-v1-bridge-seed-{seed}",
        "observation_count": dataset.observation_count,
        "representation_family": "recursive_indexing",
        "embedding_dimensions": 8,
        "microstate_count": 24,
        "diagnostics": {"deterministic_seed": seed, "source": "validated-solar-adapter-fixture"},
    }


def solar_atlas(_representation) -> dict:
    return {
        "basin_count": 4,
        "neighborhood_count": 24,
        "occupancy": {"stable_core": 0.76, "transition": 0.12, "excursion": 0.08, "sparse": 0.04},
        "topology_summary": {"dominant_basin": "stable_core", "bottleneck_count": 2, "regime_candidate": True},
    }


def progress(stage: str, message: str) -> None:
    print(f"[{stage.upper():9}] {message}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run SII v2.1's first executable scientific investigation.")
    parser.add_argument("--output", type=Path, default=Path("sii_v2_1_output"))
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--observations", type=int, default=1000)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    repository = FileStructuralKnowledgeRepository(args.output / "skr")
    question = ScientificQuestion(
        text="Does solar activity exhibit stable organizational regimes?",
        domain="solar dynamics",
        hypotheses=("Solar observations contain persistent organizational basins and transition pathways.",),
    )
    investigation = Investigation(
        code="SII-SOLAR-0001",
        name="Solar Organizational Regime Investigation",
        question_id=question.object_id,
        objectives=("Construct a structural representation.", "Qualify the evidence.", "Preserve a complete Evidence Chain."),
        enabled_capabilities=("represent", "qualify", "discover", "publish"),
    )
    experiment = ExperimentDefinition(
        code="SOLAR-FIRST-EXECUTABLE",
        name="First Executable Solar Investigation",
        scientific_question=question.text,
        investigation_id=investigation.object_id,
        objectives=investigation.objectives,
        enabled_capabilities=investigation.enabled_capabilities,
    )
    dataset = DatasetRecord(
        name="Solar structural observations",
        uri="adapter://validated-solar-v1",
        observation_count=args.observations,
        feature_names=("magnetic_field", "solar_wind_speed", "density", "pressure"),
        metadata={"release_note": "Architecture execution fixture; connect the validated Solar v1 pipeline next."},
    )
    bridge = V1RepresentationEngineBridge(
        name="Solar v1 Representation Bridge",
        version="1.0-compatible",
        build_callback=solar_representation,
        atlas_callback=solar_atlas,
    )
    instrument = StructuralIntelligenceInstrument(
        repository=repository,
        representation_engine=bridge,
        qualification_engine=BaselineQualificationEngine(),
        discovery_engine=BaselineDiscoveryEngine(),
        publication_engine=BaselinePublicationEngine(),
        progress=progress,
    )
    record = instrument.investigate(
        question=question,
        investigation=investigation,
        experiment=experiment,
        dataset=dataset,
        run_name="SII v2.1 — First Executable Scientific Investigation",
        random_seed=args.seed,
    )
    report_path = write_investigation_report(record, repository, args.output / "investigation_report.txt")
    manifest = {
        "status": "completed",
        "instrument_version": instrument.version,
        "question_id": question.object_id,
        "investigation_id": investigation.object_id,
        "scientific_record_id": record.object_id,
        "entitlement": record.entitlement_level.value,
        "evidence_chain_ids": list(record.evidence_chain_ids),
        "repository": str(repository.root),
        "report": str(report_path.resolve()),
    }
    (args.output / "run_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("\n" + report_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
