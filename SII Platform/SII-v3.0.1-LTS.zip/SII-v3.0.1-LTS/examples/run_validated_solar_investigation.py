from __future__ import annotations

import hashlib
from pathlib import Path

from sii_v2.certificate import render_investigation_certificate
from sii_v2.engines import (
    BaselineDiscoveryEngine,
    BaselinePublicationEngine,
    ValidatedSolarQualificationEngine,
    ValidatedSolarRepresentationEngine,
)
from sii_v2.identity import new_id
from sii_v2.instrument import StructuralIntelligenceInstrument
from sii_v2.objects import DatasetRecord, ExperimentDefinition, Investigation, ScientificQuestion
from sii_v2.reporting import write_investigation_report
from sii_v2.repository import FileStructuralKnowledgeRepository


# =============================================================================
# USER PARAMETERS
# Edit only this section before running the investigation.
# =============================================================================

# Analysis-ready Solar dataset used by the validated M1D/RIX implementation.
DATASET_PATH = Path(
    r"C:\Users\scott\PyCharmMiscProject\data\Goldilocks v2"
    r"\SOLAR\dataset_B_core_solar_all.csv.gz"
)

# Output directory for the SII Scientific Record, Evidence Chain,
# Equivalence Record, Investigation Certificate, and SKR.
OUTPUT_DIR = Path(
    r"C:\Users\scott\PyCharmMiscProject\examples\sii_v2_2_output"
)

# Registered random seed used by the validated representation engine.
RANDOM_SEED = 42

# Recommended first run:
#   True  = exact v1-to-v2 representation equivalence only
#   False = exact equivalence plus the complete preserved Phase 1 qualification
BASELINE_ONLY = True

# Investigation identity and scientific framing.
INVESTIGATION_CODE = "SOLAR-M1D-V25"
INVESTIGATION_NAME = "Validated Solar Organizational Regime Investigation"
EXPERIMENT_NAME = "Solar M1D/RIX Validated Integration"
SCIENTIFIC_QUESTION = "Does solar activity exhibit stable organizational regimes?"
DOMAIN = "solar dynamics"
HYPOTHESES = (
    "Solar observations contain reproducible organizational regimes.",
)
OBJECTIVES = (
    "Preserve the validated Solar M1D/RIX representation.",
    "Demonstrate exact scientific-output equivalence under SII v2.2.",
    "Create a complete Evidence Chain and Scientific Record.",
)

# =============================================================================
# END USER PARAMETERS
# =============================================================================


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def progress(stage: str, message: str) -> None:
    print(f"[{stage.upper():11}] {message}")


def validate_parameters() -> tuple[Path, Path]:
    dataset_path = DATASET_PATH.expanduser().resolve()
    output_path = OUTPUT_DIR.expanduser().resolve()

    if not dataset_path.exists():
        raise FileNotFoundError(
            "The configured DATASET_PATH does not exist.\n"
            f"Configured path: {dataset_path}\n"
            "Edit DATASET_PATH in the USER PARAMETERS section."
        )
    if not dataset_path.is_file():
        raise ValueError(f"DATASET_PATH is not a file: {dataset_path}")
    if not isinstance(RANDOM_SEED, int):
        raise TypeError("RANDOM_SEED must be an integer.")
    if not isinstance(BASELINE_ONLY, bool):
        raise TypeError("BASELINE_ONLY must be True or False.")

    return dataset_path, output_path


def main() -> None:
    dataset_path, output = validate_parameters()
    project_root = Path(__file__).resolve().parents[1]
    repository = FileStructuralKnowledgeRepository(output / "skr")

    print("STRUCTURAL INTELLIGENCE INSTRUMENT v2.5")
    print("CLOSED-LOOP SOLAR QUALIFICATION")
    print("=" * 60)
    print(f"Dataset: {dataset_path}")
    print(f"Output: {output}")
    print(f"Seed: {RANDOM_SEED}")
    print(
        "Execution mode: "
        + ("baseline equivalence only" if BASELINE_ONLY else "full Phase 1 qualification")
    )
    print()

    question = ScientificQuestion(
        object_id=new_id("question"),
        text=SCIENTIFIC_QUESTION,
        domain=DOMAIN,
        hypotheses=HYPOTHESES,
    )
    investigation = Investigation(
        object_id=new_id("investigation"),
        code=INVESTIGATION_CODE,
        name=INVESTIGATION_NAME,
        question_id=question.object_id,
        objectives=OBJECTIVES,
        enabled_capabilities=("represent", "qualify", "discover", "publish"),
    )
    experiment = ExperimentDefinition(
        object_id=new_id("experiment"),
        code=INVESTIGATION_CODE,
        name=EXPERIMENT_NAME,
        scientific_question=question.text,
        investigation_id=investigation.object_id,
        objectives=investigation.objectives,
        enabled_capabilities=investigation.enabled_capabilities,
    )
    dataset = DatasetRecord(
        object_id=new_id("dataset"),
        name=dataset_path.name,
        uri=str(dataset_path),
        sha256=sha256_file(dataset_path),
    )

    solar_engine = ValidatedSolarRepresentationEngine(
        project_root=project_root,
        dataset_path=dataset_path,
        output_dir=output / "legacy_phase1",
        run_full_qualification=not BASELINE_ONLY,
    )
    instrument = StructuralIntelligenceInstrument(
        repository=repository,
        representation_engine=solar_engine,
        qualification_engine=ValidatedSolarQualificationEngine(solar_engine),
        discovery_engine=BaselineDiscoveryEngine(),
        publication_engine=BaselinePublicationEngine(),
        progress=progress,
    )
    record = instrument.investigate(
        question=question,
        investigation=investigation,
        experiment=experiment,
        dataset=dataset,
        run_name="SII v2.5 Durable Representation Product",
        random_seed=RANDOM_SEED,
    )

    report_path = output / "investigation_report.txt"
    write_investigation_report(
        record=record,
        repository=repository,
        path=report_path,
    )
    certificate_path = render_investigation_certificate(
        record=record,
        repository=repository,
        investigation_name=investigation.name,
        scientific_question=question.text,
        output_path=output / "investigation_certificate.txt",
    )

    print()
    print("Scientific Investigation Complete.")
    print(f"Scientific Record: {record.object_id}")
    print(f"Entitlement: {record.entitlement_level.value}")
    print(
        "Equivalence: "
        + ("PASSED" if solar_engine.equivalence_record.passed else "FAILED")
    )
    print(f"Report: {report_path}")
    print(f"Certificate: {certificate_path}")
    representation_objects = repository.load_by_type("representation_product")
    representation_product = representation_objects[-1]
    print(f"Representation Product: {representation_product.get('package_uri')}")
    print(f"Representation Product SHA-256: {representation_product.get('package_sha256')}")
    print(f"SKR: {repository.root}")


if __name__ == "__main__":
    main()
