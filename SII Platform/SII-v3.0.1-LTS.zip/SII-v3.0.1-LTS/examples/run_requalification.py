from __future__ import annotations

import json
import shutil
from pathlib import Path

from sii_v2.request_loader import load_requalification_request
from sii_v2.requalification import execute_solar_requalification
from sii_v2.comparison import build_comparative_evaluation, write_comparative_reports


# =============================================================================
# Investigation Configuration
# =============================================================================
# Edit only this block for the local SII v2.8 comparative requalification investigation.

WORKSPACE_ROOT = Path(r"C:\Users\scott\PyCharmMiscProject")

PROJECT = "solar"

REQUEST_DIRECTORY = (
    WORKSPACE_ROOT
    / "examples"
    / "aiia_platform_v0_6_1"
    / PROJECT
    / "sii_requalification_requests"
)

DATASET_PATH = (
    WORKSPACE_ROOT
    / "data"
    / "Goldilocks v2"
    / "ANALYSIS_READY"
    / "dataset_B_core_solar_all.csv.gz"
)

OUTPUT_DIRECTORY = (
    WORKSPACE_ROOT
    / "examples"
    / "sii_v2_8_requalification"
)

QUALIFICATION_PROFILE = "validated-solar-phase1"
RANDOM_SEED = 42

# Use (2,) for the first candidate only, or (2, 3, 4) for all candidates.
RUN_SPLITS = (2, 3, 4)

# When True, an existing output directory for a selected split is replaced.
OVERWRITE_EXISTING = True

# The SII source root is derived from this runner and normally should not change.
SII_PROJECT_ROOT = Path(__file__).resolve().parents[1]


# =============================================================================
# Investigation Execution
# =============================================================================

def _validate_configuration() -> None:
    if not WORKSPACE_ROOT.exists():
        raise FileNotFoundError(f"WORKSPACE_ROOT does not exist: {WORKSPACE_ROOT}")
    if not REQUEST_DIRECTORY.is_dir():
        raise FileNotFoundError(f"REQUEST_DIRECTORY does not exist: {REQUEST_DIRECTORY}")
    if not DATASET_PATH.is_file():
        raise FileNotFoundError(f"DATASET_PATH does not exist: {DATASET_PATH}")
    if not RUN_SPLITS:
        raise ValueError("RUN_SPLITS must contain at least one split count.")
    if len(set(RUN_SPLITS)) != len(RUN_SPLITS):
        raise ValueError("RUN_SPLITS contains duplicate values.")
    if any(not isinstance(value, int) or value < 2 for value in RUN_SPLITS):
        raise ValueError("Every RUN_SPLITS value must be an integer of 2 or greater.")


def _load_selected_jobs():
    request_paths = sorted(REQUEST_DIRECTORY.glob("*.json"))
    if not request_paths:
        raise FileNotFoundError(f"No JSON request files found in: {REQUEST_DIRECTORY}")

    jobs_by_split = {}
    for request_path in request_paths:
        job = load_requalification_request(request_path)
        if job.split_count in jobs_by_split:
            raise ValueError(f"Multiple requests found for split {job.split_count}.")
        jobs_by_split[job.split_count] = job

    missing = [split for split in RUN_SPLITS if split not in jobs_by_split]
    if missing:
        raise FileNotFoundError(
            f"No requalification request was found for split(s): {missing}. "
            f"Available splits: {sorted(jobs_by_split)}"
        )

    return tuple(jobs_by_split[split] for split in RUN_SPLITS)


def main() -> None:
    _validate_configuration()
    jobs = _load_selected_jobs()

    print("=" * 60)
    print("STRUCTURAL INTELLIGENCE INSTRUMENT v2.8")
    print("Independent Requalification and Comparative Scientific Evaluation")
    print("=" * 60)
    print(f"Workspace:             {WORKSPACE_ROOT.resolve()}")
    print(f"Project:               {PROJECT}")
    print(f"Request directory:     {REQUEST_DIRECTORY.resolve()}")
    print(f"Dataset:               {DATASET_PATH.resolve()}")
    print(f"Output:                {OUTPUT_DIRECTORY.resolve()}")
    print(f"Qualification profile: {QUALIFICATION_PROFILE}")
    print(f"Random seed:           {RANDOM_SEED}")
    print(f"Selected splits:       {', '.join(str(value) for value in RUN_SPLITS)}")
    print(f"Overwrite existing:    {OVERWRITE_EXISTING}")
    print("Configuration:         VALID")

    summary = []
    comparative_inputs = []
    for job in jobs:
        request_profile = str(job.request.get("requested_profile") or "")
        if request_profile and QUALIFICATION_PROFILE not in request_profile:
            raise ValueError(
                f"Request {job.request['object_id']} specifies profile {request_profile!r}, "
                f"which does not match configured profile {QUALIFICATION_PROFILE!r}."
            )

        candidate_output = OUTPUT_DIRECTORY / f"dominant_basin_split_{job.split_count}"
        print(f"\nPreflight PASS: split {job.split_count} | {job.candidate_id}")

        if candidate_output.exists():
            if not OVERWRITE_EXISTING:
                raise FileExistsError(
                    f"Output already exists for split {job.split_count}: {candidate_output}. "
                    "Set OVERWRITE_EXISTING = True to replace it."
                )
            shutil.rmtree(candidate_output)

        result = execute_solar_requalification(
            job=job,
            project_root=SII_PROJECT_ROOT,
            dataset_path=DATASET_PATH,
            output_dir=candidate_output,
        )
        comparative_inputs.append((job.split_count, result))
        summary.append(
            {
                "request_id": result["request_id"],
                "candidate_id": result["candidate_product_id"],
                "split_count": job.split_count,
                "status": result["status"],
            }
        )
        print(f"Completed: split {job.split_count} | status={result['status']}")

    OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)
    summary_payload = {
        "schema": "aiia.sii.requalification-summary",
        "schema_version": "1.1",
        "instrument_version": "2.7.0",
        "project": PROJECT,
        "qualification_profile": QUALIFICATION_PROFILE,
        "random_seed": RANDOM_SEED,
        "selected_splits": list(RUN_SPLITS),
        "results": summary,
    }
    comparative_payload = build_comparative_evaluation(comparative_inputs)
    summary_payload["comparative_qualification"] = {
        "recommended_candidate_id": comparative_payload["recommended_candidate_id"],
        "recommended_split_count": comparative_payload["recommended_split_count"],
        "ranking": comparative_payload["ranking"],
        "pareto_frontier": comparative_payload["pareto_frontier"],
    }
    (OUTPUT_DIRECTORY / "requalification_summary.json").write_text(
        json.dumps(summary_payload, indent=2),
        encoding="utf-8",
    )
    write_comparative_reports(comparative_payload, OUTPUT_DIRECTORY)

    print("\nSII v2.8 requalification and comparison run complete.")
    print(f"Candidates evaluated: {len(summary)}")
    print(f"Recommended split:    {comparative_payload['recommended_split_count']}")
    print(f"Recommended candidate:{comparative_payload['recommended_candidate_id']}")
    print(f"Output: {OUTPUT_DIRECTORY.resolve()}")


if __name__ == "__main__":
    main()
