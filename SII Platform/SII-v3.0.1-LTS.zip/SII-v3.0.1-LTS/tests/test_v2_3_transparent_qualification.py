from sii_v2.objects import QualificationCheck, QualificationCheckState

def test_check_object():
    check=QualificationCheck(check_id="x",display_name="X",state=QualificationCheckState.PASS)
    assert check.object_type=="qualification_check"
