from sii_v2.engines.representation_improvement import RepresentationImprovementEngine
from sii_v2.objects import ImprovementStatus

def test_compare_improvement():
    t=RepresentationImprovementEngine().compare(baseline_qualification_id="q1",candidate_representation_id="r2",candidate_qualification_id="q2",target_check_ids=("seed_median_aligned_ari","maximum_basin_occupancy"),baseline_metrics={"seed_median_aligned_ari":0.35,"maximum_basin_occupancy":0.92},candidate_metrics={"seed_median_aligned_ari":0.56,"maximum_basin_occupancy":0.87})
    assert t.status is ImprovementStatus.IMPROVED
