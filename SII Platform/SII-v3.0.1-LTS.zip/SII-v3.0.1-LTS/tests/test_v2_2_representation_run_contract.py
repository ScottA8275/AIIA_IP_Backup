from pathlib import Path


def test_adapter_uses_actual_representation_run_interface():
    root = Path(__file__).resolve().parents[1]
    source = (root / "sii_v2" / "engines" / "solar_validated.py").read_text(encoding="utf-8")
    assert "run.config.config_id" not in source
    assert "baseline.config.config_id" not in source
    assert "run.config_id" in source
    assert "baseline.config_id" in source
    assert 'getattr(run, "metric_values", {})' in source
