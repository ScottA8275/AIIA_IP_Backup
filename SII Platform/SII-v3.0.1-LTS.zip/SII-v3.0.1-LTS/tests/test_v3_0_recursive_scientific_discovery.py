from pathlib import Path
import json

from sii_v3.discovery import (
    DiscoveryPolicy,
    build_discovery_cycle,
    diagnose_evidence,
    write_discovery_outputs,
)


def _evidence():
    rows = [
        {"split_count": 2, "candidate_id": "c2", "status": "supported", "normalized_margin_score": 0.297362, "split_merge_consistency": 0.8993},
        {"split_count": 3, "candidate_id": "c3", "status": "supported", "normalized_margin_score": 0.330788, "split_merge_consistency": 0.8766},
        {"split_count": 4, "candidate_id": "c4", "status": "supported", "normalized_margin_score": 0.356101, "split_merge_consistency": 0.8418},
        {"split_count": 5, "candidate_id": "c5", "status": "supported", "normalized_margin_score": 0.356261, "split_merge_consistency": 0.8120},
        {"split_count": 6, "candidate_id": "c6", "status": "supported", "normalized_margin_score": 0.329812, "split_merge_consistency": 0.7750},
    ]
    return {
        "optimization": {
            "schema": "aiia.sii.structural-optimization-study",
            "stop_reason": "optimization_plateau",
            "evaluated_candidates": rows,
        },
        "entitlement": {
            "optimal_set": [
                {"split_count": 4, "candidate_id": "c4"},
                {"split_count": 5, "candidate_id": "c5"},
            ],
            "recommended_split_count": 4,
        },
        "comparison": {"candidates": []},
        "summary": {"schema": "aiia.sii.structural-optimization-summary"},
    }


def test_diagnosis_detects_plateau_and_entitlement_region():
    diagnosis, signatures = diagnose_evidence(_evidence(), DiscoveryPolicy())
    assert diagnosis["peak_score_split"] == 5
    assert diagnosis["optimal_set"] == [4, 5]
    assert diagnosis["recommended_split"] == 4
    by_id = {item.signature_id: item for item in signatures}
    assert by_id["optimization_plateau"].present
    assert by_id["bounded_optimal_region"].present
    assert by_id["split_merge_tradeoff"].present


def test_cycle_selects_replication_before_new_intervention_family():
    cycle = build_discovery_cycle(_evidence(), DiscoveryPolicy(replication_seed_count=5))
    assert cycle.selected_hypothesis_id == "H-RSD-001"
    assert cycle.next_study_request["design"]["study_type"] == "multi_seed_replication"
    assert len(cycle.next_study_request["design"]["random_seeds"]) == 5
    assert cycle.authorization_status == "pending_human_authorization"


def test_hypotheses_are_falsifiable_and_ranked():
    cycle = build_discovery_cycle(_evidence(), DiscoveryPolicy())
    scores = [item.priority_score for item in cycle.hypotheses]
    assert scores == sorted(scores, reverse=True)
    assert all(item.falsification_criteria for item in cycle.hypotheses)
    assert all(item.expected_observations for item in cycle.hypotheses)


def test_outputs_are_written(tmp_path: Path):
    cycle = build_discovery_cycle(_evidence(), DiscoveryPolicy())
    paths = write_discovery_outputs(cycle, tmp_path)
    assert all(path.exists() for path in paths.values())
    request = json.loads((tmp_path / "next_study_request.json").read_text())
    assert request["authorization_required"] is True
