from dataclasses import replace

from sii_v2.comparison import compare_candidate
from sii_v2.optimization import OptimizationPolicy, evaluate_stopping_rule


def _result(candidate_id: str, margin_value: float, split_merge: float, status: str = "supported"):
    parent = {
        "metric_results": {
            "quality": {"value": 0.50, "state": "supported", "threshold": 0.50, "direction": "greater_equal"},
            "parameter_split_merge_consistency": {"value": 0.94, "state": "supported", "threshold": 0.60, "direction": "greater_equal"},
        }
    }
    candidate = {
        "metric_results": {
            "quality": {"value": margin_value, "state": status, "threshold": 0.50, "direction": "greater_equal"},
            "parameter_split_merge_consistency": {"value": split_merge, "state": "supported", "threshold": 0.60, "direction": "greater_equal"},
        }
    }
    return {
        "candidate_product_id": candidate_id,
        "request_id": f"request-{candidate_id}",
        "status": status,
        "parent_phase1_summary": parent,
        "candidate_phase1_summary": candidate,
    }


def test_plateau_stops_after_configured_patience():
    policy = OptimizationPolicy(minimum_margin_improvement=0.01, maximum_candidates_without_improvement=2)
    first = compare_candidate(_result("split-4", 0.70, 0.84), split_count=4)
    d1 = evaluate_stopping_rule(
        comparison=first, policy=policy, best_margin_score=None,
        consecutive_without_improvement=0, previous_split_merge_value=None,
    )
    assert not d1.stop
    second = compare_candidate(_result("split-5", 0.702, 0.82), split_count=5)
    d2 = evaluate_stopping_rule(
        comparison=second, policy=policy, best_margin_score=d1.best_margin_score,
        consecutive_without_improvement=d1.consecutive_without_improvement,
        previous_split_merge_value=d1.split_merge_value,
    )
    assert not d2.stop
    third = compare_candidate(_result("split-6", 0.704, 0.80), split_count=6)
    d3 = evaluate_stopping_rule(
        comparison=third, policy=policy, best_margin_score=d2.best_margin_score,
        consecutive_without_improvement=d2.consecutive_without_improvement,
        previous_split_merge_value=d2.split_merge_value,
    )
    assert d3.stop
    assert d3.reason == "optimization_plateau"


def test_large_step_regression_stops_study():
    policy = OptimizationPolicy(maximum_split_merge_regression=0.05)
    comparison = compare_candidate(_result("split-5", 0.75, 0.78), split_count=5)
    decision = evaluate_stopping_rule(
        comparison=comparison, policy=policy, best_margin_score=0.20,
        consecutive_without_improvement=0, previous_split_merge_value=0.84,
    )
    assert decision.stop
    assert decision.reason == "maximum_split_merge_regression_exceeded"


def test_loss_of_support_stops_study():
    policy = OptimizationPolicy()
    comparison = compare_candidate(_result("split-7", 0.40, 0.75, status="not_supported"), split_count=7)
    decision = evaluate_stopping_rule(
        comparison=comparison, policy=policy, best_margin_score=0.30,
        consecutive_without_improvement=0, previous_split_merge_value=0.80,
    )
    assert decision.stop
    assert decision.reason == "scientific_qualification_lost"
