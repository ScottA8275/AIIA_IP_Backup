from pathlib import Path
import numpy as np

from sii_v2.identity import new_id
from sii_v2.objects import DatasetRecord, ExperimentDefinition, RepresentationProduct
from sii_v2.representation_package import RepresentationProductStore


def test_representation_product_package_is_immutable_and_loadable(tmp_path: Path) -> None:
    store = RepresentationProductStore(tmp_path)
    representation = RepresentationProduct(
        object_id=new_id("representation"),
        experiment_code="TEST",
        configuration_id="baseline",
        observation_count=4,
        feature_names=("x",),
        payload={"method": "test"},
    )
    dataset = DatasetRecord(name="test.csv", uri="test.csv", observation_count=4)
    experiment = ExperimentDefinition(code="TEST", name="Test", scientific_question="Test?")
    product = store.persist(
        representation=representation,
        arrays={
            "basin_assignments": np.array([0, 0, 1, 1]),
            "coordinate_matrix": np.array([[0.0], [0.1], [1.0], [1.1]]),
        },
        dataset=dataset,
        experiment=experiment,
        instrument_name="SII",
        instrument_version="2.5.0-alpha.1",
    )
    assert Path(product.package_uri).exists()
    assert product.package_sha256
    manifest = store.inspect(Path(product.package_uri))
    arrays = store.load_arrays(Path(product.package_uri))
    assert manifest["product_id"] == product.object_id
    assert arrays["coordinate_matrix"].shape == (4, 1)
