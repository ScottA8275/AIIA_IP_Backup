from sii_v2.comparison import build_comparative_evaluation


def _result(candidate_id, ari, dominant, minor, occupancy, confidence=0.7):
    parent = {
        "confidence": 0.43,
        "metric_results": {
            "ari": {"value": 0.35, "state": "not_supported", "threshold": 0.5, "direction": "greater_equal"},
            "dominant": {"value": 0.88, "state": "supported", "threshold": 0.8, "direction": "greater_equal"},
            "minor": {"value": 0.39, "state": "not_supported", "threshold": 0.45, "direction": "greater_equal"},
            "occupancy": {"value": 0.92, "state": "not_supported", "threshold": 0.9, "direction": "less_equal"},
        },
    }
    candidate = {
        "confidence": confidence,
        "metric_results": {
            "ari": {"value": ari, "state": "supported", "threshold": 0.5, "direction": "greater_equal"},
            "dominant": {"value": dominant, "state": "supported", "threshold": 0.8, "direction": "greater_equal"},
            "minor": {"value": minor, "state": "supported", "threshold": 0.45, "direction": "greater_equal"},
            "occupancy": {"value": occupancy, "state": "supported", "threshold": 0.9, "direction": "less_equal"},
        },
    }
    return {
        "candidate_product_id": candidate_id,
        "request_id": f"request-{candidate_id}",
        "status": "supported",
        "parent_phase1_summary": parent,
        "candidate_phase1_summary": candidate,
    }


def test_comparative_evaluation_recommends_strongest_threshold_margin():
    payload = build_comparative_evaluation([
        (2, _result("split-2", 0.55, 0.91, 0.49, 0.76)),
        (3, _result("split-3", 0.59, 0.90, 0.53, 0.64)),
        (4, _result("split-4", 0.61, 0.93, 0.56, 0.55)),
    ])
    assert payload["recommended_candidate_id"] == "split-4"
    assert payload["recommended_split_count"] == 4
    assert payload["ranking"][0] == "split-4"


def test_new_blocking_metric_excludes_candidate():
    weak = _result("weak", 0.61, 0.93, 0.56, 0.55)
    weak["candidate_phase1_summary"]["metric_results"]["dominant"]["state"] = "not_supported"
    payload = build_comparative_evaluation([
        (2, _result("eligible", 0.55, 0.91, 0.49, 0.76)),
        (4, weak),
    ])
    assert payload["recommended_candidate_id"] == "eligible"
