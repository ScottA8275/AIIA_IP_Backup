from pathlib import Path

import pytest

from sii_v2 import (
    DatasetRecord,
    ExperimentDefinition,
    FileStructuralKnowledgeRepository,
    Investigation,
    ScientificQuestion,
    StructuralIntelligenceInstrument,
    render_investigation_report,
)
from sii_v2.adapters import V1RepresentationEngineBridge
from sii_v2.engines import BaselineDiscoveryEngine, BaselinePublicationEngine, BaselineQualificationEngine


def make_instrument(tmp_path: Path) -> tuple[StructuralIntelligenceInstrument, FileStructuralKnowledgeRepository]:
    bridge = V1RepresentationEngineBridge(
        name="test",
        version="1",
        build_callback=lambda dataset, experiment, seed: {"configuration_id": f"seed-{seed}", "observation_count": dataset.observation_count},
        atlas_callback=lambda representation: {"basin_count": 2, "neighborhood_count": 8, "occupancy": {"a": 0.8, "b": 0.2}},
    )
    repository = FileStructuralKnowledgeRepository(tmp_path / "skr")
    return StructuralIntelligenceInstrument(
        repository=repository,
        representation_engine=bridge,
        qualification_engine=BaselineQualificationEngine(),
        discovery_engine=BaselineDiscoveryEngine(),
        publication_engine=BaselinePublicationEngine(),
    ), repository


def test_first_executable_investigation(tmp_path: Path) -> None:
    instrument, repository = make_instrument(tmp_path)
    question = ScientificQuestion(text="Does it run?", domain="test")
    investigation = Investigation(
        code="INV-1", name="Executable Test", question_id=question.object_id,
        enabled_capabilities=("represent", "qualify", "discover", "publish"),
    )
    experiment = ExperimentDefinition(
        code="EXP-1", name="Test Protocol", scientific_question=question.text,
        investigation_id=investigation.object_id,
    )
    record = instrument.investigate(
        question=question,
        investigation=investigation,
        experiment=experiment,
        dataset=DatasetRecord(name="data", uri="memory://test", observation_count=1000, feature_names=("x",)),
        run_name="test",
    )
    assert record.question_id == question.object_id
    assert record.investigation_id == investigation.object_id
    assert record.claim_ids and record.evidence_chain_ids
    assert repository.get(record.evidence_chain_ids[0])["links"][0]["source_object_id"] == question.object_id
    assert "Investigation complete." in render_investigation_report(record, repository)


def test_plan_rejects_wrong_question_reference(tmp_path: Path) -> None:
    instrument, _ = make_instrument(tmp_path)
    question = ScientificQuestion(text="Question", domain="test")
    investigation = Investigation(code="INV-X", name="Bad Plan", question_id="wrong")
    experiment = ExperimentDefinition(code="EXP-X", name="Protocol", scientific_question=question.text, investigation_id=investigation.object_id)
    with pytest.raises(ValueError, match="question_id"):
        instrument.investigate(
            question=question,
            investigation=investigation,
            experiment=experiment,
            dataset=DatasetRecord(name="data", uri="memory://test", observation_count=100),
            run_name="bad",
        )
