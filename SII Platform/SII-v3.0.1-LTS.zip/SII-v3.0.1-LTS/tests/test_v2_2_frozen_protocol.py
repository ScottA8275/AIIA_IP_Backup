from pathlib import Path


def test_solar_adapter_uses_immutable_protocol_replacement():
    root = Path(__file__).resolve().parents[1]
    source = (root / "sii_v2" / "engines" / "solar_validated.py").read_text(encoding="utf-8")
    assert "protocol.paths.input_file =" not in source
    assert "paths=replace(" in source
    assert "input_file=self.dataset_path" in source
