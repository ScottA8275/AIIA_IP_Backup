from pathlib import Path
import numpy as np
from dataclasses import dataclass, replace

from sii_v2.requalification import DominantBasinReplayBuilder

@dataclass(frozen=True)
class Artifacts:
    embedded_states: np.ndarray
    basin_assignments: np.ndarray

@dataclass(frozen=True)
class Run:
    assignments: np.ndarray
    basin_profiles: np.ndarray
    basin_occupancy: np.ndarray
    representation: Artifacts
    metadata: dict


def test_replay_builder_splits_largest_basin_deterministically():
    x = np.vstack([np.column_stack([np.arange(8), np.arange(8)]), np.ones((2, 2)) * 20])
    base = Run(np.array([0] * 8 + [1] * 2), np.zeros((2, 2)), np.array([8., 2.]), Artifacts(x, np.array([0] * 8 + [1] * 2)), {})
    builder = DominantBasinReplayBuilder(lambda *_: base, {
        "intervention_type": "dominant_basin_hierarchical_split",
        "split_count": 2,
        "algorithm_parameters": {"max_iter": 10},
    })
    first = builder(None, None, 42, "a")
    second = builder(None, None, 42, "b")
    assert len(np.unique(first.assignments)) == 3
    assert np.array_equal(first.assignments, second.assignments)
    assert int(first.basin_occupancy.sum()) == 10
