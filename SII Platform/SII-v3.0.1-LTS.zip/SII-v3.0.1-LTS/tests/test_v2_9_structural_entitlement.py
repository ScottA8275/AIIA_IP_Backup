from sii_v2.entitlement import EntitlementPolicy, detect_structural_entitlement


def _row(split, score, status="supported", blocking=None, newly_blocking=0):
    return {
        "split_count": split,
        "candidate_id": f"candidate-{split}",
        "status": status,
        "normalized_margin_score": score,
        "blocking_metric_ids": blocking or [],
        "newly_blocking_metrics": newly_blocking,
    }


def test_optimal_set_detects_equivalent_peak_region_and_prefers_simplest():
    payload = detect_structural_entitlement(
        evaluated_candidates=[
            _row(2, 0.297362),
            _row(3, 0.330788),
            _row(4, 0.356101),
            _row(5, 0.356261),
            _row(6, 0.329812),
        ],
        policy=EntitlementPolicy(score_equivalence_tolerance=0.01),
        stop_reason="optimization_plateau",
    )
    assert payload["entitlement_status"] == "established"
    assert [row["split_count"] for row in payload["optimal_set"]] == [4, 5]
    assert payload["recommended_split_count"] == 4
    assert payload["recommendation_reason"] == "lowest_complexity_member_of_optimal_set"
    assert payload["optimal_regions"][0]["minimum_split"] == 4
    assert payload["optimal_regions"][0]["maximum_split"] == 5


def test_ineligible_peak_does_not_enter_entitlement_set():
    payload = detect_structural_entitlement(
        evaluated_candidates=[
            _row(4, 0.35),
            _row(5, 0.40, status="concern"),
            _row(6, 0.39, blocking=["x"]),
        ],
        policy=EntitlementPolicy(score_equivalence_tolerance=0.01),
    )
    assert [row["split_count"] for row in payload["optimal_set"]] == [4]
    assert payload["recommended_split_count"] == 4


def test_no_eligible_candidates_yields_no_entitlement():
    payload = detect_structural_entitlement(
        evaluated_candidates=[_row(2, 0.3, status="concern")],
        policy=EntitlementPolicy(),
    )
    assert payload["entitlement_status"] == "not_established"
    assert payload["optimal_set"] == []
    assert payload["recommended_split_count"] is None


def test_noncontiguous_optimal_set_is_reported_as_separate_regions():
    payload = detect_structural_entitlement(
        evaluated_candidates=[
            _row(2, 0.50),
            _row(3, 0.45),
            _row(4, 0.495),
        ],
        policy=EntitlementPolicy(score_equivalence_tolerance=0.01),
    )
    assert [region["split_counts"] for region in payload["optimal_regions"]] == [[2], [4]]
