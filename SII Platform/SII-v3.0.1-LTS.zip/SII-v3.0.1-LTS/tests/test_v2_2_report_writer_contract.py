from pathlib import Path


def test_validated_runner_uses_report_writer_api():
    root = Path(__file__).resolve().parents[1]
    source = (root / "examples" / "run_validated_solar_investigation.py").read_text(encoding="utf-8")
    assert "from sii_v2.reporting import write_investigation_report" in source
    assert "write_investigation_report(" in source
    assert "path=report_path" in source
    assert "output_path=report_path" not in source
