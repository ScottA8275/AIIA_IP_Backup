
from pathlib import Path

from sii_v2.identity import new_id
from sii_v2.objects import EquivalenceRecord, Provenance


def test_equivalence_record_is_a_scientific_object():
    record = EquivalenceRecord(
        object_id=new_id("equivalence"),
        source_engine_name="Solar v1",
        source_engine_version="1.0",
        target_engine_name="SII v2.2 Solar",
        target_engine_version="2.2",
        comparison_profile="exact",
        passed=True,
        compared_metrics={"n_states": 100},
        tolerances={"absolute": 1e-12},
        source_result_fingerprint="abc",
        target_result_fingerprint="abc",
        provenance=Provenance(instrument_version="2.2.0-alpha.1"),
    )
    assert record.passed
    assert record.source_result_fingerprint == record.target_result_fingerprint


def test_preserved_legacy_files_exist():
    root = Path(__file__).resolve().parents[1]
    required = [
        "phase1_representation.py",
        "qualification_config.py",
        "qualification_metrics.py",
        "qualification_types.py",
        "solar_m1d_adapter.py",
        "run_m1d_solar_atlas_validation.py",
    ]
    assert all((root / "legacy_solar_v1" / name).exists() for name in required)
