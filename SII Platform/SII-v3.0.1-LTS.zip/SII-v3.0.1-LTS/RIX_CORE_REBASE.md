# RIX Core rebase

SII v3.0.1 LTS is a behavior-preserving maintenance release of v3.0 LTS.

Shared deterministic clustering, representation-array inventory, and file integrity now come from RIX Core v1.0 LTS. Qualification, comparison, optimization, entitlement, and recursive discovery remain owned by SII.
