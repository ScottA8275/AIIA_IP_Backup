# Structural Intelligence Instrument v3.0

## Recursive Scientific Discovery — First Executable Cycle

SII v3.0 begins recursive scientific discovery by converting a completed, independently qualified SII study into a bounded portfolio of falsifiable next hypotheses.

The v3.0 discovery cycle is:

```text
Qualified study evidence
        ↓
Evidence signatures
        ↓
Scientific diagnosis
        ↓
Falsifiable hypothesis portfolio
        ↓
Transparent prioritization
        ↓
Bounded next-study request
        ↓
Human authorization gate
```

This release deliberately does **not** permit unrestricted autonomous experimentation. It does not generate arbitrary engineering code, alter qualification thresholds, or treat a proposed hypothesis as a scientific finding.

## First discovery decision

For the v2.9 Solar entitlement result, the registered rules prioritize:

**H-RSD-001 — Entitlement-region replication**

The next study tests whether the observed split 4–5 entitlement region persists across independent random seeds. This is prioritized before a new intervention family because replication is needed to distinguish a stable structural result from a seed-contingent observation.

## Outputs

- `recursive_discovery_cycle.json`
- `discovery_diagnosis.json`
- `hypothesis_portfolio.json`
- `next_study_request.json`
- `recursive_discovery_report.txt`

## Run

Edit inline parameters in:

```text
examples/run_recursive_scientific_discovery.py
```

Then run:

```powershell
python examples\run_recursive_scientific_discovery.py
```

## Governance

- SII owns evidence diagnosis, hypothesis formulation, prioritization, and scientific study specification.
- AIIA or a human-authorized implementation owns new engineering interventions.
- SII remains the independent qualification authority.
- Every hypothesis includes expected observations and explicit falsification criteria.
- New studies remain pending until authorized.
