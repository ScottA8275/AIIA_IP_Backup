from __future__ import annotations

from typing import Any, Callable

import numpy as np

from ..identity import new_id
from ..objects import (
    DatasetRecord,
    ExperimentDefinition,
    OrganizationalAtlasRecord,
    Provenance,
    RepresentationProduct,
)


class V1RepresentationEngineBridge:
    """
    Bridge a working SII v1/domain engine into the v2 scientific contracts.

    build_callback must return either a mapping or an object exposing to_dict().
    atlas_callback is optional and should return a mapping with basin_count,
    neighborhood_count, occupancy, and topology_summary keys where available.
    """

    def __init__(
        self,
        *,
        name: str,
        version: str,
        build_callback: Callable[[DatasetRecord, ExperimentDefinition, int], Any],
        atlas_callback: Callable[[RepresentationProduct], Any] | None = None,
    ) -> None:
        self.name = name
        self.version = version
        self._build_callback = build_callback
        self._atlas_callback = atlas_callback

    @staticmethod
    def _mapping(value: Any) -> dict[str, Any]:
        if isinstance(value, dict):
            return value
        if hasattr(value, "to_dict") and callable(value.to_dict):
            return value.to_dict()
        return {"value": value}

    def represent(self, *, dataset: DatasetRecord, experiment: ExperimentDefinition, seed: int) -> RepresentationProduct:
        payload = self._mapping(self._build_callback(dataset, experiment, seed))
        diagnostics = payload.pop("diagnostics", {}) if isinstance(payload, dict) else {}
        return RepresentationProduct(
            object_id=new_id("representation"),
            experiment_code=experiment.code,
            configuration_id=str(payload.get("configuration_id", "v1-bridge")),
            observation_count=int(dataset.observation_count or payload.get("observation_count", 0)),
            feature_names=dataset.feature_names,
            payload=payload,
            diagnostics=diagnostics,
            provenance=Provenance(
                engine_name=self.name,
                engine_version=self.version,
                parent_object_ids=(dataset.object_id, experiment.object_id),
                configuration={"seed": seed, "adapter": "v1_bridge"},
            ),
        )

    def representation_arrays(self, *, representation: RepresentationProduct) -> dict[str, Any]:
        arrays: dict[str, Any] = {}
        for name, value in representation.payload.items():
            if isinstance(value, np.ndarray):
                arrays[name] = value
            elif isinstance(value, (list, tuple)):
                candidate = np.asarray(value)
                if candidate.dtype != object and candidate.ndim > 0:
                    arrays[name] = candidate
        return arrays

    def atlas(self, *, representation: RepresentationProduct) -> OrganizationalAtlasRecord | None:
        if self._atlas_callback is None:
            return None
        payload = self._mapping(self._atlas_callback(representation))
        return OrganizationalAtlasRecord(
            object_id=new_id("atlas"),
            representation_id=representation.object_id,
            basin_count=payload.get("basin_count"),
            neighborhood_count=payload.get("neighborhood_count"),
            occupancy=payload.get("occupancy", {}),
            topology_summary=payload.get("topology_summary", {}),
            provenance=Provenance(
                engine_name=self.name,
                engine_version=self.version,
                parent_object_ids=(representation.object_id,),
            ),
        )
