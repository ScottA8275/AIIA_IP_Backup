from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PureWindowsPath
from typing import Any
import hashlib
import json
import zipfile


class RequalificationRequestError(ValueError):
    pass


@dataclass(frozen=True)
class RequalificationJob:
    request_path: Path
    request: dict[str, Any]
    candidate_path: Path | None
    manifest: dict[str, Any]
    representation: dict[str, Any]
    intervention_replay: dict[str, Any]

    @property
    def candidate_id(self) -> str:
        return str(self.request["candidate_product_id"])

    @property
    def split_count(self) -> int:
        return int(self.intervention_replay["split_count"])


from rix_core.integrity import sha256_file

def _resolve_candidate(raw: str, request_path: Path) -> Path:
    direct = Path(raw).expanduser()
    if direct.exists():
        return direct.resolve()

    filename = PureWindowsPath(raw).name
    roots = [request_path.parent, request_path.parent.parent, request_path.parent.parent.parent]
    for root in roots:
        matches = list(root.rglob(filename)) if root.exists() else []
        if len(matches) == 1:
            return matches[0].resolve()
        if len(matches) > 1:
            raise RequalificationRequestError(f"Candidate filename is ambiguous under {root}: {filename}")
    raise RequalificationRequestError(f"Candidate product not found: {raw}")


def _derive_replay(manifest: dict[str, Any]) -> dict[str, Any]:
    engineering = manifest.get("engineering") or {}
    parameters = engineering.get("parameters") or {}
    intervention = engineering.get("intervention")
    if intervention != "dominant_basin_hierarchical_split":
        raise RequalificationRequestError(f"Unsupported intervention: {intervention!r}")
    required = ("split_count", "feature_array", "assignment_array", "seed")
    missing = [name for name in required if name not in parameters]
    if missing:
        raise RequalificationRequestError(f"Candidate manifest lacks replay parameters: {missing}")
    return {
        "schema": "aiia.sii.intervention-replay",
        "schema_version": "1.0",
        "intervention_type": intervention,
        "target_selection": "largest_occupancy_basin",
        "feature_source": str(parameters["feature_array"]),
        "assignment_source": str(parameters["assignment_array"]),
        "split_count": int(parameters["split_count"]),
        "algorithm": "deterministic_lloyd_kmeans",
        "algorithm_parameters": {"max_iter": 100, "initialization": "random_rows_without_replacement"},
        "seed_policy": "qualification_run_seed",
        "preserve_global_coordinates": True,
    }


def load_requalification_request(path: Path) -> RequalificationJob:
    request_path = Path(path).expanduser().resolve()
    request = json.loads(request_path.read_text(encoding="utf-8"))
    required = {"object_id", "candidate_product", "candidate_product_id", "parent_product_id", "engineering_record_id", "requested_profile"}
    missing = sorted(required.difference(request))
    if missing:
        raise RequalificationRequestError(f"Request missing required fields: {missing}")
    if request.get("requested_profile") != "validated-solar-phase1":
        raise RequalificationRequestError(f"Unsupported profile: {request.get('requested_profile')!r}")

    candidate_path = _resolve_candidate(str(request["candidate_product"]), request_path)
    with zipfile.ZipFile(candidate_path) as archive:
        names = set(archive.namelist())
        required_members = {"manifest.json", "representation.json", "arrays.npz"}
        absent = sorted(required_members.difference(names))
        if absent:
            raise RequalificationRequestError(f"Candidate package missing members: {absent}")
        manifest = json.loads(archive.read("manifest.json"))
        representation = json.loads(archive.read("representation.json"))

    if manifest.get("product_id") != request["candidate_product_id"]:
        raise RequalificationRequestError("Request candidate_product_id does not match package product_id.")
    lineage = manifest.get("lineage") or {}
    if lineage.get("parent_product_id") != request["parent_product_id"]:
        raise RequalificationRequestError("Request parent_product_id does not match package lineage.")
    scientific = manifest.get("candidate_scientific_status") or representation.get("candidate_scientific_status") or {}
    if scientific.get("qualified") is True:
        raise RequalificationRequestError("Candidate is already marked scientifically qualified.")

    replay = request.get("intervention_replay") or _derive_replay(manifest)
    return RequalificationJob(request_path, request, candidate_path, manifest, representation, replay)
