from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import json


_SUPPORTED = {"supported", "pass", "passed"}


@dataclass(frozen=True)
class EntitlementPolicy:
    """Registered rules for converting an optimization curve into an entitlement region."""

    score_equivalence_tolerance: float = 0.01
    require_supported_status: bool = True
    require_no_blocking_metrics: bool = True
    prefer_lower_complexity: bool = True

    def validate(self) -> None:
        if self.score_equivalence_tolerance < 0:
            raise ValueError("score_equivalence_tolerance cannot be negative.")


def _eligible(row: Mapping[str, Any], policy: EntitlementPolicy) -> bool:
    if policy.require_supported_status and str(row.get("status", "")).lower() not in _SUPPORTED:
        return False
    if policy.require_no_blocking_metrics and (
        row.get("blocking_metric_ids") or int(row.get("newly_blocking_metrics", 0) or 0) > 0
    ):
        return False
    return isinstance(row.get("normalized_margin_score"), (int, float))


def _contiguous_regions(splits: Sequence[int]) -> list[list[int]]:
    if not splits:
        return []
    regions: list[list[int]] = [[splits[0]]]
    for split in splits[1:]:
        if split == regions[-1][-1] + 1:
            regions[-1].append(split)
        else:
            regions.append([split])
    return regions


def detect_structural_entitlement(
    *,
    evaluated_candidates: Iterable[Mapping[str, Any]],
    policy: EntitlementPolicy,
    intervention_family: str = "dominant_basin_hierarchical_split",
    stop_reason: str | None = None,
) -> dict[str, Any]:
    """Detect the score-equivalent optimal region and select its simplest entitled member.

    Entitlement is limited to candidates that were actually evaluated and scientifically supported.
    It does not authorize interpolation or extrapolation outside the observed candidate set.
    """
    policy.validate()
    rows = [dict(row) for row in evaluated_candidates]
    eligible = [row for row in rows if _eligible(row, policy)]

    if not eligible:
        return {
            "schema": "aiia.sii.structural-entitlement",
            "schema_version": "1.0",
            "instrument_version": "2.9.0",
            "intervention_family": intervention_family,
            "entitlement_status": "not_established",
            "reason": "no_scientifically_eligible_candidates",
            "optimal_set": [],
            "optimal_regions": [],
            "recommended_split_count": None,
            "recommended_candidate_id": None,
            "stop_reason": stop_reason,
        }

    peak_score = max(float(row["normalized_margin_score"]) for row in eligible)
    lower_bound = peak_score - policy.score_equivalence_tolerance
    optimal_rows = [
        row for row in eligible
        if float(row["normalized_margin_score"]) >= lower_bound
    ]
    optimal_rows.sort(key=lambda row: int(row["split_count"]))
    optimal_splits = [int(row["split_count"]) for row in optimal_rows]
    regions = _contiguous_regions(optimal_splits)

    if policy.prefer_lower_complexity:
        recommended = min(optimal_rows, key=lambda row: int(row["split_count"]))
        reason = "lowest_complexity_member_of_optimal_set"
    else:
        recommended = max(
            optimal_rows,
            key=lambda row: (float(row["normalized_margin_score"]), -int(row["split_count"])),
        )
        reason = "highest_margin_member_of_optimal_set"

    region_payloads = []
    for region in regions:
        region_rows = [row for row in optimal_rows if int(row["split_count"]) in region]
        region_payloads.append({
            "minimum_split": min(region),
            "maximum_split": max(region),
            "split_counts": region,
            "candidate_ids": [row.get("candidate_id") for row in region_rows],
            "minimum_margin_score": min(float(row["normalized_margin_score"]) for row in region_rows),
            "maximum_margin_score": max(float(row["normalized_margin_score"]) for row in region_rows),
        })

    return {
        "schema": "aiia.sii.structural-entitlement",
        "schema_version": "1.0",
        "instrument_version": "2.9.0",
        "intervention_family": intervention_family,
        "entitlement_status": "established",
        "entitlement_basis": "observed_supported_candidates_within_registered_peak_score_tolerance",
        "score_equivalence_tolerance": policy.score_equivalence_tolerance,
        "peak_margin_score": peak_score,
        "equivalence_lower_bound": lower_bound,
        "optimal_set": [
            {
                "split_count": int(row["split_count"]),
                "candidate_id": row.get("candidate_id"),
                "normalized_margin_score": float(row["normalized_margin_score"]),
                "distance_from_peak": peak_score - float(row["normalized_margin_score"]),
                "status": row.get("status"),
            }
            for row in optimal_rows
        ],
        "optimal_regions": region_payloads,
        "recommended_split_count": int(recommended["split_count"]),
        "recommended_candidate_id": recommended.get("candidate_id"),
        "recommendation_reason": reason,
        "stop_reason": stop_reason,
        "governance": (
            "Structural entitlement is restricted to evaluated candidates that retain scientific "
            "support and fall within the registered score-equivalence tolerance of the observed peak. "
            "The recommendation selects the lowest-complexity entitled candidate and does not extend "
            "entitlement beyond the observed optimal set."
        ),
    }


def write_entitlement_reports(payload: Mapping[str, Any], output_directory: Path) -> None:
    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    (output_directory / "structural_entitlement.json").write_text(
        json.dumps(payload, indent=2, default=str), encoding="utf-8"
    )

    lines = [
        "STRUCTURAL INTELLIGENCE INSTRUMENT v2.9",
        "STRUCTURAL ENTITLEMENT AND OPTIMAL REGION DETECTION",
        "=" * 72,
        "",
        f"Entitlement status: {payload.get('entitlement_status')}",
        f"Intervention family: {payload.get('intervention_family')}",
        f"Peak margin score: {payload.get('peak_margin_score')}",
        f"Equivalence tolerance: {payload.get('score_equivalence_tolerance')}",
        f"Equivalence lower bound: {payload.get('equivalence_lower_bound')}",
        f"Recommended split: {payload.get('recommended_split_count')}",
        f"Recommended candidate: {payload.get('recommended_candidate_id')}",
        f"Recommendation reason: {payload.get('recommendation_reason')}",
        "",
        "OPTIMAL SET",
    ]
    for row in payload.get("optimal_set", []):
        lines.append(
            f"- split {row['split_count']}: margin={row['normalized_margin_score']:.6f}, "
            f"distance_from_peak={row['distance_from_peak']:.6f}, candidate={row['candidate_id']}"
        )
    lines.extend(["", "OPTIMAL REGIONS"])
    for region in payload.get("optimal_regions", []):
        if region["minimum_split"] == region["maximum_split"]:
            label = str(region["minimum_split"])
        else:
            label = f"{region['minimum_split']}–{region['maximum_split']}"
        lines.append(
            f"- split region {label}: peak={region['maximum_margin_score']:.6f}, "
            f"floor={region['minimum_margin_score']:.6f}"
        )
    lines.extend(["", "SCIENTIFIC GOVERNANCE", str(payload.get("governance"))])
    (output_directory / "structural_entitlement.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
