from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Mapping
import json

from .comparison import CandidateComparison, compare_candidate
from .request_loader import RequalificationJob


@dataclass(frozen=True)
class OptimizationPolicy:
    min_split: int = 2
    max_split: int = 10
    minimum_margin_improvement: float = 0.01
    maximum_split_merge_regression: float = 0.05
    maximum_candidates_without_improvement: int = 2
    split_merge_metric_id: str = "parameter_split_merge_consistency"

    def validate(self) -> None:
        if self.min_split < 2:
            raise ValueError("min_split must be at least 2.")
        if self.max_split < self.min_split:
            raise ValueError("max_split must be greater than or equal to min_split.")
        if self.minimum_margin_improvement < 0:
            raise ValueError("minimum_margin_improvement cannot be negative.")
        if self.maximum_split_merge_regression < 0:
            raise ValueError("maximum_split_merge_regression cannot be negative.")
        if self.maximum_candidates_without_improvement < 1:
            raise ValueError("maximum_candidates_without_improvement must be at least 1.")


@dataclass(frozen=True)
class OptimizationDecision:
    stop: bool
    reason: str | None
    meaningful_improvement: bool
    consecutive_without_improvement: int
    margin_score: float
    best_margin_score: float
    split_merge_value: float | None
    split_merge_step_regression: float | None


def derive_optimization_job(template: RequalificationJob, split_count: int) -> RequalificationJob:
    """Create an immutable scientific-search job from a validated intervention-family template.

    The derived job does not claim to be an AIIA-materialized candidate package. It reuses the
    qualified parent context and the validated replay contract while assigning an explicit study ID.
    """
    replay = dict(template.intervention_replay)
    replay["split_count"] = int(split_count)
    replay["optimization_generated"] = True
    replay["optimization_family"] = "dominant_basin_hierarchical_split"

    request = dict(template.request)
    request["object_id"] = f"sii-v2-9-optimization-request-split-{split_count}"
    request["candidate_product_id"] = f"sii-v2-9-study-candidate-split-{split_count}"
    request["candidate_product"] = None
    request["optimization_generated"] = True
    request["intervention_replay"] = replay

    manifest = dict(template.manifest)
    manifest["product_id"] = request["candidate_product_id"]
    representation = dict(template.representation)
    representation["object_id"] = request["candidate_product_id"]

    return RequalificationJob(
        request_path=template.request_path,
        request=request,
        candidate_path=None,
        manifest=manifest,
        representation=representation,
        intervention_replay=replay,
    )


def _metric_value(comparison: CandidateComparison, metric_id: str) -> float | None:
    metric = comparison.metrics.get(metric_id) or {}
    value = metric.get("candidate_value")
    return float(value) if isinstance(value, (int, float)) else None


def evaluate_stopping_rule(
    *,
    comparison: CandidateComparison,
    policy: OptimizationPolicy,
    best_margin_score: float | None,
    consecutive_without_improvement: int,
    previous_split_merge_value: float | None,
) -> OptimizationDecision:
    status_supported = comparison.status.lower() in {"supported", "pass", "passed"}
    if not status_supported or comparison.blocking_metric_ids or comparison.newly_blocking_count:
        return OptimizationDecision(
            stop=True,
            reason="scientific_qualification_lost",
            meaningful_improvement=False,
            consecutive_without_improvement=consecutive_without_improvement + 1,
            margin_score=comparison.normalized_margin_score,
            best_margin_score=best_margin_score if best_margin_score is not None else comparison.normalized_margin_score,
            split_merge_value=_metric_value(comparison, policy.split_merge_metric_id),
            split_merge_step_regression=None,
        )

    margin = comparison.normalized_margin_score
    meaningful = best_margin_score is None or margin >= best_margin_score + policy.minimum_margin_improvement
    next_best = margin if best_margin_score is None else max(best_margin_score, margin)
    next_count = 0 if meaningful else consecutive_without_improvement + 1

    split_merge = _metric_value(comparison, policy.split_merge_metric_id)
    step_regression = None
    if split_merge is not None and previous_split_merge_value is not None:
        step_regression = previous_split_merge_value - split_merge
        if step_regression > policy.maximum_split_merge_regression:
            return OptimizationDecision(
                stop=True,
                reason="maximum_split_merge_regression_exceeded",
                meaningful_improvement=meaningful,
                consecutive_without_improvement=next_count,
                margin_score=margin,
                best_margin_score=next_best,
                split_merge_value=split_merge,
                split_merge_step_regression=step_regression,
            )

    if next_count >= policy.maximum_candidates_without_improvement:
        return OptimizationDecision(
            stop=True,
            reason="optimization_plateau",
            meaningful_improvement=False,
            consecutive_without_improvement=next_count,
            margin_score=margin,
            best_margin_score=next_best,
            split_merge_value=split_merge,
            split_merge_step_regression=step_regression,
        )

    return OptimizationDecision(
        stop=False,
        reason=None,
        meaningful_improvement=meaningful,
        consecutive_without_improvement=next_count,
        margin_score=margin,
        best_margin_score=next_best,
        split_merge_value=split_merge,
        split_merge_step_regression=step_regression,
    )


def build_optimization_study(
    *,
    evaluated: Iterable[tuple[int, Mapping[str, Any]]],
    decisions: Iterable[Mapping[str, Any]],
    policy: OptimizationPolicy,
    comparative_payload: Mapping[str, Any],
    stop_reason: str | None,
) -> dict[str, Any]:
    rows = []
    for split, result in evaluated:
        comparison = compare_candidate(result, split_count=split)
        rows.append({
            "split_count": split,
            "candidate_id": comparison.candidate_id,
            "status": comparison.status,
            "confidence": comparison.confidence,
            "normalized_margin_score": comparison.normalized_margin_score,
            "newly_supported_metrics": comparison.newly_supported_count,
            "newly_blocking_metrics": comparison.newly_blocking_count,
            "blocking_metric_ids": list(comparison.blocking_metric_ids),
            "split_merge_consistency": _metric_value(comparison, policy.split_merge_metric_id),
        })
    return {
        "schema": "aiia.sii.structural-optimization-study",
        "schema_version": "1.0",
        "instrument_version": "2.9.0",
        "intervention_family": "dominant_basin_hierarchical_split",
        "policy": {
            "min_split": policy.min_split,
            "max_split": policy.max_split,
            "minimum_margin_improvement": policy.minimum_margin_improvement,
            "maximum_split_merge_regression": policy.maximum_split_merge_regression,
            "maximum_candidates_without_improvement": policy.maximum_candidates_without_improvement,
            "split_merge_metric_id": policy.split_merge_metric_id,
        },
        "evaluated_candidates": rows,
        "decisions": list(decisions),
        "stop_reason": stop_reason or "maximum_split_reached",
        "recommended_candidate_id": comparative_payload.get("recommended_candidate_id"),
        "recommended_split_count": comparative_payload.get("recommended_split_count"),
        "ranking": comparative_payload.get("ranking", []),
        "pareto_frontier": comparative_payload.get("pareto_frontier", []),
        "governance": (
            "The study searches only within a registered intervention family. Comparative ranking "
            "does not replace qualification, alter candidate packages, or expand scientific entitlement."
        ),
    }


def write_optimization_reports(payload: Mapping[str, Any], output_directory: Path) -> None:
    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    (output_directory / "structural_optimization_study.json").write_text(
        json.dumps(payload, indent=2, default=str), encoding="utf-8"
    )
    lines = [
        "STRUCTURAL INTELLIGENCE INSTRUMENT v2.9",
        "STRUCTURAL OPTIMIZATION STUDY",
        "=" * 68,
        "",
        f"Intervention family: {payload.get('intervention_family')}",
        f"Stop reason: {payload.get('stop_reason')}",
        f"Recommended split: {payload.get('recommended_split_count')}",
        f"Recommended candidate: {payload.get('recommended_candidate_id')}",
        "",
        "OPTIMIZATION CURVE",
        "Split | Status | Margin score | Confidence | Split/merge consistency",
    ]
    for row in payload.get("evaluated_candidates", []):
        lines.append(
            f"{row['split_count']:>5} | {row['status']:<9} | "
            f"{row['normalized_margin_score']:.6f} | {row['confidence']} | {row['split_merge_consistency']}"
        )
    lines.extend(["", "STOPPING DECISIONS"])
    for decision in payload.get("decisions", []):
        lines.append(
            f"- split {decision['split_count']}: meaningful_improvement={decision['meaningful_improvement']} "
            f"plateau_count={decision['consecutive_without_improvement']} stop={decision['stop']} "
            f"reason={decision.get('reason')}"
        )
    lines.extend([
        "",
        "SCIENTIFIC GOVERNANCE",
        str(payload.get("governance")),
    ])
    (output_directory / "structural_optimization_study.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
