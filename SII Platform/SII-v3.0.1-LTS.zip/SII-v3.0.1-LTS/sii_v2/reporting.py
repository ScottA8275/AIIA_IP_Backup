from __future__ import annotations
from pathlib import Path
from typing import Any
from .objects import ScientificRecord
from .repository import FileStructuralKnowledgeRepository

def _fmt(v:Any)->str:
    if v is None:return "not available"
    if isinstance(v,float):return f"{v:.6g}"
    return str(v)

def render_investigation_report(record:ScientificRecord,repository:FileStructuralKnowledgeRepository)->str:
    objects={i:repository.get(i) for i in record.object_ids}
    question=objects[record.question_id]; investigation=objects[record.investigation_id]
    qualification=next(v for v in objects.values() if v["object_type"]=="qualification_record")
    representation=next(v for v in objects.values() if v["object_type"]=="representation_product")
    atlas=next((v for v in objects.values() if v["object_type"]=="organizational_atlas"),None)
    checks=[v for v in objects.values() if v["object_type"]=="qualification_check"]
    decision=next((v for v in objects.values() if v["object_type"]=="qualification_decision"),None)
    explanation=next((v for v in objects.values() if v["object_type"]=="qualification_explanation"),None)
    lines=["STRUCTURAL INTELLIGENCE INSTRUMENT v2.3","TRANSPARENT QUALIFICATION","="*66,"",
        f"Investigation: {investigation['name']}",f"Scientific question: {question['text']}",f"Domain: {question['domain']}","",
        "REPRESENTATION",f"  Product: {representation['object_id']}",f"  Configuration: {representation['configuration_id']}",f"  Observations: {representation['observation_count']}","",
        "QUALIFICATION DECISION",f"  Profile: {qualification['profile_name']}",f"  Outcome: {qualification['outcome']}",f"  Scientific Entitlement: {record.entitlement_level.value}"]
    if decision: lines += [f"  Decision rule: {decision['rule']}",f"  Checks passed: {decision['checks_passed']} / {decision['checks_total']}",f"  Critical checks passed: {decision['critical_checks_passed']}"]
    lines += ["","TRANSPARENT QUALIFICATION CHECKS"]
    for c in checks:
        marker={"pass":"PASS","fail":"FAIL","not_evaluated":"NOT EVALUATED","invalid":"INVALID"}.get(c['state'],c['state'].upper())
        crit=" | CRITICAL" if c.get('critical') else ""
        lines += [f"  [{marker}{crit}] {c['display_name']}",f"    Check ID: {c['check_id']}",f"    Value: {_fmt(c.get('measured_value'))}",f"    Criterion: {_fmt(c.get('direction'))} {_fmt(c.get('threshold'))}",f"    Evidence count: {c.get('evidence_count',0)}",f"    Rationale: {c.get('rationale','')}"]
        lines += [f"    Limitation: {x}" for x in c.get('limitations',())]
        if c.get('recommendation'): lines.append(f"    Recommended action: {c['recommendation']}")
    if explanation:
        lines += ["","QUALIFICATION EXPLANATION",f"  Summary: {explanation['summary']}","  Supporting factors:"]+[f"    + {x}" for x in explanation.get('supporting_factors',())]+["  Limiting factors:"]+[f"    - {x}" for x in explanation.get('limiting_factors',())]+["  Required actions before stronger entitlement:"]+[f"    * {x}" for x in explanation.get('required_actions',())]+["  Entitlement logic:"]+[f"    - {x}" for x in explanation.get('entitlement_explanation',())]
    if atlas: lines += ["","ORGANIZATIONAL ATLAS",f"  Basins: {atlas.get('basin_count')}",f"  Neighborhoods: {atlas.get('neighborhood_count')}"]
    lines += ["","EVIDENCE",f"  Claims: {len(record.claim_ids)}",f"  Validated Evidence Chains: {len(record.evidence_chain_ids)}",f"  Qualification Checks: {len(checks)}","","LIMITATIONS"]+[f"  - {x}" for x in record.limitations]+["","RECOMMENDATIONS"]+[f"  - {x}" for x in record.recommendations]+["","STRUCTURAL KNOWLEDGE REPOSITORY",f"  Scientific Record: {record.object_id}",f"  Location: {repository.root}","","Investigation complete."]
    return "\n".join(lines)

def write_investigation_report(record:ScientificRecord,repository:FileStructuralKnowledgeRepository,path:Path)->Path:
    path.parent.mkdir(parents=True,exist_ok=True); path.write_text(render_investigation_report(record,repository)+"\n",encoding="utf-8"); return path
