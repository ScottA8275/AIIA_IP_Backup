from __future__ import annotations

from typing import Any

from ..identity import new_id
from ..objects import (
    DiscoveryObject,
    EntitlementLevel,
    OrganizationalAtlasRecord,
    Provenance,
    QualificationOutcome,
    QualificationRecord,
    RepresentationProduct,
    ScientificEntitlement,
    ScientificRecord,
)


class BaselineQualificationEngine:
    name = "SII Baseline Qualification Engine"
    version = "2.2.0-alpha.1"

    def qualify(self, *, representation: RepresentationProduct, atlas: OrganizationalAtlasRecord | None) -> QualificationRecord:
        limitations: list[str] = []
        metrics: dict[str, Any] = {"observation_count": representation.observation_count}
        if representation.observation_count < 100:
            outcome = QualificationOutcome.EXPLORATORY
            limitations.append("Fewer than 100 observations; structural conclusions remain exploratory.")
            level = EntitlementLevel.EXPLORATORY
        else:
            outcome = QualificationOutcome.QUALIFIED_WITH_LIMITATIONS
            limitations.append("Baseline qualification does not replace domain-specific stability testing.")
            level = EntitlementLevel.INTERNAL_DECISION_SUPPORT
        if atlas is not None:
            metrics["basin_count"] = atlas.basin_count
            metrics["largest_basin_occupancy"] = max(atlas.occupancy.values(), default=None)
        entitlement = ScientificEntitlement(
            level=level,
            permitted_claims=("Describe observed organizational structure.", "Propose follow-on qualification and discovery experiments."),
            prohibited_claims=("Claim universal structure.", "Claim causality.", "Make regulatory claims."),
            rationale=("Entitlement is constrained by the baseline qualification profile.",),
        )
        return QualificationRecord(
            object_id=new_id("qualification"),
            target_object_id=representation.object_id,
            profile_name="baseline-v2",
            outcome=outcome,
            metrics=metrics,
            limitations=tuple(limitations),
            entitlement=entitlement,
            provenance=Provenance(
                engine_name=self.name,
                engine_version=self.version,
                parent_object_ids=tuple(x for x in (representation.object_id, atlas.object_id if atlas else None) if x),
            ),
        )


class BaselineDiscoveryEngine:
    name = "SII Baseline Discovery Engine"
    version = "2.2.0-alpha.1"

    def discover(self, *, representation: RepresentationProduct, atlas: OrganizationalAtlasRecord | None, qualification: QualificationRecord) -> tuple[DiscoveryObject, ...]:
        if qualification.entitlement.level == EntitlementLevel.NONE:
            return ()
        findings: dict[str, Any] = {
            "recommendation": "Evaluate recursively refinable regions.",
            "qualification_outcome": qualification.outcome.value,
        }
        if atlas is not None and atlas.occupancy:
            basin, occupancy = max(atlas.occupancy.items(), key=lambda item: item[1])
            findings.update({
                "largest_basin": basin,
                "largest_basin_occupancy": occupancy,
                "recursive_refinement_candidate": occupancy >= 0.70,
            })
        return (
            DiscoveryObject(
                object_id=new_id("discovery"),
                discovery_kind="recursive_refinement_assessment",
                source_object_ids=tuple(x for x in (representation.object_id, atlas.object_id if atlas else None, qualification.object_id) if x),
                findings=findings,
                provenance=Provenance(
                    engine_name=self.name,
                    engine_version=self.version,
                    parent_object_ids=tuple(x for x in (representation.object_id, atlas.object_id if atlas else None, qualification.object_id) if x),
                ),
            ),
        )


class BaselinePublicationEngine:
    name = "SII Baseline Publication Engine"
    version = "2.2.0-alpha.1"

    def publish(self, *, context: dict[str, Any]) -> ScientificRecord:
        return ScientificRecord(
            object_id=new_id("record"),
            session_id=context["session"].object_id,
            investigation_id=context["investigation"].object_id,
            experiment_id=context["experiment"].object_id,
            question_id=context["question"].object_id,
            object_ids=tuple(obj.object_id for obj in context["objects"]),
            claim_ids=tuple(claim.object_id for claim in context.get("claims", ())),
            evidence_chain_ids=tuple(chain.object_id for chain in context.get("evidence_chains", ())),
            entitlement_level=context["entitlement_level"],
            conclusions=tuple(context.get("conclusions", ())),
            limitations=tuple(context.get("limitations", ())),
            recommendations=tuple(context.get("recommendations", ())),
            provenance=Provenance(
                engine_name=self.name,
                engine_version=self.version,
                parent_object_ids=tuple(obj.object_id for obj in context["objects"]),
            ),
        )
