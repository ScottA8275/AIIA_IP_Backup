from __future__ import annotations
from typing import Any, Mapping
from ..identity import new_id
from ..objects import (EntitlementLevel, OrganizationalAtlasRecord, Provenance,
    QualificationCheck, QualificationCheckState, QualificationDecision,
    QualificationDecisionRule, QualificationExplanation, QualificationOutcome,
    QualificationRecord, RepresentationProduct, ScientificEntitlement)

class ValidatedSolarQualificationEngine:
    name = "Validated Solar Transparent Qualification Engine"
    version = "2.4.0-alpha.1"

    def __init__(self, solar_engine: Any) -> None:
        self.solar_engine = solar_engine
        self._objects: tuple[Any, ...] = ()

    @staticmethod
    def _state(metric: Mapping[str, Any]) -> QualificationCheckState:
        state = str(metric.get("state") or "").lower()
        if state == "supported" or metric.get("supported") is True: return QualificationCheckState.PASS
        if state == "not_supported" or metric.get("supported") is False: return QualificationCheckState.FAIL
        if state == "invalid": return QualificationCheckState.INVALID
        return QualificationCheckState.NOT_EVALUATED

    def qualify(self, *, representation: RepresentationProduct, atlas: OrganizationalAtlasRecord | None) -> QualificationRecord:
        eq = self.solar_engine.equivalence_record
        checks: list[QualificationCheck] = [QualificationCheck(
            object_id=new_id("qualification-check"), check_id="scientific_equivalence",
            display_name="Scientific representation equivalence",
            state=QualificationCheckState.PASS if eq.passed else QualificationCheckState.FAIL,
            measured_value=eq.passed, threshold=True, direction="==", critical=True,
            evidence_count=len(eq.compared_metrics),
            rationale="The SII output matched the preserved source implementation." if eq.passed else "Scientific equivalence failed.",
            limitations=tuple(eq.discrepancies),
            provenance=Provenance(instrument_version=self.version, engine_name=self.name,
                engine_version=self.version, parent_object_ids=(representation.object_id, eq.object_id))) ]

        phase1 = self.solar_engine.phase1_result
        if phase1 is not None:
            for metric_id, metric in phase1.to_summary().get("metric_results", {}).items():
                state=self._state(metric)
                value=metric.get("value"); threshold=metric.get("threshold"); direction=metric.get("direction")
                display=str(metric.get("display_name") or metric_id)
                rationale=(f"{display} met the registered criterion: value={value!r}, criterion={direction} {threshold!r}."
                    if state is QualificationCheckState.PASS else
                    f"{display} did not establish support: value={value!r}, criterion={direction} {threshold!r}.")
                limits=tuple(str(x) for x in metric.get("limitations",[]) if x)
                if metric.get("failure_reason"): limits += (str(metric["failure_reason"]),)
                checks.append(QualificationCheck(
                    object_id=new_id("qualification-check"), check_id=str(metric_id), display_name=display,
                    state=state, measured_value=value, threshold=threshold,
                    direction=str(direction) if direction is not None else None,
                    critical=str(metric.get("severity") or "").lower() in {"critical","required","blocking"},
                    confidence=metric.get("confidence"), evidence_count=int(metric.get("n_evidence") or 0),
                    rationale=rationale, limitations=limits, recommendation=metric.get("recommendation"),
                    metadata={"effect_size":metric.get("effect_size"),"components":metric.get("components",{})},
                    provenance=Provenance(instrument_version=self.version,engine_name=self.name,
                        engine_version=self.version,parent_object_ids=(representation.object_id,))))

        passed=[c for c in checks if c.state is QualificationCheckState.PASS]
        blocking=[c for c in checks if c.state in {QualificationCheckState.FAIL,QualificationCheckState.INVALID}]
        critical=[c for c in checks if c.critical]
        critical_passed=all(c.state is QualificationCheckState.PASS for c in critical)
        if not eq.passed:
            outcome=QualificationOutcome.CONCERN; level=EntitlementLevel.NONE; rule=QualificationDecisionRule.LEGACY_PROTOCOL
        elif phase1 is None:
            outcome=QualificationOutcome.QUALIFIED_WITH_LIMITATIONS; level=EntitlementLevel.INTERNAL_DECISION_SUPPORT; rule=QualificationDecisionRule.EQUIVALENCE_ONLY
        else:
            status=str(phase1.to_summary().get("status") or "").lower()
            outcome=QualificationOutcome.CONCERN if status in {"concern","incomplete"} or blocking else QualificationOutcome.QUALIFIED_WITH_LIMITATIONS
            level=EntitlementLevel.EXPLORATORY if outcome is QualificationOutcome.CONCERN else EntitlementLevel.INTERNAL_DECISION_SUPPORT
            rule=QualificationDecisionRule.LEGACY_PROTOCOL

        decision=QualificationDecision(object_id=new_id("qualification-decision"),target_object_id=representation.object_id,
            profile_name="validated-solar-phase1-transparent-v2.3",outcome=outcome,rule=rule,
            check_ids=tuple(c.object_id for c in checks),checks_passed=len(passed),checks_total=len(checks),
            critical_checks_passed=critical_passed,blocking_check_ids=tuple(c.object_id for c in blocking),
            rationale=(f"Scientific equivalence {'passed' if eq.passed else 'failed'}.",
                f"{len(passed)} of {len(checks)} checks passed.",f"Critical checks passed: {critical_passed}.",
                "The preserved Phase 1 review decision remains authoritative." if phase1 else "Phase 1 was not executed."),
            provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,
                parent_object_ids=tuple(c.object_id for c in checks)))
        supporting=tuple(c.rationale for c in checks if c.state is QualificationCheckState.PASS)
        limiting=tuple(c.rationale for c in checks if c.state is not QualificationCheckState.PASS)
        actions=tuple(c.recommendation or f"Review and revise evidence for {c.display_name}." for c in checks if c.state is not QualificationCheckState.PASS)
        explanation=QualificationExplanation(object_id=new_id("qualification-explanation"),decision_id=decision.object_id,
            summary="Computational equivalence passed, but blocking qualification evidence limits scientific entitlement." if outcome is QualificationOutcome.CONCERN else "The representation is qualified within explicit limitations.",
            supporting_factors=supporting,limiting_factors=limiting,required_actions=actions,
            entitlement_explanation=(f"Permitted use: {level.value}.","Equivalence alone does not establish scientific qualification.","Stronger entitlement requires blocking checks to pass."),
            provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=(decision.object_id,)))
        entitlement=ScientificEntitlement(level=level,
            permitted_claims=("Describe the observed Solar representation.","Use the result to revise and retest the representation.","Report the decision with transparent evidence."),
            prohibited_claims=("Claim causality.","Claim universal structural laws.","Claim publication-grade validation while blocking checks remain.","Claim regulatory fitness."),
            rationale=explanation.entitlement_explanation)
        limitations=tuple(dict.fromkeys(x for c in checks for x in c.limitations)) + (("Phase 1 qualification only." if phase1 else "Full Phase 1 qualification was not executed."),)
        record=QualificationRecord(object_id=new_id("qualification"),target_object_id=representation.object_id,
            profile_name="validated-solar-phase1-transparent-v2.3",outcome=outcome,
            metrics={"equivalence_passed":eq.passed,"phase1_executed":phase1 is not None,"checks_passed":len(passed),"checks_total":len(checks),"critical_checks_passed":critical_passed},
            limitations=limitations,entitlement=entitlement,check_ids=tuple(c.object_id for c in checks),decision_id=decision.object_id,explanation_id=explanation.object_id,
            provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=(representation.object_id,decision.object_id,explanation.object_id)))
        self._objects=tuple(checks)+(decision,explanation)
        return record

    @property
    def qualification_objects(self) -> tuple[Any, ...]: return self._objects
