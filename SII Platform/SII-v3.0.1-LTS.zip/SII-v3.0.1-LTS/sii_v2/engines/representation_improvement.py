from __future__ import annotations
from typing import Any, Iterable, Mapping
from ..identity import new_id
from ..objects import (ImprovementActionType, ImprovementHypothesis, ImprovementStatus,
    ImprovementTrial, Provenance, QualificationCheck, QualificationCheckState,
    QualificationRecord, RepresentationCandidate, RepresentationIntervention,
    RepresentationProduct, StructuralDiagnosis)

class RepresentationImprovementEngine:
    name="Closed-Loop Representation Improvement Engine"
    version="2.4.0-alpha.1"

    def diagnose(self, *, qualification: QualificationRecord, checks: Iterable[QualificationCheck]) -> tuple[StructuralDiagnosis,...]:
        failed=[c for c in checks if c.state in {QualificationCheckState.FAIL,QualificationCheckState.INVALID,QualificationCheckState.NOT_EVALUATED}]
        by_id={c.check_id:c for c in failed}; result=[]
        seed=[c for c in failed if c.check_id in {"seed_median_aligned_ari","seed_minor_basin_stability"}]
        if seed:
            result.append(StructuralDiagnosis(object_id=new_id("structural-diagnosis"),qualification_record_id=qualification.object_id,
                failed_check_ids=tuple(c.object_id for c in seed),diagnosis_code="seed_sensitive_basin_boundaries",
                summary="Minor basin identity is not sufficiently stable across random seeds.",
                affected_regions=("minor basins","basin boundaries","low-occupancy neighborhoods"),
                causal_hypotheses=("Minor regimes are under-supported relative to the dominant regime.","Initialization sensitivity moves boundary observations between neighboring basins.","The atlas may over-partition weak structure."),
                confidence=0.82,evidence={c.check_id:c.measured_value for c in seed},
                provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=(qualification.object_id,*tuple(c.object_id for c in seed)))))
        occ=by_id.get("maximum_basin_occupancy")
        if occ:
            result.append(StructuralDiagnosis(object_id=new_id("structural-diagnosis"),qualification_record_id=qualification.object_id,
                failed_check_ids=(occ.object_id,),diagnosis_code="dominant_basin_overconcentration",
                summary="One basin absorbs too much of the representation and may conceal internal regimes.",
                affected_regions=("dominant basin","rare basins","transition boundary"),
                causal_hypotheses=("The dominant basin contains unresolved substructure.","The atlas is collapsing heterogeneous states into one basin.","Rare basins may be artifacts of an oversized dominant basin."),
                confidence=0.90,evidence={"maximum_basin_occupancy":occ.measured_value},
                provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=(qualification.object_id,occ.object_id))))
        return tuple(result)

    def hypothesize(self, *, diagnoses: Iterable[StructuralDiagnosis]) -> tuple[ImprovementHypothesis,...]:
        out=[]
        for d in diagnoses:
            if d.diagnosis_code=="dominant_basin_overconcentration":
                out.append(ImprovementHypothesis(object_id=new_id("improvement-hypothesis"),diagnosis_id=d.object_id,
                    hypothesis_code="hierarchical_split_of_dominant_basin",
                    statement="A local hierarchical split of the dominant basin will reduce occupancy concentration without destabilizing the global atlas.",
                    predicted_effects={"maximum_basin_occupancy":{"direction":"decrease","target":"<=0.90"},"seed_median_aligned_ari":{"direction":"increase"},"bootstrap_profile_similarity":{"direction":"maintain","floor":0.65}},
                    target_check_ids=("maximum_basin_occupancy","seed_median_aligned_ari"),
                    falsification_criteria=("Maximum occupancy remains above 0.90.","Bootstrap profile similarity falls below 0.65.","Minor basin stability declines."),priority=1,
                    provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=(d.object_id,))))
            elif d.diagnosis_code=="seed_sensitive_basin_boundaries":
                out.append(ImprovementHypothesis(object_id=new_id("improvement-hypothesis"),diagnosis_id=d.object_id,
                    hypothesis_code="seed_consensus_initialization",
                    statement="Consensus initialization across aligned seeds will improve basin identity stability while preserving parameter similarity.",
                    predicted_effects={"seed_median_aligned_ari":{"direction":"increase","target":">=0.50"},"seed_minor_basin_stability":{"direction":"increase","target":">=0.45"}},
                    target_check_ids=("seed_median_aligned_ari","seed_minor_basin_stability"),
                    falsification_criteria=("Median ARI remains below 0.50.","Minor basin stability remains below 0.45.","Parameter similarity falls below 0.65."),priority=2,
                    provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=(d.object_id,))))
        return tuple(sorted(out,key=lambda x:x.priority))

    def plan_interventions(self, *, hypotheses: Iterable[ImprovementHypothesis], representation: RepresentationProduct):
        result=[]
        for h in hypotheses:
            if h.hypothesis_code=="hierarchical_split_of_dominant_basin":
                action=ImprovementActionType.SPLIT_DOMINANT_BASIN
                changes={"strategy":"hierarchical_local_split","target":"largest_occupancy_basin","local_basin_count_candidates":[2,3,4],"preserve_global_coordinates":True,"selection_rule":"best qualification improvement with no critical regression"}
            else:
                action=ImprovementActionType.INCREASE_SEED_ROBUSTNESS
                changes={"strategy":"consensus_seed_initialization","seed_count":10,"consensus_method":"aligned_medoid","boundary_assignment":"majority_vote"}
            intervention=RepresentationIntervention(object_id=new_id("representation-intervention"),hypothesis_id=h.object_id,action_type=action,
                parameter_changes=changes,rationale=h.statement,safeguards=("Preserve the baseline representation.","Use a new candidate configuration ID.","Re-run full qualification.","Reject any critical regression."),status=ImprovementStatus.READY_FOR_TRIAL,
                provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=(h.object_id,representation.object_id)))
            candidate=RepresentationCandidate(object_id=new_id("representation-candidate"),parent_representation_id=representation.object_id,intervention_id=intervention.object_id,
                candidate_configuration_id=f"{representation.configuration_id}__{h.hypothesis_code}",expected_improvements=h.predicted_effects,status=ImprovementStatus.READY_FOR_TRIAL,
                provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=(representation.object_id,intervention.object_id)))
            result.append((intervention,candidate))
        return tuple(result)

    def compare(self, *, baseline_qualification_id:str,candidate_representation_id:str,candidate_qualification_id:str|None,target_check_ids:tuple[str,...],baseline_metrics:Mapping[str,Any],candidate_metrics:Mapping[str,Any])->ImprovementTrial:
        deltas={}; improved=degraded=0
        for key in set(baseline_metrics)&set(candidate_metrics):
            before,after=baseline_metrics[key],candidate_metrics[key]
            if isinstance(before,(int,float)) and isinstance(after,(int,float)):
                deltas[key]=after-before
                good=after<before if key=="maximum_basin_occupancy" else after>before
                bad=after>before if key=="maximum_basin_occupancy" else after<before
                improved+=int(good); degraded+=int(bad)
        if improved and not degraded: status=ImprovementStatus.IMPROVED; conclusion="The candidate improved all comparable target metrics."
        elif degraded and not improved: status=ImprovementStatus.DEGRADED; conclusion="The candidate degraded the target metrics."
        else: status=ImprovementStatus.INCONCLUSIVE; conclusion="The candidate produced mixed or insufficient changes."
        return ImprovementTrial(object_id=new_id("improvement-trial"),baseline_qualification_id=baseline_qualification_id,candidate_representation_id=candidate_representation_id,candidate_qualification_id=candidate_qualification_id,target_check_ids=target_check_ids,baseline_metrics=dict(baseline_metrics),candidate_metrics=dict(candidate_metrics),deltas=deltas,status=status,conclusion=conclusion,
            provenance=Provenance(instrument_version=self.version,engine_name=self.name,engine_version=self.version,parent_object_ids=tuple(x for x in (baseline_qualification_id,candidate_representation_id,candidate_qualification_id) if x)))
