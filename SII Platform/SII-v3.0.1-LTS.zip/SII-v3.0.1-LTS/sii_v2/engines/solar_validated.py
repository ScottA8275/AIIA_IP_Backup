
from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import asdict, is_dataclass, replace
from pathlib import Path
from typing import Any, Mapping

import numpy as np

from ..identity import new_id
from ..objects import (
    DatasetRecord,
    EquivalenceRecord,
    ExperimentDefinition,
    OrganizationalAtlasRecord,
    Provenance,
    RepresentationProduct,
)


class ValidatedSolarIntegrationError(RuntimeError):
    pass


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {k: _jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if hasattr(value, "value"):
        return value.value
    return value


def _fingerprint(payload: Mapping[str, Any]) -> str:
    encoded = json.dumps(_jsonable(payload), sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


class ValidatedSolarRepresentationEngine:
    """
    SII v2.2 adapter over the preserved Solar M1D/RIX v1 implementation.

    The adapter does not alter the legacy construction or Phase 1 qualification
    mathematics. It translates validated outputs into the SII Scientific Object
    Model and records equivalence evidence.
    """

    name = "Validated Solar M1D/RIX Representation Engine"
    version = "2.5.0-alpha.1"
    source_engine_name = "Solar M1D RIX Representation Engine"
    source_engine_version = "1.0"

    def __init__(
        self,
        *,
        project_root: Path,
        dataset_path: Path,
        legacy_script_path: Path | None = None,
        output_dir: Path | None = None,
        run_full_qualification: bool = True,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.dataset_path = Path(dataset_path).expanduser().resolve()
        self.legacy_dir = self.project_root / "legacy_solar_v1"
        self.legacy_script_path = (
            Path(legacy_script_path).expanduser().resolve()
            if legacy_script_path is not None
            else self.legacy_dir / "run_m1d_solar_atlas_validation.py"
        )
        self.output_dir = Path(output_dir or self.project_root / "sii_v2_2_output" / "legacy_phase1").resolve()
        self.run_full_qualification = run_full_qualification
        self._loaded = False
        self._dataset = None
        self._protocol = None
        self._adapter = None
        self._atlas = None
        self._baseline_run = None
        self._phase1 = None
        self._equivalence = None

    def _load_legacy(self) -> None:
        if self._loaded:
            return
        if not self.legacy_dir.exists():
            raise ValidatedSolarIntegrationError(f"Legacy Solar directory not found: {self.legacy_dir}")
        if not self.dataset_path.exists():
            raise ValidatedSolarIntegrationError(f"Solar dataset not found: {self.dataset_path}")

        sys.path.insert(0, str(self.legacy_dir))
        try:
            from qualification_config import ACTIVE_PROTOCOL
            from solar_m1d_adapter import SolarM1DAdapter, initialize_solar_atlas
            self._run_phase1 = __import__("phase1_representation").run_phase1_representation

            # QualificationProtocolConfig and PathConfig are frozen dataclasses.
            # Preserve immutability by constructing a new protocol with only the
            # registered input path replaced.
            protocol = replace(
                ACTIVE_PROTOCOL,
                paths=replace(
                    ACTIVE_PROTOCOL.paths,
                    input_file=self.dataset_path,
                ),
            )
            protocol.validate()

            adapter = SolarM1DAdapter(
                protocol=protocol,
                legacy_script_path=self.legacy_script_path,
            )
            dataset = adapter.load_data(self.dataset_path)
            atlas = initialize_solar_atlas(protocol=protocol, dataset=dataset)
        except Exception as exc:
            raise ValidatedSolarIntegrationError(f"Could not initialize validated Solar integration: {exc}") from exc
        finally:
            if sys.path and sys.path[0] == str(self.legacy_dir):
                sys.path.pop(0)

        self._protocol = protocol
        self._adapter = adapter
        self._dataset = dataset
        self._atlas = atlas
        self._loaded = True

    @staticmethod
    def _normalized_baseline(run: Any) -> dict[str, Any]:
        assignments = np.asarray(run.assignments, dtype=int)
        microstates = np.asarray(run.microstate_assignments, dtype=int)
        occupancy = np.asarray(run.basin_occupancy, dtype=float)
        profiles = np.asarray(run.basin_profiles, dtype=float)
        return {
            "config_id": str(run.config_id),
            "seed": int(run.seed),
            "n_states": int(assignments.size),
            "n_basins": int(np.unique(assignments).size),
            "n_microstates": int(np.unique(microstates).size),
            "basin_occupancy": np.round(occupancy, 12).tolist(),
            "basin_profiles": np.round(profiles, 12).tolist(),
            "assignment_sha256": hashlib.sha256(assignments.tobytes()).hexdigest(),
            "microstate_assignment_sha256": hashlib.sha256(microstates.tobytes()).hexdigest(),
            "run_id": str(run.run_id),
            "metric_values": _jsonable(dict(getattr(run, "metric_values", {}))),
        }

    def _build_once(self, seed: int) -> Any:
        self._load_legacy()
        return self._adapter(
            self._dataset.data,
            self._protocol.baseline_representation,
            seed,
            "sii-v2.3-baseline",
        )

    def _validate_equivalence(self, source_run: Any, target_payload: Mapping[str, Any]) -> EquivalenceRecord:
        source = self._normalized_baseline(source_run)
        target = dict(target_payload["equivalence_contract"])
        discrepancies: list[str] = []
        exact_keys = (
            "config_id", "seed", "n_states", "n_basins", "n_microstates",
            "assignment_sha256", "microstate_assignment_sha256",
        )
        for key in exact_keys:
            if source.get(key) != target.get(key):
                discrepancies.append(f"{key}: source={source.get(key)!r}, target={target.get(key)!r}")

        for key in ("basin_occupancy", "basin_profiles"):
            a = np.asarray(source[key], dtype=float)
            b = np.asarray(target[key], dtype=float)
            if a.shape != b.shape or not np.allclose(a, b, rtol=0.0, atol=1e-12, equal_nan=True):
                discrepancies.append(f"{key}: values differ beyond absolute tolerance 1e-12")

        source_fp = _fingerprint(source)
        target_fp = _fingerprint(target)
        passed = not discrepancies and source_fp == target_fp
        if source_fp != target_fp and not discrepancies:
            discrepancies.append("Normalized result fingerprints differ.")

        return EquivalenceRecord(
            object_id=new_id("equivalence"),
            source_engine_name=self.source_engine_name,
            source_engine_version=self.source_engine_version,
            target_engine_name=self.name,
            target_engine_version=self.version,
            comparison_profile="solar-m1d-baseline-exact-v1",
            passed=passed,
            compared_metrics={
                "exact_fields": exact_keys,
                "numeric_fields": ("basin_occupancy", "basin_profiles"),
                "source_summary": source,
                "target_summary": target,
            },
            tolerances={"absolute": 1e-12, "relative": 0.0},
            discrepancies=tuple(discrepancies),
            source_result_fingerprint=source_fp,
            target_result_fingerprint=target_fp,
            provenance=Provenance(
                instrument_version=self.version,
                engine_name="SII Scientific Equivalence Gate",
                engine_version=self.version,
                source_references=(str(self.legacy_script_path), str(self.dataset_path)),
            ),
        )

    def represent(
        self,
        *,
        dataset: DatasetRecord,
        experiment: ExperimentDefinition,
        seed: int,
    ) -> RepresentationProduct:
        self._load_legacy()
        if Path(dataset.uri).expanduser().resolve() != self.dataset_path:
            raise ValidatedSolarIntegrationError(
                "DatasetRecord URI does not match the dataset bound to this validated engine."
            )

        baseline = self._build_once(seed)
        self._baseline_run = baseline
        contract = self._normalized_baseline(baseline)

        phase1_summary: dict[str, Any] = {}
        if self.run_full_qualification:
            self.output_dir.mkdir(parents=True, exist_ok=True)
            self._phase1 = self._run_phase1(
                atlas=self._atlas,
                data=self._dataset.data,
                builder=self._adapter,
                protocol=self._protocol,
                output_dir=self.output_dir,
            )
            phase1_summary = _jsonable(self._phase1.to_summary())

        payload = {
            "representation_method": self._protocol.identity.representation_method,
            "representation_version": self._protocol.identity.representation_version,
            "baseline_configuration": _jsonable(self._protocol.baseline_representation),
            "equivalence_contract": contract,
            "phase1_qualification_summary": phase1_summary,
            "legacy_metadata": _jsonable(dict(baseline.metadata)),
        }
        self._equivalence = self._validate_equivalence(baseline, payload)
        if not self._equivalence.passed:
            raise ValidatedSolarIntegrationError(
                "Scientific equivalence gate failed: " + "; ".join(self._equivalence.discrepancies)
            )

        return RepresentationProduct(
            object_id=new_id("representation"),
            experiment_code=experiment.code,
            configuration_id=str(baseline.config_id),
            observation_count=int(len(self._dataset.data)),
            feature_names=tuple(self._dataset.feature_names),
            payload=payload,
            diagnostics={
                "source_engine": f"{self.source_engine_name} {self.source_engine_version}",
                "equivalence_passed": True,
                "equivalence_record_id": self._equivalence.object_id,
                "phase1_executed": bool(self.run_full_qualification),
            },
            provenance=Provenance(
                instrument_version=self.version,
                engine_name=self.name,
                engine_version=self.version,
                configuration={"seed": seed, "run_full_qualification": self.run_full_qualification},
                source_references=(str(self.dataset_path), str(self.legacy_script_path)),
            ),
        )

    def representation_arrays(self, *, representation: RepresentationProduct) -> dict[str, Any]:
        if self._baseline_run is None or self._baseline_run.representation is None:
            raise ValidatedSolarIntegrationError("represent() must execute before representation_arrays().")
        artifacts = self._baseline_run.representation
        return {
            "basin_assignments": np.asarray(self._baseline_run.assignments, dtype=np.int64),
            "microstate_assignments": np.asarray(self._baseline_run.microstate_assignments, dtype=np.int64),
            "basin_profiles": np.asarray(self._baseline_run.basin_profiles, dtype=float),
            "basin_occupancy": np.asarray(self._baseline_run.basin_occupancy, dtype=float),
            "embedded_states": np.asarray(artifacts.embedded_states, dtype=float),
            "scaled_states": np.asarray(artifacts.scaled_states, dtype=float),
            "coordinate_matrix": np.asarray(artifacts.coordinate_matrix, dtype=float),
            "microstate_to_basin": np.asarray(artifacts.microstate_to_basin, dtype=np.int64),
        }

    def atlas(self, *, representation: RepresentationProduct) -> OrganizationalAtlasRecord:
        if self._baseline_run is None:
            raise ValidatedSolarIntegrationError("represent() must execute before atlas().")
        assignments = np.asarray(self._baseline_run.assignments, dtype=int)
        basin_ids, counts = np.unique(assignments, return_counts=True)
        total = float(counts.sum())
        occupancy = {str(int(b)): float(c / total) for b, c in zip(basin_ids, counts)}
        return OrganizationalAtlasRecord(
            object_id=new_id("atlas"),
            representation_id=representation.object_id,
            basin_count=int(len(basin_ids)),
            neighborhood_count=int(np.unique(self._baseline_run.microstate_assignments).size),
            occupancy=occupancy,
            topology_summary={
                "source": "validated Solar M1D/RIX baseline representation",
                "configuration_id": representation.configuration_id,
                "phase1_qualification_available": self._phase1 is not None,
            },
            provenance=Provenance(
                instrument_version=self.version,
                engine_name=self.name,
                engine_version=self.version,
                parent_object_ids=(representation.object_id,),
            ),
        )

    @property
    def equivalence_record(self) -> EquivalenceRecord:
        if self._equivalence is None:
            raise ValidatedSolarIntegrationError("No equivalence record exists before represent().")
        return self._equivalence

    @property
    def phase1_result(self) -> Any:
        return self._phase1
