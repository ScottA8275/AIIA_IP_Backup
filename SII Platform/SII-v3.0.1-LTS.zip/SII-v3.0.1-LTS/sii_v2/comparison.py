from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping
import json
import math


SUPPORTED_STATES = {"supported", "pass", "passed"}
BLOCKING_STATES = {"not_supported", "fail", "failed", "invalid"}


@dataclass(frozen=True)
class CandidateComparison:
    candidate_id: str
    request_id: str
    split_count: int
    status: str
    confidence: float | None
    metrics: dict[str, dict[str, Any]]
    improved_count: int
    degraded_count: int
    unchanged_count: int
    newly_supported_count: int
    newly_blocking_count: int
    blocking_metric_ids: tuple[str, ...]
    normalized_margin_score: float


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)) and math.isfinite(float(value)):
        return float(value)
    return None


def _metric_direction(metric: Mapping[str, Any]) -> str:
    return str(metric.get("direction") or "").strip().lower()


def _better(before: float, after: float, direction: str, tolerance: float = 1e-12) -> str:
    delta = after - before
    if abs(delta) <= tolerance:
        return "unchanged"
    if direction in {"less", "less_equal", "<", "<=", "decrease"}:
        return "improved" if delta < 0 else "degraded"
    return "improved" if delta > 0 else "degraded"


def _normalized_margin(value: float | None, threshold: float | None, direction: str) -> float | None:
    if value is None or threshold is None:
        return None
    scale = max(abs(threshold), 1e-12)
    if direction in {"less", "less_equal", "<", "<=", "decrease"}:
        return (threshold - value) / scale
    return (value - threshold) / scale


def compare_candidate(result: Mapping[str, Any], *, split_count: int) -> CandidateComparison:
    baseline = result.get("parent_phase1_summary", {})
    candidate = result.get("candidate_phase1_summary", {})
    baseline_metrics = baseline.get("metric_results", {}) or {}
    candidate_metrics = candidate.get("metric_results", {}) or {}

    metric_comparisons: dict[str, dict[str, Any]] = {}
    improved = degraded = unchanged = newly_supported = newly_blocking = 0
    margins: list[float] = []
    blocking: list[str] = []

    for metric_id in sorted(set(baseline_metrics) | set(candidate_metrics)):
        before_metric = baseline_metrics.get(metric_id, {}) or {}
        after_metric = candidate_metrics.get(metric_id, {}) or {}
        before = _number(before_metric.get("value"))
        after = _number(after_metric.get("value"))
        threshold = _number(after_metric.get("threshold", before_metric.get("threshold")))
        direction = _metric_direction(after_metric) or _metric_direction(before_metric)
        before_state = str(before_metric.get("state") or "not_evaluated").lower()
        after_state = str(after_metric.get("state") or "not_evaluated").lower()

        change = "not_comparable"
        delta = None
        if before is not None and after is not None:
            delta = after - before
            change = _better(before, after, direction)
            if change == "improved": improved += 1
            elif change == "degraded": degraded += 1
            else: unchanged += 1

        became_supported = before_state not in SUPPORTED_STATES and after_state in SUPPORTED_STATES
        became_blocking = before_state not in BLOCKING_STATES and after_state in BLOCKING_STATES
        newly_supported += int(became_supported)
        newly_blocking += int(became_blocking)
        if after_state in BLOCKING_STATES:
            blocking.append(metric_id)

        margin = _normalized_margin(after, threshold, direction)
        if margin is not None:
            margins.append(margin)

        metric_comparisons[metric_id] = {
            "baseline_value": before,
            "candidate_value": after,
            "delta": delta,
            "direction": direction,
            "threshold": threshold,
            "baseline_state": before_state,
            "candidate_state": after_state,
            "change": change,
            "newly_supported": became_supported,
            "newly_blocking": became_blocking,
            "normalized_threshold_margin": margin,
        }

    return CandidateComparison(
        candidate_id=str(result.get("candidate_product_id") or ""),
        request_id=str(result.get("request_id") or ""),
        split_count=int(split_count),
        status=str(result.get("status") or "unknown"),
        confidence=_number(candidate.get("confidence")),
        metrics=metric_comparisons,
        improved_count=improved,
        degraded_count=degraded,
        unchanged_count=unchanged,
        newly_supported_count=newly_supported,
        newly_blocking_count=newly_blocking,
        blocking_metric_ids=tuple(blocking),
        normalized_margin_score=sum(margins) / len(margins) if margins else float("-inf"),
    )


def _scientifically_eligible(candidate: CandidateComparison) -> bool:
    return (
        candidate.status.lower() in SUPPORTED_STATES
        and candidate.newly_blocking_count == 0
        and not candidate.blocking_metric_ids
    )


def _dominates(left: CandidateComparison, right: CandidateComparison) -> bool:
    comparable = []
    strictly_better = False
    for metric_id in set(left.metrics) & set(right.metrics):
        l = left.metrics[metric_id].get("candidate_value")
        r = right.metrics[metric_id].get("candidate_value")
        direction = str(left.metrics[metric_id].get("direction") or "")
        if l is None or r is None:
            continue
        comparable.append(metric_id)
        relation = _better(float(r), float(l), direction)
        if relation == "degraded":
            return False
        if relation == "improved":
            strictly_better = True
    return bool(comparable) and strictly_better


def build_comparative_evaluation(results: Iterable[tuple[int, Mapping[str, Any]]]) -> dict[str, Any]:
    comparisons = [compare_candidate(result, split_count=split) for split, result in results]
    eligible = [candidate for candidate in comparisons if _scientifically_eligible(candidate)]

    pareto = [
        candidate for candidate in eligible
        if not any(_dominates(other, candidate) for other in eligible if other is not candidate)
    ]

    ranked = sorted(
        eligible,
        key=lambda candidate: (
            candidate.newly_blocking_count,
            len(candidate.blocking_metric_ids),
            -candidate.newly_supported_count,
            -candidate.normalized_margin_score,
            -(candidate.confidence if candidate.confidence is not None else float("-inf")),
            candidate.split_count,
        ),
    )

    recommended = ranked[0] if ranked else None
    recommendation_basis = (
        "Highest equal-weight mean threshold margin among scientifically supported candidates, "
        "after excluding candidates with blocking metrics or newly introduced blocking evidence. "
        "The ranking is comparative evidence, not a new entitlement decision."
    )

    payload = {
        "schema": "aiia.sii.comparative-qualification",
        "schema_version": "1.0",
        "instrument_version": "2.8.0",
        "evaluation_method": {
            "eligibility": "supported status with no candidate blocking metrics and no newly blocking metrics",
            "ranking": "equal-weight mean normalized threshold margin",
            "normalized_margin": "(value-threshold)/abs(threshold) for greater-is-better; reversed for less-is-better",
            "pareto_frontier": "candidate is retained unless another eligible candidate is no worse on every comparable metric and better on at least one",
            "governance": "Comparative ranking does not replace qualification or expand scientific entitlement.",
        },
        "candidates": [
            {
                "candidate_id": candidate.candidate_id,
                "request_id": candidate.request_id,
                "split_count": candidate.split_count,
                "status": candidate.status,
                "confidence": candidate.confidence,
                "improved_metrics": candidate.improved_count,
                "degraded_metrics": candidate.degraded_count,
                "unchanged_metrics": candidate.unchanged_count,
                "newly_supported_metrics": candidate.newly_supported_count,
                "newly_blocking_metrics": candidate.newly_blocking_count,
                "blocking_metric_ids": list(candidate.blocking_metric_ids),
                "normalized_margin_score": candidate.normalized_margin_score,
                "scientifically_eligible": _scientifically_eligible(candidate),
                "pareto_frontier": candidate in pareto,
                "metrics": candidate.metrics,
            }
            for candidate in comparisons
        ],
        "ranking": [candidate.candidate_id for candidate in ranked],
        "pareto_frontier": [candidate.candidate_id for candidate in pareto],
        "recommended_candidate_id": recommended.candidate_id if recommended else None,
        "recommended_split_count": recommended.split_count if recommended else None,
        "recommendation_basis": recommendation_basis if recommended else "No candidate satisfied comparative eligibility requirements.",
    }
    return payload


def write_comparative_reports(payload: Mapping[str, Any], output_directory: Path) -> None:
    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    (output_directory / "comparative_qualification.json").write_text(
        json.dumps(payload, indent=2, default=str), encoding="utf-8"
    )

    by_id = {item["candidate_id"]: item for item in payload.get("candidates", [])}
    lines = [
        "STRUCTURAL INTELLIGENCE INSTRUMENT v2.8",
        "COMPARATIVE SCIENTIFIC EVALUATION",
        "=" * 68,
        "",
        "SCIENTIFIC GOVERNANCE",
        "This report compares independently qualified candidates. It does not replace",
        "qualification, alter candidate packages, or expand scientific entitlement.",
        "",
        "CANDIDATE COMPARISON",
    ]
    for rank, candidate_id in enumerate(payload.get("ranking", []), start=1):
        candidate = by_id[candidate_id]
        lines.extend([
            f"{rank}. Split {candidate['split_count']} | {candidate_id}",
            f"   Status: {candidate['status']}",
            f"   Confidence: {candidate['confidence']}",
            f"   Improved/degraded vs parent: {candidate['improved_metrics']}/{candidate['degraded_metrics']}",
            f"   Newly supported/newly blocking: {candidate['newly_supported_metrics']}/{candidate['newly_blocking_metrics']}",
            f"   Mean normalized threshold margin: {candidate['normalized_margin_score']:.6f}",
            f"   Pareto frontier: {candidate['pareto_frontier']}",
        ])
    lines.extend([
        "",
        "RECOMMENDATION",
        f"Candidate: {payload.get('recommended_candidate_id')}",
        f"Split count: {payload.get('recommended_split_count')}",
        f"Basis: {payload.get('recommendation_basis')}",
        "",
        "METRIC DETAIL",
    ])
    recommended = by_id.get(payload.get("recommended_candidate_id"))
    if recommended:
        for metric_id, metric in recommended.get("metrics", {}).items():
            lines.append(
                f"- {metric_id}: parent={metric.get('baseline_value')} candidate={metric.get('candidate_value')} "
                f"delta={metric.get('delta')} change={metric.get('change')} state={metric.get('candidate_state')}"
            )
    (output_directory / "comparative_qualification.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
