from __future__ import annotations

from dataclasses import replace
from typing import Callable

from .contracts import DiscoveryEngine, PublicationEngine, QualificationEngine, RepresentationEngine
from .identity import new_id, utc_now_iso
from .objects import (
    DatasetRecord,
    EvidenceChain,
    EvidenceLink,
    ExperimentDefinition,
    InstrumentSession,
    Investigation,
    InvestigationStatus,
    ScientificClaim,
    ScientificQuestion,
    ScientificRecord,
)
from .repository import FileStructuralKnowledgeRepository
from .representation_package import RepresentationProductStore

ProgressCallback = Callable[[str, str], None]


class StructuralIntelligenceInstrument:
    """Executable, capability-oriented SII investigation orchestrator."""

    name = "Structural Intelligence Instrument"
    version = "2.6.0-alpha.1"

    def __init__(
        self,
        *,
        repository: FileStructuralKnowledgeRepository,
        representation_engine: RepresentationEngine,
        qualification_engine: QualificationEngine,
        publication_engine: PublicationEngine,
        discovery_engine: DiscoveryEngine | None = None,
        progress: ProgressCallback | None = None,
        representation_product_store: RepresentationProductStore | None = None,
    ) -> None:
        self.repository = repository
        self.representation_engine = representation_engine
        self.qualification_engine = qualification_engine
        self.discovery_engine = discovery_engine
        self.publication_engine = publication_engine
        self.progress = progress or (lambda _stage, _message: None)
        self.representation_product_store = representation_product_store or RepresentationProductStore(
            repository.root / "representation_products"
        )

    def _emit(self, stage: str, message: str) -> None:
        self.progress(stage, message)

    def investigate(
        self,
        *,
        question: ScientificQuestion,
        investigation: Investigation,
        experiment: ExperimentDefinition,
        dataset: DatasetRecord,
        run_name: str,
        random_seed: int = 42,
    ) -> ScientificRecord:
        self._validate_plan(question, investigation, experiment)
        running_investigation = replace(investigation, status=InvestigationStatus.RUNNING)
        session = InstrumentSession(
            object_id=new_id("session"),
            run_name=run_name,
            investigation_id=investigation.object_id,
            random_seed=random_seed,
        )
        self.repository.register_many((question, running_investigation, experiment, dataset, session))
        self._emit("observe", f"Registered question, investigation, experiment, and dataset {dataset.object_id}.")

        representation = self.representation_engine.represent(dataset=dataset, experiment=experiment, seed=random_seed)
        arrays = self.representation_engine.representation_arrays(representation=representation)
        representation = self.representation_product_store.persist(
            representation=representation,
            arrays=arrays,
            dataset=dataset,
            experiment=experiment,
            instrument_name=self.name,
            instrument_version=self.version,
        )
        self.repository.register(representation)
        self._emit(
            "represent",
            f"Persisted Representation Product {representation.object_id} at {representation.package_uri}.",
        )

        equivalence = getattr(self.representation_engine, "equivalence_record", None)
        if equivalence is not None:
            self.repository.register(equivalence)
            status = "passed" if equivalence.passed else "failed"
            self._emit("equivalence", f"Scientific equivalence gate {status}: {equivalence.object_id}.")

        atlas = self.representation_engine.atlas(representation=representation)
        if atlas is not None:
            self.repository.register(atlas)
            self._emit("organize", f"Created Organizational Atlas {atlas.object_id}.")

        qualification = self.qualification_engine.qualify(representation=representation, atlas=atlas)
        qualification_objects = tuple(getattr(self.qualification_engine, "qualification_objects", ()))
        self.repository.register_many(qualification_objects)
        self.repository.register(qualification)
        self._emit("qualify", f"Qualification outcome: {qualification.outcome.value}; entitlement: {qualification.entitlement.level.value}; transparent checks: {len(qualification.check_ids)}.")

        discoveries = ()
        if self.discovery_engine is not None and "discover" in investigation.enabled_capabilities:
            discoveries = self.discovery_engine.discover(
                representation=representation,
                atlas=atlas,
                qualification=qualification,
            )
            self.repository.register_many(discoveries)
            self._emit("discover", f"Created {len(discoveries)} Discovery Object(s).")

        claim = ScientificClaim(
            object_id=new_id("claim"),
            statement=(
                f"The {investigation.name} representation was evaluated as "
                f"{qualification.outcome.value} under profile {qualification.profile_name}."
            ),
            claim_type="qualification_summary",
            entitlement_required=qualification.entitlement.level,
            supporting_object_ids=(representation.object_id, qualification.object_id),
        )
        self.repository.register(claim)

        links = [
            EvidenceLink(source_object_id=question.object_id, target_object_id=dataset.object_id, relationship="investigated_through", rationale="The dataset operationalizes the registered scientific question."),
            EvidenceLink(source_object_id=dataset.object_id, target_object_id=representation.object_id, relationship="represented_as", rationale="The Representation Product was constructed from the registered observations."),
            EvidenceLink(source_object_id=representation.object_id, target_object_id=qualification.object_id, relationship="qualified_by", rationale="The Qualification Record evaluates the Representation Product."),
            EvidenceLink(source_object_id=qualification.object_id, target_object_id=claim.object_id, relationship="entitles", rationale="The qualification outcome bounds and supports the stated claim."),
        ]
        chain = EvidenceChain(object_id=new_id("evidence-chain"), claim_id=claim.object_id, links=tuple(links))
        chain.validate()
        self.repository.register(chain)
        self._emit("evidence", f"Validated Evidence Chain {chain.object_id}.")

        scientific_objects = tuple(
            value for value in (question, running_investigation, experiment, dataset, representation, atlas, *qualification_objects, qualification, *discoveries)
            if value is not None
        )
        record = self.publication_engine.publish(
            context={
                "session": session,
                "question": question,
                "investigation": running_investigation,
                "experiment": experiment,
                "objects": scientific_objects,
                "claims": (claim,),
                "evidence_chains": (chain,),
                "entitlement_level": qualification.entitlement.level,
                "conclusions": (claim.statement,),
                "limitations": qualification.limitations,
                "recommendations": tuple(
                    str(discovery.findings["recommendation"])
                    for discovery in discoveries
                    if discovery.findings.get("recommendation")
                ),
            }
        )
        self.repository.register(record)

        completed_session = replace(
            session,
            object_id=new_id("session-completion"),
            status=InvestigationStatus.COMPLETED,
            completed_utc=utc_now_iso(),
            metadata={"supersedes": session.object_id},
        )
        completed_investigation = replace(
            running_investigation,
            object_id=new_id("investigation-completion"),
            status=InvestigationStatus.COMPLETED,
            metadata={"supersedes": running_investigation.object_id, "scientific_record_id": record.object_id},
        )
        self.repository.register_many((completed_session, completed_investigation))
        self._emit("publish", f"Published Scientific Record {record.object_id} to the SKR.")
        return record

    @staticmethod
    def _validate_plan(
        question: ScientificQuestion,
        investigation: Investigation,
        experiment: ExperimentDefinition,
    ) -> None:
        if investigation.question_id != question.object_id:
            raise ValueError("Investigation.question_id must reference the supplied ScientificQuestion.")
        if experiment.investigation_id not in (None, investigation.object_id):
            raise ValueError("ExperimentDefinition.investigation_id does not reference the supplied Investigation.")
        required = {"represent", "qualify", "publish"}
        missing = required.difference(investigation.enabled_capabilities)
        if missing:
            raise ValueError(f"Investigation is missing required capabilities: {sorted(missing)}")
