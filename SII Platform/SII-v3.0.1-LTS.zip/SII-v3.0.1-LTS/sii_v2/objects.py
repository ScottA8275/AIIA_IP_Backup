from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from .identity import new_id, utc_now_iso


class LifecycleState(str, Enum):
    CREATED = "created"
    VALIDATED = "validated"
    QUALIFIED = "qualified"
    PUBLISHED = "published"
    ARCHIVED = "archived"
    SUPERSEDED = "superseded"


class InvestigationStatus(str, Enum):
    PLANNED = "planned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class QualificationOutcome(str, Enum):
    QUALIFIED = "qualified"
    QUALIFIED_WITH_LIMITATIONS = "qualified_with_limitations"
    EXPLORATORY = "exploratory"
    CONCERN = "concern"


class EntitlementLevel(str, Enum):
    NONE = "none"
    EXPLORATORY = "exploratory"
    INTERNAL_DECISION_SUPPORT = "internal_decision_support"
    SCIENTIFIC_PUBLICATION = "scientific_publication"
    CROSS_DOMAIN_COMPARISON = "cross_domain_comparison"
    REGULATORY = "regulatory"


class QualificationCheckState(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    NOT_EVALUATED = "not_evaluated"
    INVALID = "invalid"


class QualificationDecisionRule(str, Enum):
    LEGACY_PROTOCOL = "legacy_protocol"
    EQUIVALENCE_ONLY = "equivalence_only"


class ImprovementStatus(str, Enum):
    PROPOSED = "proposed"
    READY_FOR_TRIAL = "ready_for_trial"
    APPLIED = "applied"
    REJECTED = "rejected"
    INCONCLUSIVE = "inconclusive"
    IMPROVED = "improved"
    DEGRADED = "degraded"


class ImprovementActionType(str, Enum):
    REVISE_REPRESENTATION = "revise_representation"
    REFINE_PARAMETERS = "refine_parameters"
    SPLIT_DOMINANT_BASIN = "split_dominant_basin"
    INCREASE_SEED_ROBUSTNESS = "increase_seed_robustness"
    REPAIR_EVIDENCE_COVERAGE = "repair_evidence_coverage"


@dataclass(frozen=True, kw_only=True)
class Provenance:
    created_utc: str = field(default_factory=utc_now_iso)
    created_by: str = "Structural Intelligence Instrument"
    instrument_version: str = "2.5.0-alpha.1"
    engine_name: str | None = None
    engine_version: str | None = None
    parent_object_ids: tuple[str, ...] = ()
    configuration: Mapping[str, Any] = field(default_factory=dict)
    source_references: tuple[str, ...] = ()


@dataclass(frozen=True, kw_only=True)
class ScientificObject:
    object_id: str = field(default_factory=lambda: new_id("object"))
    object_type: str
    object_version: str = "1.0"
    lifecycle_state: LifecycleState = LifecycleState.CREATED
    provenance: Provenance = field(default_factory=Provenance)
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, kw_only=True)
class ScientificQuestion(ScientificObject):
    object_type: str = "scientific_question"
    text: str
    domain: str
    question_type: str = "structural"
    hypotheses: tuple[str, ...] = ()


@dataclass(frozen=True, kw_only=True)
class Investigation(ScientificObject):
    object_type: str = "investigation"
    code: str
    name: str
    question_id: str
    status: InvestigationStatus = InvestigationStatus.PLANNED
    objectives: tuple[str, ...] = ()
    enabled_capabilities: tuple[str, ...] = ("represent", "qualify", "publish")


@dataclass(frozen=True, kw_only=True)
class InstrumentSession(ScientificObject):
    object_type: str = "instrument_session"
    run_name: str
    investigation_id: str
    status: InvestigationStatus = InvestigationStatus.RUNNING
    random_seed: int = 42
    started_utc: str = field(default_factory=utc_now_iso)
    completed_utc: str | None = None


@dataclass(frozen=True, kw_only=True)
class ExperimentDefinition(ScientificObject):
    """A bounded executable protocol inside an Investigation."""
    object_type: str = "experiment_definition"
    code: str
    name: str
    scientific_question: str
    investigation_id: str | None = None
    objectives: tuple[str, ...] = ()
    enabled_capabilities: tuple[str, ...] = ("represent", "qualify", "publish")


@dataclass(frozen=True, kw_only=True)
class DatasetRecord(ScientificObject):
    object_type: str = "dataset_record"
    name: str
    uri: str
    sha256: str | None = None
    observation_count: int | None = None
    feature_names: tuple[str, ...] = ()


@dataclass(frozen=True, kw_only=True)
class RepresentationProduct(ScientificObject):
    object_type: str = "representation_product"
    experiment_code: str
    configuration_id: str
    observation_count: int
    feature_names: tuple[str, ...]
    payload: Mapping[str, Any]
    diagnostics: Mapping[str, Any] = field(default_factory=dict)
    package_uri: str | None = None
    package_sha256: str | None = None
    array_inventory: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)


@dataclass(frozen=True, kw_only=True)
class OrganizationalAtlasRecord(ScientificObject):
    object_type: str = "organizational_atlas"
    representation_id: str
    basin_count: int | None = None
    neighborhood_count: int | None = None
    occupancy: Mapping[str, float] = field(default_factory=dict)
    topology_summary: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, kw_only=True)
class ScientificEntitlement:
    level: EntitlementLevel
    permitted_claims: tuple[str, ...]
    prohibited_claims: tuple[str, ...] = ()
    rationale: tuple[str, ...] = ()


@dataclass(frozen=True, kw_only=True)
class QualificationCheck(ScientificObject):
    object_type: str = "qualification_check"
    check_id: str
    display_name: str
    state: QualificationCheckState
    measured_value: Any = None
    threshold: Any = None
    direction: str | None = None
    critical: bool = False
    confidence: float | None = None
    evidence_count: int = 0
    rationale: str = ""
    limitations: tuple[str, ...] = ()
    recommendation: str | None = None


@dataclass(frozen=True, kw_only=True)
class QualificationDecision(ScientificObject):
    object_type: str = "qualification_decision"
    target_object_id: str
    profile_name: str
    outcome: QualificationOutcome
    rule: QualificationDecisionRule
    check_ids: tuple[str, ...]
    checks_passed: int
    checks_total: int
    critical_checks_passed: bool
    rationale: tuple[str, ...]
    blocking_check_ids: tuple[str, ...] = ()


@dataclass(frozen=True, kw_only=True)
class QualificationExplanation(ScientificObject):
    object_type: str = "qualification_explanation"
    decision_id: str
    summary: str
    supporting_factors: tuple[str, ...]
    limiting_factors: tuple[str, ...]
    required_actions: tuple[str, ...]
    entitlement_explanation: tuple[str, ...]


@dataclass(frozen=True, kw_only=True)
class StructuralDiagnosis(ScientificObject):
    object_type: str = "structural_diagnosis"
    qualification_record_id: str
    failed_check_ids: tuple[str, ...]
    diagnosis_code: str
    summary: str
    affected_regions: tuple[str, ...] = ()
    causal_hypotheses: tuple[str, ...] = ()
    confidence: float | None = None
    evidence: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, kw_only=True)
class ImprovementHypothesis(ScientificObject):
    object_type: str = "improvement_hypothesis"
    diagnosis_id: str
    hypothesis_code: str
    statement: str
    predicted_effects: Mapping[str, Any]
    target_check_ids: tuple[str, ...]
    falsification_criteria: tuple[str, ...]
    priority: int = 1


@dataclass(frozen=True, kw_only=True)
class RepresentationIntervention(ScientificObject):
    object_type: str = "representation_intervention"
    hypothesis_id: str
    action_type: ImprovementActionType
    parameter_changes: Mapping[str, Any]
    rationale: str
    safeguards: tuple[str, ...]
    status: ImprovementStatus = ImprovementStatus.PROPOSED


@dataclass(frozen=True, kw_only=True)
class RepresentationCandidate(ScientificObject):
    object_type: str = "representation_candidate"
    parent_representation_id: str
    intervention_id: str
    candidate_configuration_id: str
    expected_improvements: Mapping[str, Any]
    status: ImprovementStatus = ImprovementStatus.READY_FOR_TRIAL


@dataclass(frozen=True, kw_only=True)
class ImprovementTrial(ScientificObject):
    object_type: str = "improvement_trial"
    baseline_qualification_id: str
    candidate_representation_id: str
    candidate_qualification_id: str | None
    target_check_ids: tuple[str, ...]
    baseline_metrics: Mapping[str, Any]
    candidate_metrics: Mapping[str, Any]
    deltas: Mapping[str, Any]
    status: ImprovementStatus
    conclusion: str


@dataclass(frozen=True, kw_only=True)
class QualificationRecord(ScientificObject):
    object_type: str = "qualification_record"
    target_object_id: str
    profile_name: str
    outcome: QualificationOutcome
    metrics: Mapping[str, Any]
    limitations: tuple[str, ...]
    entitlement: ScientificEntitlement
    check_ids: tuple[str, ...] = ()
    decision_id: str | None = None
    explanation_id: str | None = None


@dataclass(frozen=True, kw_only=True)
class DiscoveryObject(ScientificObject):
    object_type: str = "discovery_object"
    discovery_kind: str
    source_object_ids: tuple[str, ...]
    findings: Mapping[str, Any]
    hypothesis_status: str = "candidate"


@dataclass(frozen=True, kw_only=True)
class ScientificClaim(ScientificObject):
    object_type: str = "scientific_claim"
    statement: str
    claim_type: str
    entitlement_required: EntitlementLevel
    supporting_object_ids: tuple[str, ...]


@dataclass(frozen=True, kw_only=True)
class EvidenceLink:
    source_object_id: str
    target_object_id: str
    relationship: str
    rationale: str


@dataclass(frozen=True, kw_only=True)
class EvidenceChain(ScientificObject):
    object_type: str = "evidence_chain"
    claim_id: str
    links: tuple[EvidenceLink, ...]

    def validate(self) -> None:
        if not self.links:
            raise ValueError("Evidence Chain must contain at least one link.")
        if self.links[-1].target_object_id != self.claim_id:
            raise ValueError("The final Evidence Chain link must terminate at the claim.")
        for left, right in zip(self.links, self.links[1:]):
            if left.target_object_id != right.source_object_id:
                raise ValueError("Evidence Chain links are not contiguous.")


@dataclass(frozen=True, kw_only=True)
class ScientificRecord(ScientificObject):
    object_type: str = "scientific_record"
    session_id: str
    investigation_id: str
    experiment_id: str
    question_id: str
    object_ids: tuple[str, ...]
    claim_ids: tuple[str, ...]
    evidence_chain_ids: tuple[str, ...]
    entitlement_level: EntitlementLevel
    conclusions: tuple[str, ...]
    limitations: tuple[str, ...]
    recommendations: tuple[str, ...]


@dataclass(frozen=True, kw_only=True)
class EquivalenceRecord(ScientificObject):
    """Evidence that a v2 engine preserves the outputs of its validated source implementation."""
    object_type: str = "equivalence_record"
    source_engine_name: str
    source_engine_version: str
    target_engine_name: str
    target_engine_version: str
    comparison_profile: str
    passed: bool
    compared_metrics: Mapping[str, Any]
    tolerances: Mapping[str, float]
    discrepancies: tuple[str, ...] = ()
    source_result_fingerprint: str | None = None
    target_result_fingerprint: str | None = None
