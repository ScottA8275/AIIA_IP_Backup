from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any
import json
import sys

import numpy as np

from rix_core.clustering import deterministic_kmeans

from .request_loader import RequalificationJob, sha256_file


def _kmeans(values: np.ndarray, k: int, seed: int, max_iter: int = 100) -> np.ndarray:
    """Compatibility wrapper around the frozen RIX Core primitive."""
    return deterministic_kmeans(values, k, seed, max_iter)


class DominantBasinReplayBuilder:
    def __init__(self, base_builder: Any, replay: dict[str, Any]) -> None:
        self.base_builder = base_builder
        self.replay = replay

    def __call__(self, data: Any, config: Any, seed: int, run_id: str) -> Any:
        run = self.base_builder(data, config, seed, run_id)
        artifacts = run.representation
        if artifacts is None:
            raise RuntimeError("Base representation run did not expose RepresentationArtifacts.")
        assignments = np.asarray(run.assignments, dtype=np.int64)
        features = np.asarray(artifacts.embedded_states, dtype=float)
        basin_ids, counts = np.unique(assignments, return_counts=True)
        dominant = int(basin_ids[np.argmax(counts)])
        mask = assignments == dominant
        split_count = int(self.replay["split_count"])
        labels = _kmeans(features[mask], split_count, seed, int(self.replay.get("algorithm_parameters", {}).get("max_iter", 100)))

        candidate = assignments.copy()
        indices = np.flatnonzero(mask)
        next_id = int(assignments.max()) + 1
        for cluster in range(1, split_count):
            candidate[indices[labels == cluster]] = next_id + cluster - 1

        ordered = np.unique(candidate)
        occupancy = np.asarray([(candidate == basin).sum() for basin in ordered], dtype=float)
        profile_width = int(run.basin_profiles.shape[1])
        profiles = np.vstack([
            np.asarray(features[candidate == basin, :profile_width], dtype=float).mean(axis=0)
            for basin in ordered
        ])
        new_artifacts = replace(artifacts, basin_assignments=candidate)
        metadata = dict(run.metadata)
        metadata.update({
            "requalification_intervention": self.replay["intervention_type"],
            "split_count": split_count,
            "dominant_basin_selected": dominant,
            "dominant_basin_rows": int(mask.sum()),
        })
        return replace(run, assignments=candidate, basin_profiles=profiles, basin_occupancy=occupancy,
                       representation=new_artifacts, metadata=metadata)


def execute_solar_requalification(*, job: RequalificationJob, project_root: Path, dataset_path: Path, output_dir: Path) -> dict[str, Any]:
    project_root = Path(project_root).resolve()
    legacy_dir = project_root / "legacy_solar_v1"
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(legacy_dir))
    try:
        from qualification_config import ACTIVE_PROTOCOL
        from solar_m1d_adapter import SolarM1DAdapter, initialize_solar_atlas
        from phase1_representation import run_phase1_representation
        protocol = replace(ACTIVE_PROTOCOL, paths=replace(ACTIVE_PROTOCOL.paths, input_file=Path(dataset_path).resolve()))
        protocol.validate()
        adapter = SolarM1DAdapter(protocol=protocol, legacy_script_path=legacy_dir / "run_m1d_solar_atlas_validation.py")

        dataset = adapter.load_data(Path(dataset_path).resolve())

        atlas = initialize_solar_atlas(
            protocol=protocol,
            dataset=dataset,
        )

        builder = DominantBasinReplayBuilder(
            adapter,
            job.intervention_replay,
        )

        phase1 = run_phase1_representation(
            atlas=atlas,
            data=dataset.data,
            builder=builder,
            protocol=protocol,
            output_dir=output_dir / "phase1",
        )

    finally:
        if sys.path and sys.path[0] == str(legacy_dir):
            sys.path.pop(0)

    summary = phase1.to_summary()
    baseline = job.representation.get("parent_scientific_context", {}).get("parent_payload", {}).get("phase1_qualification_summary", {})
    result = {
        "schema": "aiia.sii.requalification-result",
        "schema_version": "1.0",
        "request_id": job.request["object_id"],
        "candidate_product_id": job.candidate_id,
        "candidate_package": str(job.candidate_path) if job.candidate_path is not None else None,
        "candidate_package_sha256": sha256_file(job.candidate_path) if job.candidate_path is not None else None,
        "optimization_generated": bool(job.request.get("optimization_generated")),
        "parent_product_id": job.request["parent_product_id"],
        "profile": job.request["requested_profile"],
        "intervention_replay": job.intervention_replay,
        "status": summary.get("status"),
        "candidate_phase1_summary": summary,
        "parent_phase1_summary": baseline,
        "governance": "SII independently determines scientific entitlement; this result does not alter the candidate package.",
    }
    (output_dir / "requalification_result.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    lines = [
        "SII v2.8 REQUALIFICATION RESULT",
        "=" * 60,
        f"Request: {result['request_id']}",
        f"Candidate: {result['candidate_product_id']}",
        f"Split count: {job.split_count}",
        f"Phase 1 status: {result['status']}",
        "",
        "METRIC RESULTS",
    ]
    for metric_id, metric in summary.get("metric_results", {}).items():
        lines.append(f"- {metric_id}: value={metric.get('value')} state={metric.get('state')} threshold={metric.get('threshold')}")
    (output_dir / "requalification_result.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result
