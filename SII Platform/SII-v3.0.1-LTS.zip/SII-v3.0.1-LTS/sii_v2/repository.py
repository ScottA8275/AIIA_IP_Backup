from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import Any, Iterable

from .objects import ScientificObject
from .serialization import content_hash, to_primitive, write_json


class RepositoryConflictError(RuntimeError):
    pass


class FileStructuralKnowledgeRepository:
    """Immutable file-backed Structural Knowledge Repository."""

    def __init__(self, root: Path) -> None:
        self.root = root.expanduser().resolve()
        self.objects_dir = self.root / "objects"
        self.index_path = self.root / "index.jsonl"
        self.objects_dir.mkdir(parents=True, exist_ok=True)

    def register(self, obj: ScientificObject) -> str:
        payload = to_primitive(obj)
        digest = content_hash(payload)
        path = self.objects_dir / obj.object_type / f"{obj.object_id}.json"
        if path.exists():
            existing = json.loads(path.read_text(encoding="utf-8"))
            if content_hash(existing) != digest:
                raise RepositoryConflictError(f"Object ID already exists with different content: {obj.object_id}")
            return obj.object_id
        write_json(path, payload)
        index_entry = {
            "object_id": obj.object_id,
            "object_type": obj.object_type,
            "object_version": obj.object_version,
            "lifecycle_state": obj.lifecycle_state.value,
            "content_sha256": digest,
            "path": str(path.relative_to(self.root)),
        }
        with self.index_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(index_entry, sort_keys=True) + "\n")
        return obj.object_id

    def register_many(self, objects: Iterable[ScientificObject]) -> tuple[str, ...]:
        return tuple(self.register(obj) for obj in objects)

    def get(self, object_id: str) -> dict[str, Any]:
        if not self.index_path.exists():
            raise KeyError(object_id)
        for line in self.index_path.read_text(encoding="utf-8").splitlines():
            entry = json.loads(line)
            if entry["object_id"] == object_id:
                return json.loads((self.root / entry["path"]).read_text(encoding="utf-8"))
        raise KeyError(object_id)

    def search(self, *, object_type: str | None = None) -> list[dict[str, Any]]:
        if not self.index_path.exists():
            return []
        entries = [json.loads(line) for line in self.index_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if object_type is not None:
            entries = [entry for entry in entries if entry["object_type"] == object_type]
        return entries


def _load_by_type(self, object_type: str):
    directory = self.objects_dir / object_type
    if not directory.exists():
        return []
    import json
    return [json.loads(path.read_text(encoding="utf-8")) for path in sorted(directory.glob("*.json"))]

FileStructuralKnowledgeRepository.load_by_type = _load_by_type
