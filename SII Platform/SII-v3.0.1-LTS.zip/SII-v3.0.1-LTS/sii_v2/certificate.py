
from __future__ import annotations

from pathlib import Path
from typing import Iterable

from .objects import EquivalenceRecord, ScientificRecord
from .repository import FileStructuralKnowledgeRepository


def render_investigation_certificate(
    *,
    record: ScientificRecord,
    repository: FileStructuralKnowledgeRepository,
    investigation_name: str,
    scientific_question: str,
    output_path: Path,
) -> Path:
    equivalence_records = [
        obj for obj in repository.load_by_type("equivalence_record")
        if obj.get("object_id") in set(record.object_ids)
        or obj.get("passed") is not None
    ]
    eq = equivalence_records[-1] if equivalence_records else None
    lines = [
        "STRUCTURAL INTELLIGENCE INSTRUMENT",
        "SCIENTIFIC INVESTIGATION CERTIFICATE",
        "=" * 62,
        "",
        f"Investigation: {investigation_name}",
        f"Scientific Question: {scientific_question}",
        f"Scientific Record: {record.object_id}",
        "",
        "SCIENTIFIC INTEGRITY",
        f"  Evidence Chains: {len(record.evidence_chain_ids)} validated",
        f"  Scientific Entitlement: {record.entitlement_level.value}",
    ]
    if eq:
        lines.extend([
            f"  v1-to-v2 Equivalence: {'PASSED' if eq.get('passed') else 'FAILED'}",
            f"  Source Fingerprint: {eq.get('source_result_fingerprint')}",
            f"  Target Fingerprint: {eq.get('target_result_fingerprint')}",
        ])
    lines.extend([
        "",
        "REPOSITORY STATUS",
        "  Scientific objects archived in the Structural Knowledge Repository.",
        "",
        "INSTRUMENT STATUS",
        "  OPERATIONAL",
        "",
        "This certificate records completion under the registered instrument,",
        "engine, configuration, qualification, entitlement, and Evidence Chain.",
    ])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return output_path
