"""Structural Intelligence Instrument v2.5."""

from .instrument import StructuralIntelligenceInstrument
from .objects import (
    DatasetRecord,
    DiscoveryObject,
    EntitlementLevel,
    EvidenceChain,
    ExperimentDefinition,
    InstrumentSession,
    Investigation,
    InvestigationStatus,
    OrganizationalAtlasRecord,
    QualificationRecord,
    RepresentationProduct,
    ScientificClaim,
    ScientificQuestion,
    ScientificRecord,
)
from .reporting import render_investigation_report, write_investigation_report
from .repository import FileStructuralKnowledgeRepository
from .representation_package import RepresentationProductStore

__all__ = [
    "StructuralIntelligenceInstrument",
    "FileStructuralKnowledgeRepository",
    "RepresentationProductStore",
    "ScientificQuestion",
    "Investigation",
    "InvestigationStatus",
    "DatasetRecord",
    "DiscoveryObject",
    "EntitlementLevel",
    "EvidenceChain",
    "ExperimentDefinition",
    "InstrumentSession",
    "OrganizationalAtlasRecord",
    "QualificationRecord",
    "RepresentationProduct",
    "ScientificClaim",
    "ScientificRecord",
    "render_investigation_report",
    "write_investigation_report",
]

__version__ = "2.5.0-alpha.1"

# SII v2.9 structural entitlement
from .entitlement import EntitlementPolicy, detect_structural_entitlement, write_entitlement_reports
