from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any, Mapping
import hashlib
import io
import json
import zipfile

import numpy as np

from .objects import DatasetRecord, ExperimentDefinition, RepresentationProduct
from .serialization import to_primitive

SCHEMA = "aiia.representation-product"
SCHEMA_VERSION = "1.0"


from rix_core.integrity import sha256_file

from rix_core.representation import array_inventory


def _inventory(arrays: Mapping[str, np.ndarray]) -> dict[str, dict[str, Any]]:
    """Compatibility wrapper around the frozen RIX Core primitive."""
    return array_inventory(arrays)


class RepresentationProductStore:
    """Immutable writer/reader for portable `.aiia-rp` packages."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def persist(
        self,
        *,
        representation: RepresentationProduct,
        arrays: Mapping[str, Any],
        dataset: DatasetRecord,
        experiment: ExperimentDefinition,
        instrument_name: str,
        instrument_version: str,
    ) -> RepresentationProduct:
        normalized = {
            str(name): np.asarray(value)
            for name, value in arrays.items()
            if value is not None
        }
        for name, value in normalized.items():
            if value.dtype == object:
                raise TypeError(f"Representation array {name!r} has unsafe object dtype.")

        inventory = _inventory(normalized)
        path = self.root / f"{representation.object_id}.aiia-rp"
        if path.exists():
            raise FileExistsError(f"Refusing to overwrite Representation Product: {path}")

        enriched = replace(
            representation,
            package_uri=str(path),
            array_inventory=inventory,
        )
        manifest = {
            "schema": SCHEMA,
            "schema_version": SCHEMA_VERSION,
            "product_id": enriched.object_id,
            "instrument": {"name": instrument_name, "version": instrument_version},
            "dataset": {
                "object_id": dataset.object_id,
                "name": dataset.name,
                "uri": dataset.uri,
                "sha256": dataset.sha256,
            },
            "experiment": {
                "object_id": experiment.object_id,
                "code": experiment.code,
                "name": experiment.name,
            },
            "representation": to_primitive(enriched),
            "arrays": inventory,
            "immutability": {
                "policy": "A changed representation must be persisted as a new product ID."
            },
        }

        array_buffer = io.BytesIO()
        np.savez_compressed(array_buffer, **normalized)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("manifest.json", json.dumps(manifest, indent=2, sort_keys=True))
            archive.writestr("representation.json", json.dumps(to_primitive(enriched), indent=2, sort_keys=True))
            archive.writestr("arrays.npz", array_buffer.getvalue())

        digest = sha256_file(path)
        return replace(enriched, package_sha256=digest)

    @staticmethod
    def inspect(path: Path) -> dict[str, Any]:
        with zipfile.ZipFile(Path(path), "r") as archive:
            manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
            required = {"manifest.json", "representation.json", "arrays.npz"}
            missing = required.difference(archive.namelist())
            if missing:
                raise ValueError(f"Invalid Representation Product; missing: {sorted(missing)}")
            return manifest

    @staticmethod
    def load_arrays(path: Path) -> dict[str, np.ndarray]:
        with zipfile.ZipFile(Path(path), "r") as archive:
            with archive.open("arrays.npz") as stream:
                payload = np.load(stream, allow_pickle=False)
                return {name: payload[name] for name in payload.files}
