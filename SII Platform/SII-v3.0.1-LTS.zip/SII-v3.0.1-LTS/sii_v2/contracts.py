from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from .objects import (
    DatasetRecord,
    DiscoveryObject,
    ExperimentDefinition,
    OrganizationalAtlasRecord,
    QualificationRecord,
    RepresentationProduct,
    ScientificRecord,
)


@runtime_checkable
class RepresentationEngine(Protocol):
    name: str
    version: str

    def represent(self, *, dataset: DatasetRecord, experiment: ExperimentDefinition, seed: int) -> RepresentationProduct: ...

    def representation_arrays(self, *, representation: RepresentationProduct) -> dict[str, Any]: ...

    def atlas(self, *, representation: RepresentationProduct) -> OrganizationalAtlasRecord | None: ...


@runtime_checkable
class QualificationEngine(Protocol):
    name: str
    version: str

    def qualify(self, *, representation: RepresentationProduct, atlas: OrganizationalAtlasRecord | None) -> QualificationRecord: ...


@runtime_checkable
class DiscoveryEngine(Protocol):
    name: str
    version: str

    def discover(self, *, representation: RepresentationProduct, atlas: OrganizationalAtlasRecord | None, qualification: QualificationRecord) -> tuple[DiscoveryObject, ...]: ...


@runtime_checkable
class PublicationEngine(Protocol):
    name: str
    version: str

    def publish(self, *, context: dict[str, Any]) -> ScientificRecord: ...
