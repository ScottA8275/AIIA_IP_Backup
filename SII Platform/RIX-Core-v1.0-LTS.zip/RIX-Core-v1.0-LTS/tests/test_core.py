from pathlib import Path
import numpy as np
from rix_core import deterministic_kmeans, array_inventory, sha256_file


def test_deterministic_kmeans_is_repeatable():
    values = np.array([[0.0], [0.1], [10.0], [10.1]])
    assert np.array_equal(deterministic_kmeans(values, 2, 7), deterministic_kmeans(values, 2, 7))


def test_inventory_and_digest(tmp_path: Path):
    inv = array_inventory({"x": np.zeros((2, 3), dtype=np.float64)})
    assert inv["x"]["shape"] == [2, 3]
    path = tmp_path / "x.bin"; path.write_bytes(b"rix")
    assert len(sha256_file(path)) == 64
