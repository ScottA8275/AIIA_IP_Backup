# RIX Core v1.0 LTS

Immutable Generation 1 reference implementation of shared Recursive Indexing computational primitives.

This package owns deterministic structural computation, representation-array conventions, identity, and integrity primitives shared by AIIA Platform and SII. It does not perform representation engineering or scientific qualification.

Install before the two client systems:

```bash
python -m pip install .
```
