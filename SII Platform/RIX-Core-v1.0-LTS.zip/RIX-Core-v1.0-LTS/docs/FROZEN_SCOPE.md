# Frozen scope

RIX Core v1.0 LTS freezes the shared Generation 1 computational contract:

- deterministic k-means used by dominant-basin splitting and replay;
- representation assignment and feature aliases;
- representation array inventory generation;
- SHA-256 file integrity;
- canonical identifiers and UTC timestamps.

AIIA Platform owns engineering policy. SII owns scientific investigation policy. Neither policy belongs in RIX Core.
