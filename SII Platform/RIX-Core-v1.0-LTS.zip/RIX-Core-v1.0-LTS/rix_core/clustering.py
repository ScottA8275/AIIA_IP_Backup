from __future__ import annotations
import numpy as np


def deterministic_kmeans(values: np.ndarray, k: int, seed: int, max_iter: int = 100) -> np.ndarray:
    """Canonical Generation 1 deterministic k-means assignment primitive."""
    values = np.asarray(values)
    if values.ndim != 2:
        raise ValueError("values must be a two-dimensional array")
    if k < 1:
        raise ValueError("k must be at least 1")
    if len(values) < k:
        raise ValueError(f"Cannot split {len(values)} rows into {k} clusters.")
    rng = np.random.default_rng(seed)
    centers = values[rng.choice(len(values), k, replace=False)].astype(float, copy=True)
    labels = np.full(len(values), -1, dtype=np.int64)
    for _ in range(max_iter):
        next_labels = ((values[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2).argmin(axis=1)
        if np.array_equal(next_labels, labels):
            break
        labels = next_labels
        for index in range(k):
            members = values[labels == index]
            centers[index] = members.mean(axis=0) if len(members) else values[rng.integers(len(values))]
    return labels.astype(np.int64)
