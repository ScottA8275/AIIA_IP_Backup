from __future__ import annotations
from hashlib import sha256
from pathlib import Path


def sha256_file(path: Path) -> str:
    """Return the SHA-256 digest of a file using bounded-memory streaming."""
    digest = sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
