"""RIX Core: canonical Generation 1 computational primitives."""
from .clustering import deterministic_kmeans
from .identity import new_id, utc_now_iso
from .integrity import sha256_file
from .representation import (
    ASSIGNMENT_ALIASES,
    FEATURE_ALIASES,
    array_inventory,
    first_present,
)

__version__ = "1.0.0"

__all__ = [
    "ASSIGNMENT_ALIASES", "FEATURE_ALIASES", "array_inventory",
    "deterministic_kmeans", "first_present", "new_id", "sha256_file",
    "utc_now_iso",
]
