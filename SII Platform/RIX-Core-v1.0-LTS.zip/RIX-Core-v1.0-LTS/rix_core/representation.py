from __future__ import annotations
from typing import Any, Mapping
import numpy as np

ASSIGNMENT_ALIASES = ("basin_assignments", "assignments")
FEATURE_ALIASES = ("embedded_states", "features", "scaled_states", "coordinate_matrix")


def first_present(mapping: Mapping[str, Any], names: tuple[str, ...]) -> str | None:
    return next((name for name in names if name in mapping), None)


def array_inventory(arrays: Mapping[str, np.ndarray]) -> dict[str, dict[str, Any]]:
    return {
        name: {"shape": list(value.shape), "dtype": str(value.dtype), "size": int(value.size)}
        for name, value in sorted(arrays.items())
    }
