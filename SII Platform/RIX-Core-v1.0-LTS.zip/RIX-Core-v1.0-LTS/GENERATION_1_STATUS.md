# Generation 1 status

Release: RIX-Core-v1.0-LTS
Status: Frozen LTS baseline
Validation: 2 passed

Changes require a new version. The frozen scientific or engineering behavior must not be altered in place.
