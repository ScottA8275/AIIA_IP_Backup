# Generation 1 status

Release: AIIA-Platform-v0.6.2-LTS
Status: Frozen LTS baseline
Validation: 5 passed

Changes require a new version. The frozen scientific or engineering behavior must not be altered in place.
