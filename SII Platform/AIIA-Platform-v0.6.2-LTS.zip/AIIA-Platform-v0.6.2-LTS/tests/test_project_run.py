from aiia.config import PlatformConfig
from aiia.projects import ProjectContext
from aiia.projects.solar import SolarProject
from aiia.validation import validate_startup


def test_solar_project_executes_candidate_evaluations(synthetic_workspace):
    config = PlatformConfig(
        workspace_root=synthetic_workspace["workspace"],
        sii_output_root=synthetic_workspace["sii_output"],
        aiia_output_root=synthetic_workspace["aiia_output"],
        execute_candidates=True,
    ).normalized()
    validation = validate_startup(config)
    project = SolarProject(ProjectContext(config, validation.discovery))
    record = project.run()
    assert record.decision.value in {"accept", "reject", "inconclusive"}
    assert len(record.candidates) == 3
    assert len(record.evaluations) == 3
    assert all((item.requalification_request is not None) == (item.decision.value == "accept") for item in record.evaluations)
    assert (project.output_directory / "engineering_record.json").exists()
    assert (project.output_directory / "engineering_report.txt").exists()
    assert len(list((project.output_directory / "candidate_representation_products").rglob("*.aiia-rp"))) == 3
    request_count = sum(item.decision.value == "accept" for item in record.evaluations)
    request_dir = project.output_directory / "sii_requalification_requests"
    actual_request_count = len(list(request_dir.glob("*.json"))) if request_dir.exists() else 0
    assert actual_request_count == request_count
