from __future__ import annotations

from pathlib import Path
import io
import json
import zipfile

import numpy as np
import pytest


@pytest.fixture
def synthetic_workspace(tmp_path: Path) -> dict[str, Path]:
    workspace = tmp_path / "workspace"
    sii_output = workspace / "examples" / "sii_v2_5_output"
    product_dir = sii_output / "skr" / "representation_products"
    product_dir.mkdir(parents=True)
    product_path = product_dir / "baseline.aiia-rp"

    assignments = np.array([0, 0, 0, 0, 1, 1, 2, 2], dtype=np.int64)
    features = np.array([[0, 0], [0.1, 0], [1, 1], [1.1, 1], [3, 3], [3.1, 3], [6, 6], [6.1, 6]], dtype=float)
    arrays = io.BytesIO()
    np.savez_compressed(arrays, basin_assignments=assignments, embedded_states=features)
    representation = {"object_id": "representation-baseline", "object_type": "representation_product"}
    manifest = {"schema": "sii.representation-product", "schema_version": "1.0", "product_id": "representation-baseline"}
    with zipfile.ZipFile(product_path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest))
        archive.writestr("representation.json", json.dumps(representation))
        archive.writestr("arrays.npz", arrays.getvalue())

    record_dir = sii_output / "skr" / "scientific_record"
    record_dir.mkdir(parents=True)
    record_path = record_dir / "record-baseline.json"
    record_path.write_text(json.dumps({"object_id": "record-baseline", "object_type": "scientific_record"}), encoding="utf-8")

    return {
        "workspace": workspace,
        "sii_output": sii_output,
        "aiia_output": workspace / "examples" / "aiia_platform_v0_6_1",
        "product": product_path,
        "record": record_path,
    }
