from __future__ import annotations

import io
import json
from pathlib import Path
import zipfile

import numpy as np

from aiia.config import PlatformConfig
from aiia.evaluation import evaluate_candidate
from aiia.projects import ProjectContext
from aiia.projects.solar import SolarProject
from aiia.representation import load_representation_product
from aiia.validation import validate_startup


def test_candidate_materialization_recomputes_dependent_arrays(synthetic_workspace):
    config = PlatformConfig(
        workspace_root=synthetic_workspace["workspace"],
        sii_output_root=synthetic_workspace["sii_output"],
        aiia_output_root=synthetic_workspace["aiia_output"],
        execute_candidates=True,
    ).normalized()
    validation = validate_startup(config)
    record = SolarProject(ProjectContext(config, validation.discovery)).run()
    candidate = load_representation_product(Path(record.candidates[-1].product.path))
    arrays = candidate.load_arrays()
    basin_count = len(np.unique(arrays["basin_assignments"]))
    assert len(arrays["basin_occupancy"]) == basin_count
    assert len(arrays["basin_profiles"]) == basin_count
    assert candidate.representation["represented_state_count"] == len(arrays["basin_assignments"])
    assert candidate.representation["candidate_scientific_status"]["qualified"] is False
    assert candidate.manifest["engineering"]["platform_version"] == "0.6.2"


def test_inherited_rare_basin_is_not_a_new_defect(tmp_path: Path):
    def write_product(path: Path, product_id: str, assignments: np.ndarray, parent_id: str | None = None) -> None:
        features = np.arange(len(assignments) * 2, dtype=float).reshape(len(assignments), 2)
        ids, counts = np.unique(assignments, return_counts=True)
        profiles = np.stack([features[assignments == basin_id].mean(axis=0) for basin_id in ids])
        arrays = io.BytesIO()
        np.savez_compressed(
            arrays,
            basin_assignments=assignments,
            embedded_states=features,
            basin_occupancy=counts.astype(float),
            basin_profiles=profiles,
            coordinate_matrix=features,
        )
        representation = {
            "object_id": product_id,
            "object_type": "representation_product",
            "parent_product_id": parent_id,
            "payload": {"legacy_metadata": {"basin_ids_in_profile_order": ids.tolist()}},
        }
        manifest = {
            "schema": "aiia.native-representation-product",
            "schema_version": "1.1",
            "product_id": product_id,
            "lineage": {"parent_product_id": parent_id},
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("manifest.json", json.dumps(manifest))
            archive.writestr("representation.json", json.dumps(representation))
            archive.writestr("arrays.npz", arrays.getvalue())

    # Basin 2 is rare in the baseline and remains unchanged in the candidate.
    baseline_assignments = np.array([0] * 900 + [1] * 99 + [2], dtype=np.int64)
    candidate_assignments = np.array([0] * 500 + [3] * 400 + [1] * 99 + [2], dtype=np.int64)
    baseline_path = tmp_path / "baseline.aiia-rp"
    candidate_path = tmp_path / "candidate.aiia-rp"
    write_product(baseline_path, "representation-baseline", baseline_assignments)
    write_product(candidate_path, "representation-candidate", candidate_assignments, "representation-baseline")

    decision, record_ref, _, _, _ = evaluate_candidate(
        baseline=load_representation_product(baseline_path),
        candidate=load_representation_product(candidate_path),
        output_dir=tmp_path / "eval",
        candidate_id="candidate-test",
    )
    payload = json.loads(Path(record_ref.path).read_text(encoding="utf-8"))
    assert decision.value == "accept"
    assert payload["rare_basin_analysis"]["new_rare_basin_ids"] == []
    assert payload["checks"]["rare_basin_count_not_worsened"] is True
