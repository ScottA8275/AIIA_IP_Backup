from aiia.config import PlatformConfig
from aiia.projects import ProjectContext
from aiia.projects.solar import SolarProject
from aiia.representation import load_representation_product
from aiia.validation import validate_startup


def test_candidates_preserve_parent_lineage(synthetic_workspace):
    config = PlatformConfig(
        workspace_root=synthetic_workspace["workspace"],
        sii_output_root=synthetic_workspace["sii_output"],
        aiia_output_root=synthetic_workspace["aiia_output"],
    ).normalized()
    validation = validate_startup(config)
    record = SolarProject(ProjectContext(config, validation.discovery)).run()
    candidate = load_representation_product(record.candidates[0].product.path)
    assert candidate.manifest["lineage"]["parent_product_id"] == "representation-baseline"
    assert candidate.manifest["engineering"]["platform_version"] == "0.6.2"
