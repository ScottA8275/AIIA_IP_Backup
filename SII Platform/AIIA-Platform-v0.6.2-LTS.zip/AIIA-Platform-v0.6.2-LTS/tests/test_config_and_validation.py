from aiia.config import PlatformConfig
from aiia.validation import validate_startup


def test_config_derives_paths_and_creates_output(synthetic_workspace):
    config = PlatformConfig(
        workspace_root=synthetic_workspace["workspace"],
        sii_output_root=synthetic_workspace["sii_output"],
        aiia_output_root=synthetic_workspace["aiia_output"],
    ).normalized()
    result = validate_startup(config)
    assert config.representation_product_dir.name == "representation_products"
    assert config.aiia_output_root.exists()
    assert len(result.discovery.representation_products) == 1
    assert len(result.discovery.scientific_records) == 1
