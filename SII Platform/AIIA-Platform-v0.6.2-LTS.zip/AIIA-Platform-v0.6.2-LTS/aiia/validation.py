from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from aiia.config import PlatformConfig
from aiia.discovery import DiscoveryResult, discover_sii_outputs


class ConfigurationError(RuntimeError):
    pass


@dataclass(frozen=True)
class ValidationResult:
    config: PlatformConfig
    discovery: DiscoveryResult


def validate_startup(config: PlatformConfig, *, create_output: bool = True) -> ValidationResult:
    errors: list[str] = []
    if not config.workspace_root.exists():
        errors.append(f"Workspace root not found: {config.workspace_root}")
    if not config.sii_output_root.exists():
        errors.append(f"SII output root not found: {config.sii_output_root}")
    if not config.representation_product_dir.exists():
        errors.append(f"Representation Product directory not found: {config.representation_product_dir}")

    discovery = discover_sii_outputs(config)
    if not discovery.representation_products:
        errors.append(
            "No .aiia-rp files found. Expected at least one under: "
            f"{config.representation_product_dir}"
        )
    if errors:
        raise ConfigurationError("AIIA Platform configuration is invalid:\n- " + "\n- ".join(errors))

    if create_output:
        config.aiia_output_root.mkdir(parents=True, exist_ok=True)
    return ValidationResult(config, discovery)


def print_startup_diagnostics(result: ValidationResult, project_code: str) -> None:
    config = result.config
    discovery = result.discovery
    print("=" * 60)
    print("AIIA PLATFORM v0.6.1")
    print("=" * 60)
    print(f"Workspace:               {config.workspace_root}")
    print(f"SII output:              {config.sii_output_root}")
    print(f"Representation Products: {len(discovery.representation_products)} found")
    print(f"Scientific Records:      {len(discovery.scientific_records)} found")
    print(f"AIIA output:             {config.aiia_output_root}")
    print(f"Project output:          {config.project_output(project_code)}")
    print("Configuration:           VALID")
    print()
