from __future__ import annotations

from dataclasses import dataclass
from math import log
from pathlib import Path
from typing import Any
import json

import numpy as np

from aiia import __version__
from aiia.representation import NativeRepresentationProduct
from aiia.shared.io import sha256_file
from aiia.shared.models import ArtifactRef, Decision, new_id, utc_now

MICROBASIN_THRESHOLD = 0.001


@dataclass(frozen=True)
class StructuralMetrics:
    row_count: int
    basin_count: int
    basin_ids: tuple[int, ...]
    basin_occupancies: tuple[float, ...]
    maximum_basin_occupancy: float
    minimum_basin_occupancy: float
    rare_basin_count: int
    occupancy_entropy: float
    coordinate_shape: tuple[int, ...] | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "row_count": self.row_count,
            "basin_count": self.basin_count,
            "basin_ids": list(self.basin_ids),
            "basin_occupancies": list(self.basin_occupancies),
            "maximum_basin_occupancy": self.maximum_basin_occupancy,
            "minimum_basin_occupancy": self.minimum_basin_occupancy,
            "rare_basin_count": self.rare_basin_count,
            "occupancy_entropy": self.occupancy_entropy,
            "coordinate_shape": list(self.coordinate_shape) if self.coordinate_shape else None,
        }


def measure(product: NativeRepresentationProduct) -> StructuralMetrics:
    arrays = product.load_arrays()
    assignments = np.asarray(arrays[product.assignment_array_name()]).reshape(-1)
    basin_ids, counts = np.unique(assignments, return_counts=True)
    occupancy = counts.astype(float) / max(len(assignments), 1)
    entropy = float(-sum(float(p) * log(float(p)) for p in occupancy if p > 0))
    coordinate_shape = tuple(int(x) for x in arrays["coordinate_matrix"].shape) if "coordinate_matrix" in arrays else None
    return StructuralMetrics(
        row_count=int(len(assignments)),
        basin_count=int(len(counts)),
        basin_ids=tuple(int(x) for x in basin_ids),
        basin_occupancies=tuple(float(x) for x in occupancy),
        maximum_basin_occupancy=float(occupancy.max()) if len(occupancy) else 0.0,
        minimum_basin_occupancy=float(occupancy.min()) if len(occupancy) else 0.0,
        rare_basin_count=int(np.sum(occupancy < MICROBASIN_THRESHOLD)),
        occupancy_entropy=entropy,
        coordinate_shape=coordinate_shape,
    )


def evaluate_candidate(
    *,
    baseline: NativeRepresentationProduct,
    candidate: NativeRepresentationProduct,
    output_dir: Path,
    candidate_id: str,
) -> tuple[Decision, ArtifactRef, ArtifactRef, str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    baseline_metrics = measure(baseline)
    candidate_metrics = measure(candidate)
    arrays0 = baseline.load_arrays()
    arrays1 = candidate.load_arrays()

    valid, integrity_errors, integrity_warnings = candidate.validate()
    lineage_ok = (
        candidate.manifest.get("lineage", {}).get("parent_product_id") == baseline.product_id
        and candidate.representation.get("parent_product_id") == baseline.product_id
    )
    rows_preserved = candidate_metrics.row_count == baseline_metrics.row_count
    coordinates_preserved = True
    coordinate_note = "No coordinate_matrix was available in both products."
    if "coordinate_matrix" in arrays0 and "coordinate_matrix" in arrays1:
        coordinates_preserved = bool(np.array_equal(arrays0["coordinate_matrix"], arrays1["coordinate_matrix"]))
        coordinate_note = "Global coordinate matrix preserved exactly." if coordinates_preserved else "Global coordinate matrix changed."

    occupancy_improved = candidate_metrics.maximum_basin_occupancy < baseline_metrics.maximum_basin_occupancy
    occupancy_target_met = candidate_metrics.maximum_basin_occupancy <= 0.90

    baseline_map = dict(zip(baseline_metrics.basin_ids, baseline_metrics.basin_occupancies))
    candidate_map = dict(zip(candidate_metrics.basin_ids, candidate_metrics.basin_occupancies))
    new_basin_ids = tuple(sorted(set(candidate_map) - set(baseline_map)))
    new_rare_basin_ids = tuple(basin_id for basin_id in new_basin_ids if candidate_map[basin_id] < MICROBASIN_THRESHOLD)
    rare_basin_count_not_worsened = candidate_metrics.rare_basin_count <= baseline_metrics.rare_basin_count
    no_new_pathological_microbasin = not new_rare_basin_ids and rare_basin_count_not_worsened

    blocking: list[str] = []
    if not valid:
        blocking.extend(f"Package integrity: {item}" for item in integrity_errors)
    if not lineage_ok:
        blocking.append("Candidate lineage does not reference the baseline product.")
    if not rows_preserved:
        blocking.append("Candidate changed the number of represented states.")
    if not coordinates_preserved:
        blocking.append("Candidate changed the preserved global coordinate matrix.")
    if new_rare_basin_ids:
        blocking.append(
            f"Candidate introduced new basin(s) below the {MICROBASIN_THRESHOLD:.3%} occupancy threshold: {list(new_rare_basin_ids)}."
        )
    elif not rare_basin_count_not_worsened:
        blocking.append("Candidate increased the number of basins below the rare-basin threshold.")

    if blocking:
        decision = Decision.REJECT
        outcome = "engineering_prequalification_failed"
    elif occupancy_improved and occupancy_target_met:
        decision = Decision.ACCEPT
        outcome = "engineering_prequalification_passed"
    elif occupancy_improved:
        decision = Decision.INCONCLUSIVE
        outcome = "improved_but_target_not_met"
    else:
        decision = Decision.REJECT
        outcome = "target_not_improved"

    record_id = new_id("candidate-evaluation")
    payload = {
        "object_id": record_id,
        "object_type": "candidate_evaluation_record",
        "platform_version": __version__,
        "created_at": utc_now(),
        "candidate_id": candidate_id,
        "baseline_product_id": baseline.product_id,
        "candidate_product_id": candidate.product_id,
        "decision": decision.value,
        "outcome": outcome,
        "entitlement": "engineering_prequalification_only",
        "scientific_status": "requires_independent_sii_requalification" if decision is Decision.ACCEPT else "not_referred_to_sii",
        "checks": {
            "package_integrity_valid": valid,
            "lineage_ok": lineage_ok,
            "rows_preserved": rows_preserved,
            "coordinates_preserved": coordinates_preserved,
            "occupancy_improved": occupancy_improved,
            "occupancy_target_met": occupancy_target_met,
            "rare_basin_count_not_worsened": rare_basin_count_not_worsened,
            "no_new_pathological_microbasin": no_new_pathological_microbasin,
        },
        "rare_basin_analysis": {
            "threshold": MICROBASIN_THRESHOLD,
            "baseline_rare_basin_count": baseline_metrics.rare_basin_count,
            "candidate_rare_basin_count": candidate_metrics.rare_basin_count,
            "new_basin_ids": list(new_basin_ids),
            "new_rare_basin_ids": list(new_rare_basin_ids),
        },
        "baseline_metrics": baseline_metrics.to_dict(),
        "candidate_metrics": candidate_metrics.to_dict(),
        "deltas": {
            "maximum_basin_occupancy": candidate_metrics.maximum_basin_occupancy - baseline_metrics.maximum_basin_occupancy,
            "occupancy_entropy": candidate_metrics.occupancy_entropy - baseline_metrics.occupancy_entropy,
            "basin_count": candidate_metrics.basin_count - baseline_metrics.basin_count,
            "rare_basin_count": candidate_metrics.rare_basin_count - baseline_metrics.rare_basin_count,
        },
        "blocking_findings": blocking,
        "integrity_warnings": list(integrity_warnings),
        "notes": [coordinate_note, "Inherited baseline rare basins are not treated as newly created defects.", "This record does not grant scientific entitlement."],
    }
    json_path = output_dir / f"{record_id}.json"
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    findings = blocking or ["None. Candidate passed all blocking engineering checks."]
    report_lines = [
        "AIIA PLATFORM v0.6.1 — CANDIDATE EVALUATION",
        "=" * 62,
        f"Candidate: {candidate_id}",
        f"Decision: {decision.value}",
        f"Outcome: {outcome}",
        f"Scientific status: {payload['scientific_status']}",
        "",
        "STRUCTURAL METRICS",
        f"Baseline maximum occupancy: {baseline_metrics.maximum_basin_occupancy:.6f}",
        f"Candidate maximum occupancy: {candidate_metrics.maximum_basin_occupancy:.6f}",
        f"Occupancy delta: {candidate_metrics.maximum_basin_occupancy-baseline_metrics.maximum_basin_occupancy:+.6f}",
        f"Baseline basin count: {baseline_metrics.basin_count}",
        f"Candidate basin count: {candidate_metrics.basin_count}",
        f"Baseline rare-basin count: {baseline_metrics.rare_basin_count}",
        f"Candidate rare-basin count: {candidate_metrics.rare_basin_count}",
        f"New rare basin IDs: {list(new_rare_basin_ids)}",
        "",
        "VALIDATION",
        f"Package integrity valid: {valid}",
        f"Rows preserved: {rows_preserved}",
        f"Lineage valid: {lineage_ok}",
        f"Coordinates preserved: {coordinates_preserved}",
        "",
        "BLOCKING FINDINGS",
    ]
    report_lines.extend(f"- {item}" for item in findings)
    report_lines.extend([
        "",
        "GOVERNANCE",
        "Engineering prequalification is not scientific qualification.",
        "Only accepted candidates receive a standard SII requalification request.",
    ])
    report_path = output_dir / f"{record_id}.txt"
    report_path.write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    return (
        decision,
        ArtifactRef(str(json_path), "candidate_evaluation_record", sha256_file(json_path), record_id),
        ArtifactRef(str(report_path), "candidate_evaluation_report", sha256_file(report_path)),
        "engineering_prequalification_only",
        outcome,
    )
