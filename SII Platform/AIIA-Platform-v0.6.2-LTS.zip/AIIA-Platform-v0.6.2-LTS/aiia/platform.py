from __future__ import annotations

from pathlib import Path
import json

from aiia import __version__
from aiia.evaluation import evaluate_candidate
from aiia.interfaces.sii_interface import SIIInterface
from aiia.projects.base import ScientificProject
from aiia.rem.adapters.dominant_basin_split import split_dominant_basin
from aiia.rem.diagnosis import diagnose_product
from aiia.representation import load_representation_product
from aiia.shared.io import sha256_file
from aiia.shared.models import (
    ArtifactRef,
    CandidateEvaluation,
    CandidateRepresentation,
    Decision,
    EngineeringRecord,
    new_id,
)


def _read_record_id(path: Path) -> str | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    value = payload.get("object_id") or payload.get("record_id") or payload.get("scientific_record_id")
    return str(value) if value else None


def _overall_decision(evaluations: list[CandidateEvaluation]) -> Decision:
    decisions = [item.decision for item in evaluations]
    if any(value is Decision.ACCEPT for value in decisions):
        return Decision.ACCEPT
    if decisions and all(value is Decision.REJECT for value in decisions):
        return Decision.REJECT
    if any(value is Decision.ERROR for value in decisions):
        return Decision.ERROR
    return Decision.INCONCLUSIVE


def run_project(project: ScientificProject) -> EngineeringRecord:
    output = project.output_directory
    output.mkdir(parents=True, exist_ok=True)
    baseline = load_representation_product(project.baseline_product)
    baseline_ref = ArtifactRef(
        str(baseline.path),
        "baseline_representation_product",
        baseline.package_sha256,
        baseline.product_id,
    )

    scientific_record_ref = None
    if project.baseline_scientific_record and project.baseline_scientific_record.exists():
        scientific_record_ref = ArtifactRef(
            str(project.baseline_scientific_record.resolve()),
            "scientific_record",
            sha256_file(project.baseline_scientific_record),
            _read_record_id(project.baseline_scientific_record),
        )

    diagnosis = diagnose_product(baseline)
    candidates: list[CandidateRepresentation] = []
    for split_count in project.dominant_split_counts:
        name = f"dominant_basin_split_{split_count}"
        candidate_id = new_id("candidate")
        candidate_path = output / "candidate_representation_products" / name / f"{name}-{candidate_id}.aiia-rp"
        result = split_dominant_basin(baseline.path, candidate_path, split_count, project.seed)
        candidates.append(
            CandidateRepresentation(
                candidate_id=candidate_id,
                name=name,
                parent_product_id=baseline.product_id,
                product=ArtifactRef(
                    str(result.candidate_product.path),
                    "candidate_representation_product",
                    result.candidate_product.package_sha256,
                    result.candidate_product.product_id,
                ),
                intervention="dominant_basin_hierarchical_split",
                parameters={
                    "split_count": split_count,
                    "seed": project.seed,
                    "dominant_basin": result.dominant_basin,
                },
                status="constructed_pending_evaluation",
                notes=("Candidate is an engineering object, not a scientific result.",),
            )
        )

    engineering_record_id = new_id("engineering-record")
    evaluations: list[CandidateEvaluation] = []
    if project.execute_candidates:
        sii = SIIInterface()
        for candidate in candidates:
            try:
                product = load_representation_product(Path(candidate.product.path))
                decision, evaluation_record, evaluation_report, entitlement, outcome = evaluate_candidate(
                    baseline=baseline,
                    candidate=product,
                    output_dir=output / "candidate_evaluations" / candidate.name,
                    candidate_id=candidate.candidate_id,
                )
                request_ref = None
                if decision is Decision.ACCEPT:
                    request = sii.create_requalification_request(
                        candidate_product=Path(candidate.product.path),
                        candidate_product_id=product.product_id,
                        parent_product_id=baseline.product_id,
                        engineering_record_id=engineering_record_id,
                        output_dir=output / "sii_requalification_requests",
                    )
                    request_ref = request.request
                evaluations.append(CandidateEvaluation(
                    candidate_id=candidate.candidate_id,
                    decision=decision,
                    evaluation_record=evaluation_record,
                    evaluation_report=evaluation_report,
                    requalification_request=request_ref,
                    entitlement=entitlement,
                    outcome=outcome,
                ))
            except Exception as exc:  # preserve the full run and record the failure
                evaluations.append(CandidateEvaluation(
                    candidate_id=candidate.candidate_id,
                    decision=Decision.ERROR,
                    entitlement="none",
                    outcome="evaluation_error",
                    error=f"{type(exc).__name__}: {exc}",
                ))
        overall = _overall_decision(evaluations)
    else:
        overall = Decision.PLAN_ONLY

    record = EngineeringRecord(
        engineering_record_id=engineering_record_id,
        platform_version=__version__,
        project_code=project.code,
        project_name=project.name,
        domain=project.domain,
        baseline_product=baseline_ref,
        baseline_scientific_record=scientific_record_ref,
        diagnosis=diagnosis,
        candidates=tuple(candidates),
        evaluations=tuple(evaluations),
        decision=overall,
        provenance={
            "sii_output_root": str(project.context.config.sii_output_root),
            "baseline_manifest_schema": baseline.manifest.get("schema"),
            "baseline_schema_version": baseline.manifest.get("schema_version"),
            "candidate_evaluation": "AIIA engineering prequalification",
            "scientific_requalification": "requested only for engineering-prequalified candidates",
        },
    )
    record.write_json(output / "engineering_records" / f"{record.engineering_record_id}.json")
    record.write_json(output / "engineering_record.json")
    write_report(record, output / "engineering_report.txt")
    return record


def write_report(record: EngineeringRecord, path: Path) -> None:
    lines = [
        "AIIA PLATFORM v0.6.1 — ENGINEERING REPORT",
        "=" * 58,
        f"Engineering Record: {record.engineering_record_id}",
        f"Project: {record.project_name}",
        f"Domain: {record.domain}",
        f"Engineering decision: {record.decision.value}",
        "Scientific status: candidate requalification requested",
        "",
        "BASELINE",
        f"Product: {record.baseline_product.path}",
        f"Product ID: {record.baseline_product.object_id}",
        f"SHA-256: {record.baseline_product.sha256}",
        "",
        "DIAGNOSIS",
    ]
    lines.extend(f"- {finding}" for finding in record.diagnosis)
    lines.extend(["", "CANDIDATE REPRESENTATION PRODUCTS"])
    evaluation_map = {item.candidate_id: item for item in record.evaluations}
    for candidate in record.candidates:
        evaluation = evaluation_map.get(candidate.candidate_id)
        lines.extend([
            f"- {candidate.name}",
            f"  Product: {candidate.product.path}",
            f"  Product ID: {candidate.product.object_id}",
            f"  Intervention: {candidate.intervention}",
            f"  Engineering evaluation: {evaluation.decision.value if evaluation else 'not_executed'}",
            f"  Outcome: {evaluation.outcome if evaluation else 'not_executed'}",
            f"  SII request: {evaluation.requalification_request.path if evaluation and evaluation.requalification_request else 'not_created'}",
        ])
    lines.extend([
        "",
        "SCIENTIFIC STATUS",
        "AIIA v0.6.1 evaluates engineering candidates and creates SII requests only for candidates that pass prequalification.",
        "No engineering acceptance grants scientific entitlement.",
        "Final scientific selection requires an independent SII Scientific Record.",
        "",
        "GOVERNANCE",
    ])
    lines.extend(f"- {item}" for item in record.governance)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
