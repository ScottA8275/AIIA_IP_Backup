from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class PlatformConfig:
    """Single source of truth for AIIA Platform paths and defaults."""

    workspace_root: Path
    sii_output_root: Path
    aiia_output_root: Path
    default_seed: int = 42
    dominant_split_counts: tuple[int, ...] = (2, 3, 4)
    execute_candidates: bool = True
    sii_timeout_seconds: int = 86_400

    @property
    def representation_product_dir(self) -> Path:
        return self.sii_output_root / "skr" / "representation_products"

    @property
    def scientific_record_root(self) -> Path:
        return self.sii_output_root / "skr"

    def project_output(self, project_code: str) -> Path:
        return self.aiia_output_root / project_code

    def normalized(self) -> "PlatformConfig":
        return PlatformConfig(
            workspace_root=self.workspace_root.expanduser().resolve(),
            sii_output_root=self.sii_output_root.expanduser().resolve(),
            aiia_output_root=self.aiia_output_root.expanduser().resolve(),
            default_seed=self.default_seed,
            dominant_split_counts=tuple(self.dominant_split_counts),
            execute_candidates=self.execute_candidates,
            sii_timeout_seconds=self.sii_timeout_seconds,
        )


# =============================================================================
# USER PARAMETERS — edit only this section.
# =============================================================================
WORKSPACE_ROOT = Path(r"C:\Users\scott\PyCharmMiscProject")
SII_OUTPUT_ROOT = WORKSPACE_ROOT / "examples" / "sii_v2_5_output"
AIIA_OUTPUT_ROOT = WORKSPACE_ROOT / "examples" / "aiia_platform_v0_6_1"

DEFAULT_SEED = 42
DEFAULT_DOMINANT_SPLITS = (2, 3, 4)
DEFAULT_EXECUTE_CANDIDATES = True
DEFAULT_SII_TIMEOUT_SECONDS = 86_400
# =============================================================================
# END USER PARAMETERS
# =============================================================================


def load_config() -> PlatformConfig:
    return PlatformConfig(
        workspace_root=WORKSPACE_ROOT,
        sii_output_root=SII_OUTPUT_ROOT,
        aiia_output_root=AIIA_OUTPUT_ROOT,
        default_seed=DEFAULT_SEED,
        dominant_split_counts=DEFAULT_DOMINANT_SPLITS,
        execute_candidates=DEFAULT_EXECUTE_CANDIDATES,
        sii_timeout_seconds=DEFAULT_SII_TIMEOUT_SECONDS,
    ).normalized()
