from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any
import json
import uuid


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex}"


class Decision(str, Enum):
    PLAN_ONLY = "plan_only"
    ACCEPT = "accept"
    REJECT = "reject"
    INCONCLUSIVE = "inconclusive"
    ERROR = "error"


@dataclass(frozen=True)
class ArtifactRef:
    path: str
    kind: str
    sha256: str | None = None
    object_id: str | None = None


@dataclass(frozen=True)
class CandidateRepresentation:
    candidate_id: str
    name: str
    parent_product_id: str
    product: ArtifactRef
    intervention: str
    parameters: dict[str, Any]
    status: str = "constructed_unqualified"
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class CandidateEvaluation:
    candidate_id: str
    decision: Decision
    evaluation_record: ArtifactRef | None = None
    evaluation_report: ArtifactRef | None = None
    requalification_request: ArtifactRef | None = None
    scientific_record: ArtifactRef | None = None
    qualification_report: ArtifactRef | None = None
    entitlement: str | None = None
    outcome: str | None = None
    error: str | None = None


@dataclass(frozen=True)
class EngineeringRecord:
    engineering_record_id: str
    platform_version: str
    project_code: str
    project_name: str
    domain: str
    baseline_product: ArtifactRef
    baseline_scientific_record: ArtifactRef | None
    diagnosis: tuple[str, ...]
    candidates: tuple[CandidateRepresentation, ...]
    evaluations: tuple[CandidateEvaluation, ...]
    decision: Decision
    created_at: str = field(default_factory=utc_now)
    governance: tuple[str, ...] = (
        "The baseline Representation Product is immutable.",
        "Each engineering intervention creates a new candidate Representation Product.",
        "A candidate remains unqualified until independently evaluated by SII.",
        "REM proposes and constructs; SII alone determines scientific entitlement.",
    )
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        def convert(value: Any) -> Any:
            if isinstance(value, Enum):
                return value.value
            if hasattr(value, "__dataclass_fields__"):
                return {key: convert(item) for key, item in asdict(value).items()}
            if isinstance(value, dict):
                return {str(key): convert(item) for key, item in value.items()}
            if isinstance(value, (tuple, list)):
                return [convert(item) for item in value]
            return value
        return convert(self)

    def write_json(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
