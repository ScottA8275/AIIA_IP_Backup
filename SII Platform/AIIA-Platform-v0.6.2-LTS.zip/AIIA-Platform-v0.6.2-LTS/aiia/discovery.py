from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json

from aiia.config import PlatformConfig


@dataclass(frozen=True)
class DiscoveryResult:
    representation_products: tuple[Path, ...]
    scientific_records: tuple[Path, ...]

    @property
    def latest_representation_product(self) -> Path:
        if not self.representation_products:
            raise FileNotFoundError("No Representation Products were discovered.")
        return max(self.representation_products, key=lambda path: path.stat().st_mtime)

    @property
    def latest_scientific_record(self) -> Path | None:
        if not self.scientific_records:
            return None
        return max(self.scientific_records, key=lambda path: path.stat().st_mtime)


def _looks_like_scientific_record(path: Path) -> bool:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return False
    object_type = str(payload.get("object_type", "")).lower()
    object_id = str(payload.get("object_id") or payload.get("record_id") or payload.get("scientific_record_id") or "").lower()
    return object_type == "scientific_record" or object_id.startswith("record-") or object_id.startswith("scientific-record-")


def discover_sii_outputs(config: PlatformConfig) -> DiscoveryResult:
    products = tuple(sorted(config.representation_product_dir.glob("*.aiia-rp")))
    records = tuple(
        path
        for path in config.scientific_record_root.rglob("*.json")
        if _looks_like_scientific_record(path)
    ) if config.scientific_record_root.exists() else ()
    return DiscoveryResult(products, records)
