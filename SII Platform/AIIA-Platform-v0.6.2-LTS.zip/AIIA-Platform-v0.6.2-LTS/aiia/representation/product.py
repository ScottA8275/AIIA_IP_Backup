from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping
import copy
import io
import json
import uuid
import zipfile

import numpy as np

from aiia import __version__
from rix_core.integrity import sha256_file

from rix_core.representation import ASSIGNMENT_ALIASES, FEATURE_ALIASES, first_present, array_inventory


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _basin_summary(assignments: np.ndarray, features: np.ndarray, profile_width: int | None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    basin_ids, counts = np.unique(assignments.astype(np.int64), return_counts=True)
    occupancy = counts.astype(float)
    width = int(profile_width or min(features.shape[1] if features.ndim > 1 else 1, 5))
    values = features.reshape(len(features), -1)[:, :width]
    profiles = np.stack([values[assignments == basin_id].mean(axis=0) for basin_id in basin_ids])
    return basin_ids.astype(np.int64), occupancy, profiles


def _recompute_microstate_to_basin(arrays: dict[str, np.ndarray], assignments: np.ndarray) -> None:
    if "microstate_assignments" not in arrays or "microstate_to_basin" not in arrays:
        return
    microstates = np.asarray(arrays["microstate_assignments"], dtype=np.int64).reshape(-1)
    if len(microstates) != len(assignments) or len(microstates) == 0:
        return
    mapping = np.full(int(microstates.max()) + 1, -1, dtype=np.int64)
    for microstate in np.unique(microstates):
        values, counts = np.unique(assignments[microstates == microstate], return_counts=True)
        mapping[int(microstate)] = int(values[np.argmax(counts)])
    arrays["microstate_to_basin"] = mapping


def _separate_parent_science(representation: dict[str, Any], parent: "NativeRepresentationProduct") -> None:
    diagnostics = copy.deepcopy(representation.get("diagnostics", {}))
    payload = copy.deepcopy(representation.get("payload", {}))
    inherited: dict[str, Any] = {
        "parent_product_id": parent.product_id,
        "parent_diagnostics": diagnostics,
    }
    scientific_payload_keys = [
        key for key in payload
        if any(token in key.lower() for token in ("qualification", "equivalence", "entitlement", "review"))
    ]
    if scientific_payload_keys:
        inherited["parent_payload"] = {key: payload.pop(key) for key in scientific_payload_keys}
    representation["payload"] = payload
    representation["diagnostics"] = {
        "equivalence_passed": None,
        "phase1_executed": False,
        "scientific_status": "unqualified_candidate",
    }
    representation["parent_scientific_context"] = inherited
    representation["candidate_scientific_status"] = {
        "qualified": False,
        "scientific_record_id": None,
        "qualification_report_id": None,
        "status": "requires_independent_sii_requalification",
    }


@dataclass(frozen=True)
class NativeRepresentationProduct:
    path: Path
    manifest: dict[str, Any]
    representation: dict[str, Any]

    @property
    def product_id(self) -> str:
        return str(self.manifest.get("product_id") or self.representation.get("object_id") or "unknown")

    @property
    def package_sha256(self) -> str:
        return sha256_file(self.path)

    def load_arrays(self) -> dict[str, np.ndarray]:
        with zipfile.ZipFile(self.path, "r") as archive:
            with np.load(io.BytesIO(archive.read("arrays.npz")), allow_pickle=False) as payload:
                return {name: payload[name] for name in payload.files}

    def validate(self) -> tuple[bool, tuple[str, ...], tuple[str, ...]]:
        errors: list[str] = []
        warnings: list[str] = []
        arrays = self.load_arrays()
        assignment_name = first_present(arrays, ASSIGNMENT_ALIASES)
        feature_name = first_present(arrays, FEATURE_ALIASES)
        if not assignment_name:
            errors.append(f"No basin assignment array found. Expected one of {ASSIGNMENT_ALIASES}.")
        if not feature_name:
            errors.append(f"No feature array found. Expected one of {FEATURE_ALIASES}.")
        if assignment_name and feature_name and len(arrays[assignment_name]) != len(arrays[feature_name]):
            errors.append("Assignment and feature arrays have different row counts.")
        if assignment_name:
            assignments = np.asarray(arrays[assignment_name]).reshape(-1)
            basin_ids = np.unique(assignments)
            basin_count = len(basin_ids)
            if "basin_occupancy" in arrays and len(arrays["basin_occupancy"]) != basin_count:
                errors.append("basin_occupancy length does not match the number of assigned basins.")
            if "basin_profiles" in arrays and len(arrays["basin_profiles"]) != basin_count:
                errors.append("basin_profiles row count does not match the number of assigned basins.")
            legacy_ids = self.representation.get("payload", {}).get("legacy_metadata", {}).get("basin_ids_in_profile_order")
            if legacy_ids is not None and list(map(int, legacy_ids)) != list(map(int, basin_ids)):
                errors.append("basin_ids_in_profile_order does not match assigned basin IDs.")
            if "microstate_assignments" in arrays and len(arrays["microstate_assignments"]) != len(assignments):
                errors.append("microstate_assignments row count does not match basin_assignments.")
            if "microstate_to_basin" in arrays and "microstate_assignments" in arrays:
                microstates = np.asarray(arrays["microstate_assignments"]).reshape(-1)
                if len(microstates) and len(arrays["microstate_to_basin"]) <= int(microstates.max()):
                    errors.append("microstate_to_basin does not cover all assigned microstate IDs.")
        if self.manifest.get("product_id") and self.representation.get("object_id"):
            if self.manifest["product_id"] != self.representation["object_id"]:
                warnings.append("Manifest product_id differs from representation object_id.")
        return not errors, tuple(errors), tuple(warnings)

    def assignment_array_name(self) -> str:
        name = first_present(self.load_arrays(), ASSIGNMENT_ALIASES)
        if not name:
            raise ValueError("No basin assignment array found.")
        return name

    def feature_array_name(self) -> str:
        name = first_present(self.load_arrays(), FEATURE_ALIASES)
        if not name:
            raise ValueError("No feature array found.")
        return name


def load_representation_product(path: Path) -> NativeRepresentationProduct:
    path = Path(path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"Representation Product not found: {path}")
    with zipfile.ZipFile(path, "r") as archive:
        names = set(archive.namelist())
        missing = {"manifest.json", "representation.json", "arrays.npz"} - names
        if missing:
            raise ValueError(f"Invalid SII Representation Product; missing {sorted(missing)}")
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
        representation = json.loads(archive.read("representation.json").decode("utf-8"))
    product = NativeRepresentationProduct(path, manifest, representation)
    valid, errors, _ = product.validate()
    if not valid:
        raise ValueError("Representation Product failed validation: " + "; ".join(errors))
    return product


def write_candidate_product(
    *,
    parent: NativeRepresentationProduct,
    output_path: Path,
    arrays: Mapping[str, Any],
    intervention: str,
    parameters: Mapping[str, Any],
    notes: tuple[str, ...] = (),
) -> NativeRepresentationProduct:
    output_path = Path(output_path).expanduser().resolve()
    if output_path.suffix != ".aiia-rp":
        output_path = output_path.with_suffix(".aiia-rp")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path.exists():
        raise FileExistsError(f"Refusing to overwrite candidate: {output_path}")

    normalized = {str(key): np.asarray(value) for key, value in arrays.items() if value is not None}
    for key, value in normalized.items():
        if value.dtype == object:
            raise TypeError(f"Unsafe object dtype in {key}.")

    assignment_name = first_present(normalized, ASSIGNMENT_ALIASES)
    feature_name = first_present(normalized, FEATURE_ALIASES)
    if not assignment_name or not feature_name:
        raise ValueError("Candidate requires basin assignments and features.")
    assignments = np.asarray(normalized[assignment_name], dtype=np.int64).reshape(-1)
    features = np.asarray(normalized[feature_name], dtype=float)
    profile_width = normalized.get("basin_profiles", np.empty((0, min(features.reshape(len(features), -1).shape[1], 5)))).shape[1]
    basin_ids, occupancy, profiles = _basin_summary(assignments, features, profile_width)
    normalized["basin_occupancy"] = occupancy
    normalized["basin_profiles"] = profiles
    _recompute_microstate_to_basin(normalized, assignments)

    product_id = f"representation-{uuid.uuid4().hex}"
    inventory = array_inventory(normalized)
    representation = copy.deepcopy(parent.representation)
    _separate_parent_science(representation, parent)
    payload = representation.setdefault("payload", {})
    legacy = payload.setdefault("legacy_metadata", {})
    # Parent basin-derived summaries are stale after an intervention. The native
    # arrays below are the candidate source of truth until SII requalification.
    legacy.pop("raw_basin_profile_means", None)
    legacy.pop("basin_occupancy", None)
    legacy["basin_ids_in_profile_order"] = basin_ids.tolist()
    legacy["n_states"] = int(len(assignments))
    baseline_config = payload.setdefault("baseline_configuration", {})
    baseline_config["n_basins"] = int(len(basin_ids))
    payload["candidate_structure"] = {
        "n_basins": int(len(basin_ids)),
        "basin_ids_in_profile_order": basin_ids.tolist(),
        "represented_state_count": int(len(assignments)),
    }
    source_count = representation.get("observation_count")
    representation.update({
        "object_id": product_id,
        "object_type": "representation_product",
        "package_uri": str(output_path),
        "package_sha256": None,
        "array_inventory": inventory,
        "engineering_status": "candidate_unqualified",
        "parent_product_id": parent.product_id,
        "engineering_intervention": intervention,
        "engineering_parameters": dict(parameters),
        "engineering_notes": list(notes),
        "created_at": _now(),
        "source_observation_count": int(source_count) if source_count is not None else None,
        "represented_state_count": int(len(assignments)),
    })
    representation.pop("observation_count", None)
    manifest = {
        "schema": "aiia.native-representation-product",
        "schema_version": "1.1",
        "product_id": product_id,
        "instrument": parent.manifest.get("instrument", {}),
        "dataset": parent.manifest.get("dataset", {}),
        "experiment": {"object_id": f"engineering-experiment-{uuid.uuid4().hex}", "code": "AIIA-REM", "name": intervention},
        "representation": representation,
        "arrays": inventory,
        "lineage": {"parent_product_id": parent.product_id, "parent_package_sha256": parent.package_sha256},
        "engineering": {
            "platform_version": __version__, "status": "candidate_unqualified", "intervention": intervention,
            "parameters": dict(parameters), "notes": list(notes),
            "materialization": {
                "basin_dependent_arrays_recomputed": ["basin_occupancy", "basin_profiles", "microstate_to_basin"],
                "profile_source_array": feature_name,
                "profile_width": int(profile_width),
            },
        },
        "candidate_scientific_status": representation["candidate_scientific_status"],
        "immutability": {"policy": "A changed representation must be persisted as a new product ID."},
    }

    buffer = io.BytesIO()
    np.savez_compressed(buffer, **normalized)
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, indent=2, sort_keys=True))
        archive.writestr("representation.json", json.dumps(representation, indent=2, sort_keys=True))
        archive.writestr("arrays.npz", buffer.getvalue())
    candidate = load_representation_product(output_path)
    valid, errors, _ = candidate.validate()
    if not valid:
        output_path.unlink(missing_ok=True)
        raise ValueError("Candidate package integrity validation failed: " + "; ".join(errors))
    return candidate
