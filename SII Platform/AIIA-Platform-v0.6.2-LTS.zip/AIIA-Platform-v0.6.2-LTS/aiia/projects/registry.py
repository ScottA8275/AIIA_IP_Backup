from __future__ import annotations

from typing import Type

from aiia.projects.base import ScientificProject
from aiia.projects.solar import SolarProject

_PROJECTS: dict[str, Type[ScientificProject]] = {
    SolarProject.code: SolarProject,
}


def get_project_class(code: str) -> Type[ScientificProject]:
    normalized = code.strip().lower()
    if normalized not in _PROJECTS:
        raise KeyError(f"Unknown project '{code}'. Available projects: {', '.join(sorted(_PROJECTS))}")
    return _PROJECTS[normalized]


def available_projects() -> tuple[str, ...]:
    return tuple(sorted(_PROJECTS))
