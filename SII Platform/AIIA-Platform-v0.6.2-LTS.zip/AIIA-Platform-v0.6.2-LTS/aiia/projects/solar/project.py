from aiia.projects.base import ScientificProject


class SolarProject(ScientificProject):
    code = "solar"
    name = "Solar Structural Representation Engineering"
    domain = "solar dynamics"
