from aiia.projects.solar.project import SolarProject

__all__ = ["SolarProject"]
