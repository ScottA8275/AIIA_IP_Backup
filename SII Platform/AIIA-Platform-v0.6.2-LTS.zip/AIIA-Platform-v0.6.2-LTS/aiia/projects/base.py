from __future__ import annotations

from abc import ABC
from dataclasses import dataclass
from pathlib import Path

from aiia.config import PlatformConfig
from aiia.discovery import DiscoveryResult
from aiia.shared.models import EngineeringRecord


@dataclass(frozen=True)
class ProjectContext:
    config: PlatformConfig
    discovery: DiscoveryResult


class ScientificProject(ABC):
    code = ""
    name = ""
    domain = ""

    def __init__(self, context: ProjectContext):
        self.context = context

    @property
    def baseline_product(self) -> Path:
        return self.context.discovery.latest_representation_product

    @property
    def baseline_scientific_record(self) -> Path | None:
        return self.context.discovery.latest_scientific_record

    @property
    def output_directory(self) -> Path:
        return self.context.config.project_output(self.code)

    @property
    def dominant_split_counts(self) -> tuple[int, ...]:
        return self.context.config.dominant_split_counts

    @property
    def seed(self) -> int:
        return self.context.config.default_seed

    @property
    def execute_candidates(self) -> bool:
        return self.context.config.execute_candidates

    def run(self) -> EngineeringRecord:
        from aiia.platform import run_project
        return run_project(self)
