from __future__ import annotations

import numpy as np

from aiia.representation import NativeRepresentationProduct


def diagnose_product(product: NativeRepresentationProduct) -> tuple[str, ...]:
    arrays = product.load_arrays()
    assignments = arrays[product.assignment_array_name()]
    basin_ids, counts = np.unique(assignments, return_counts=True)
    share = float(counts.max() / counts.sum())
    findings = [
        f"Baseline contains {len(basin_ids)} basins across {len(assignments)} represented states.",
        f"Dominant basin occupancy share is {share:.4f}.",
    ]
    if share >= 0.25:
        findings.append("Dominant-basin concentration supports a hierarchical split trial.")
    else:
        findings.append("No strong dominant-basin concentration was detected; split trial remains exploratory.")
    return tuple(findings)
