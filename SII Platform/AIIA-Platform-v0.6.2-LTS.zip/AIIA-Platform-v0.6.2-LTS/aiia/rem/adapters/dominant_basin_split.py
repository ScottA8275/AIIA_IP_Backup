from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import numpy as np

from rix_core.clustering import deterministic_kmeans

from aiia.representation import NativeRepresentationProduct, load_representation_product, write_candidate_product


@dataclass(frozen=True)
class SplitResult:
    candidate_product: NativeRepresentationProduct
    dominant_basin: int
    original_occupancy: int
    split_count: int
    new_basin_ids: tuple[int, ...]


def _kmeans(values: np.ndarray, k: int, seed: int, max_iter: int = 100) -> np.ndarray:
    """Compatibility wrapper around the frozen RIX Core primitive."""
    return deterministic_kmeans(values, k, seed, max_iter)


def split_dominant_basin(
    source_product_path: Path,
    output_product_path: Path,
    split_count: int,
    seed: int = 42,
) -> SplitResult:
    if split_count < 2:
        raise ValueError("split_count must be at least 2.")
    source = load_representation_product(source_product_path)
    arrays = source.load_arrays()
    assignment_name = source.assignment_array_name()
    feature_name = source.feature_array_name()
    assignments = np.asarray(arrays[assignment_name], dtype=np.int64)
    features = np.asarray(arrays[feature_name], dtype=float)

    basin_ids, counts = np.unique(assignments, return_counts=True)
    dominant = int(basin_ids[np.argmax(counts)])
    mask = assignments == dominant
    local_labels = _kmeans(features[mask], split_count, seed)
    candidate_assignments = assignments.copy()
    next_id = int(assignments.max()) + 1
    new_ids = [dominant]
    indices = np.flatnonzero(mask)
    for cluster in range(1, split_count):
        new_id = next_id + cluster - 1
        new_ids.append(new_id)
        candidate_assignments[indices[local_labels == cluster]] = new_id

    updated = dict(arrays)
    updated[assignment_name] = candidate_assignments
    for alias in ("assignments", "basin_assignments"):
        if alias in updated:
            updated[alias] = candidate_assignments.copy()

    candidate_product = write_candidate_product(
        parent=source,
        output_path=output_product_path,
        arrays=updated,
        intervention="dominant_basin_hierarchical_split",
        parameters={
            "split_count": split_count,
            "seed": seed,
            "assignment_array": assignment_name,
            "feature_array": feature_name,
            "dominant_basin": dominant,
        },
        notes=(
            f"Parent {source.product_id} was not modified.",
            f"Dominant basin {dominant} was partitioned into {split_count} local basins.",
        ),
    )
    return SplitResult(candidate_product, dominant, int(mask.sum()), split_count, tuple(new_ids))
