from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json

from aiia.shared.io import sha256_file
from aiia.shared.models import ArtifactRef, new_id, utc_now


@dataclass(frozen=True)
class RequalificationRequest:
    request: ArtifactRef
    candidate_product: ArtifactRef


class SIIInterface:
    """File-contract boundary between AIIA Platform and an independent SII process.

    v0.6.1 creates immutable requalification requests. A future SII command can consume
    these files without importing AIIA internals.
    """

    def create_requalification_request(
        self,
        *,
        candidate_product: Path,
        candidate_product_id: str,
        parent_product_id: str,
        engineering_record_id: str,
        output_dir: Path,
    ) -> RequalificationRequest:
        output_dir.mkdir(parents=True, exist_ok=True)
        request_id = new_id("sii-requalification-request")
        payload = {
            "object_id": request_id,
            "object_type": "sii_requalification_request",
            "created_at": utc_now(),
            "candidate_product": str(candidate_product.resolve()),
            "candidate_product_id": candidate_product_id,
            "parent_product_id": parent_product_id,
            "engineering_record_id": engineering_record_id,
            "requested_profile": "validated-solar-phase1",
            "required_outputs": ["scientific_record", "qualification_report"],
            "governance": "SII independently determines scientific entitlement.",
        }
        path = output_dir / f"{request_id}.json"
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return RequalificationRequest(
            request=ArtifactRef(str(path), "sii_requalification_request", sha256_file(path), request_id),
            candidate_product=ArtifactRef(str(candidate_product.resolve()), "candidate_representation_product", sha256_file(candidate_product), candidate_product_id),
        )
