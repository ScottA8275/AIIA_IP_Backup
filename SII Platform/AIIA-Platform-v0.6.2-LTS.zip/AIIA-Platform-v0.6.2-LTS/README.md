# AIIA Platform v0.6.1

A corrective release for the v0.6 closed engineering loop. It preserves the external-SII architecture while correcting candidate materialization, rare-basin evaluation, lineage, and reporting semantics.

## Corrections

- Compares rare basins with the baseline; inherited rare basins are not treated as newly created defects.
- Recomputes `basin_occupancy`, `basin_profiles`, `basin_ids_in_profile_order`, basin counts, and `microstate_to_basin` after an intervention.
- Runs package-integrity validation before engineering evaluation.
- Separates parent scientific context from the unqualified candidate's own status.
- Distinguishes `source_observation_count` from `represented_state_count`.
- Reads Scientific Record identifiers from `object_id`, `record_id`, or `scientific_record_id`.
- Creates standard SII requalification requests only for accepted engineering candidates.
- Includes blocking findings in each human-readable candidate report.

## Configuration

Edit only the user-parameter section in `aiia/config.py`:

```python
WORKSPACE_ROOT = Path(r"C:\Users\scott\PyCharmMiscProject")
SII_OUTPUT_ROOT = WORKSPACE_ROOT / "examples" / "sii_v2_5_output"
AIIA_OUTPUT_ROOT = WORKSPACE_ROOT / "examples" / "aiia_platform_v0_6_1"
```

## Run

```bash
python run_solar.py
```

Expected output includes the number of candidates created, evaluated, and referred to SII. A rejected or inconclusive candidate does not receive a standard requalification request.

## Governance

Engineering prequalification never grants scientific entitlement. Accepted candidates remain unqualified until SII independently publishes a Scientific Record.
