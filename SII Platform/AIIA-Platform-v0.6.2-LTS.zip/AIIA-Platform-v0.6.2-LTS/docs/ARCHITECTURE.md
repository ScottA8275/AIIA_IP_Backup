# Architecture

```text
SII v2.5
  ├── baseline .aiia-rp
  └── baseline Scientific Record
          │
          ▼
AIIA Platform v0.6.1
  ├── Project registry
  ├── REM diagnosis
  ├── immutable candidate .aiia-rp products
  ├── engineering prequalification
  ├── Engineering Record
  └── SII requalification request contract
          │
          ▼
Independent SII candidate qualification
  └── future candidate Scientific Record
```

The file-based request contract avoids imports from SII internals and preserves the instrument/platform boundary.
