# AIIA Platform v0.6.1 Release Notes

## Purpose

v0.6.1 corrects issues identified by reviewing the complete v0.6 Solar output directory.

## Fixed

1. **Inherited rare-basin handling** — rejection now depends on new or worsened rare basins, not the mere presence of a rare basin already in the baseline.
2. **Candidate materialization** — basin-dependent arrays and metadata are regenerated after splitting.
3. **Package integrity** — assignments, profiles, occupancy, basin IDs, and microstate mappings are checked before evaluation.
4. **Scientific-status separation** — inherited parent diagnostics and scientific payload are namespaced under `parent_scientific_context`; candidates explicitly remain unqualified.
5. **Count semantics** — candidate metadata uses separate source-observation and represented-state counts.
6. **Scientific Record lineage** — common Scientific Record identifier fields are supported.
7. **SII request policy** — only accepted candidates receive normal requalification requests.
8. **Explainability** — text reports include blocking findings and rare-basin comparisons.

## Expected effect on the reviewed Solar run

The inherited baseline microbasin should no longer be the sole cause of rejection. Candidates that pass integrity, lineage, preservation, occupancy, and new-rare-basin checks will be marked `accept` for engineering prequalification and referred to SII. This remains distinct from scientific qualification.
