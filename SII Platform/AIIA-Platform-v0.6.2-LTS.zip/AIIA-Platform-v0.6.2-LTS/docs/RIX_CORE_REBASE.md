# RIX Core rebase

AIIA Platform v0.6.2 LTS is a behavior-preserving maintenance release of v0.6.1 LTS.

Shared deterministic clustering, representation-array conventions, inventory generation, and file integrity now come from RIX Core v1.0 LTS. Engineering policy and outputs remain owned by AIIA Platform.
