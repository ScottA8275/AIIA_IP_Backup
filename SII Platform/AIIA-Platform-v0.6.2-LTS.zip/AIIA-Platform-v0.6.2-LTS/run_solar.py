from __future__ import annotations

from aiia.config import load_config
from aiia.projects import ProjectContext, get_project_class
from aiia.validation import ConfigurationError, print_startup_diagnostics, validate_startup


def main() -> None:
    config = load_config()
    try:
        validation = validate_startup(config, create_output=True)
    except ConfigurationError as error:
        print(error)
        raise SystemExit(2) from error

    project_class = get_project_class("solar")
    project = project_class(ProjectContext(config=validation.config, discovery=validation.discovery))
    print_startup_diagnostics(validation, project.code)
    record = project.run()

    print("AIIA Platform v0.6.1 complete.")
    print(f"Engineering Record: {record.engineering_record_id}")
    print(f"Decision: {record.decision.value}")
    print(f"Candidates created: {len(record.candidates)}")
    print(f"Candidates evaluated: {len(record.evaluations)}")
    print(f"SII requests created: {sum(1 for item in record.evaluations if item.requalification_request)}")
    print(f"Output: {project.output_directory}")


if __name__ == "__main__":
    main()
