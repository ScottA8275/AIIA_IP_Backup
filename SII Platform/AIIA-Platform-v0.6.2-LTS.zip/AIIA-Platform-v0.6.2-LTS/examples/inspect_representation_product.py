from __future__ import annotations

import argparse
from pathlib import Path

from aiia.representation import load_representation_product


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("product", type=Path)
    args = parser.parse_args()
    product = load_representation_product(args.product)
    print(f"Product ID: {product.product_id}")
    print(f"Path: {product.path}")
    print(f"SHA-256: {product.package_sha256}")
    print("Arrays:")
    for name, value in product.load_arrays().items():
        print(f"  {name}: shape={value.shape}, dtype={value.dtype}")


if __name__ == "__main__":
    main()
